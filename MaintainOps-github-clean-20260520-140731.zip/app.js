﻿const app = document.querySelector("#app");

const {
  STATUS_OPTIONS,
  TYPE_OPTIONS,
  ASSET_TYPE_OPTIONS,
  WORK_ORDERS_PER_PAGE,
  PARTS_PER_PAGE,
  ASSETS_PER_PAGE,
  LIST_ITEMS_PER_PAGE,
  SEARCH_ID_PAGE_SIZE,
  SEARCH_ID_CHUNK_SIZE,
  SEARCH_PREVIEW_LIMIT,
  OUTSIDE_VENDOR_VALUE,
  OUTSIDE_VENDOR_NOTE,
  COMPANY_ROLES,
  ACTIVE_LOCATION_STORAGE_KEY,
} = window.MaintainOpsConstants;
const { escapeHtml } = window.MaintainOpsDom;
const {
  postgrestSearchTerm,
  isoDate,
  isoDateTime,
  daysAgoDate,
  monthStartDate,
  chunkArray,
  fileBaseName,
  safeFileName,
  statusLabel,
  normalizeRole,
  roleLabel,
  roleDescription,
  formatDate,
  photoMetaText,
  requestPhotoMetaText,
  formatBytes,
  money,
  partUsageUnitCost,
  getDueState,
  startOfToday,
  csvCell,
} = window.MaintainOpsFormatting;
const { listLocations, createLocation: createLocationRecord } = window.MaintainOpsLocationsService;
const {
  listProfiles,
  listCompanyMembers,
  listTeamInvites,
  listTeamInvitesLegacy,
} = window.MaintainOpsProfilesService;
const { listParts } = window.MaintainOpsPartsService;
const { listAssets } = window.MaintainOpsAssetsService;
const {
  selectWorkOrders,
  countWorkOrdersQuery,
  fetchWorkOrderById,
  fetchWorkOrdersByIds,
  scopedWorkOrderSearchQuery: buildScopedWorkOrderSearchQuery,
  fetchPagedSearchRows,
} = window.MaintainOpsWorkOrdersService;
const {
  getMyCompanies,
  listUserCompanyMemberships,
  listUserCompanyMembershipsLegacy,
  listCompaniesByIds,
  listCompaniesByIdsLegacy,
} = window.MaintainOpsCompanyService;
const {
  listAppIssueReports,
  createAppIssueReportRecord,
  updateAppIssueReportStatusRecord,
} = window.MaintainOpsAppIssueReportsService;
const {
  renderMetric,
  renderInsight,
  renderRoleGuide,
} = window.MaintainOpsRenderDisplayHelpers;
const { createRelationshipDisplayHelpers } = window.MaintainOpsRelationshipDisplay;
const { createDashboardDisplayHelpers } = window.MaintainOpsDashboardDisplay;
const { segmentIcon, navIcon } = window.MaintainOpsIconDisplay;
const { assetTypeLabel, assetStatusLabel } = window.MaintainOpsEquipmentLabels;
const { createEmptyStateTextHelpers } = window.MaintainOpsEmptyStateText;
const { createRequestDisplayHelpers } = window.MaintainOpsRequestDisplay;
const { createGlobalSearchDisplayHelpers } = window.MaintainOpsGlobalSearchDisplay;
const { createWorkQueueDisplayHelpers } = window.MaintainOpsWorkQueueDisplay;
const { createPlanningDisplayHelpers } = window.MaintainOpsPlanningDisplay;
const { createMiniWorkOrderDisplayHelpers } = window.MaintainOpsMiniWorkOrderDisplay;
const { createPaginationDisplayHelpers } = window.MaintainOpsPaginationDisplay;
const { createPartsDisplayHelpers } = window.MaintainOpsPartsDisplay;
const { createOptionDisplayHelpers } = window.MaintainOpsOptionDisplay;
const { createSetupDisplayHelpers } = window.MaintainOpsSetupDisplay;
const { createRequestPhotoDisplayHelpers } = window.MaintainOpsRequestPhotoDisplay;
const { createMessageBadgeDisplayHelpers } = window.MaintainOpsMessageBadgeDisplay;
const { createAppIssueDisplayHelpers } = window.MaintainOpsAppIssueDisplay;
const { createWorkMessageDisplayHelpers } = window.MaintainOpsWorkMessageDisplay;
const { createWorkRecommendationDisplayHelpers } = window.MaintainOpsWorkRecommendationDisplay;
const { createCommandCardDisplayHelpers } = window.MaintainOpsCommandCardDisplay;
const { createWorkCommandDisplayHelpers } = window.MaintainOpsWorkCommandDisplay;
const { createMissingWorkDetailDisplayHelpers } = window.MaintainOpsMissingWorkDetailDisplay;
const { createPartSourceDisplayHelpers } = window.MaintainOpsPartSourceDisplay;
const { createAssetCardDisplayHelpers } = window.MaintainOpsAssetCardDisplay;
const { createProcedureOptionsDisplayHelpers } = window.MaintainOpsProcedureOptionsDisplay;
const { createMessageThreadLabelDisplayHelpers } = window.MaintainOpsMessageThreadLabelDisplay;
const { createMessageThreadButtonDisplayHelpers } = window.MaintainOpsMessageThreadButtonDisplay;
const { createMessageComposerDisplayHelpers } = window.MaintainOpsMessageComposerDisplay;
const { createAppIssuePanelDisplayHelpers } = window.MaintainOpsAppIssuePanelDisplay;
const { createInviteLocationDisplayHelpers } = window.MaintainOpsInviteLocationDisplay;
const { createPartSetupDisplayHelpers } = window.MaintainOpsPartSetupDisplay;
const { createTeamMemberDisplayHelpers } = window.MaintainOpsTeamMemberDisplay;
const { createTeamWorkloadDisplayHelpers } = window.MaintainOpsTeamWorkloadDisplay;
const { createLocationDisplayHelpers } = window.MaintainOpsLocationDisplay;
const { createDowntimeEmailDisplayHelpers } = window.MaintainOpsDowntimeEmailDisplay;
const {
  formatMessageTime,
  formatMessageDay,
  initials,
} = window.MaintainOpsMessageFormatting;
const { createMessageDisplayHelpers } = window.MaintainOpsMessageDisplay;
let supabaseClient;
let session;
let companies = [];
let activeCompanyId = localStorage.getItem("maintainops.activeCompanyId");
let locations = [];
let locationsReady = true;
let activeLocationId = localStorage.getItem(ACTIVE_LOCATION_STORAGE_KEY) || "";
let assets = [];
let workOrders = [];
let workOrderServerTotal = 0;
let workOrderDashboardCounts = null;
let myWorkDashboardCounts = null;
let workOrderRelatedSearch = { assetIds: [], workOrderIds: [], procedureIds: [] };
let exactWorkOrderSearchCache = { key: "", rows: [] };
let maintenanceRequests = [];
let requestServerTotal = 0;
let requestDashboardCounts = { active: 0, converted: 0, all: 0 };
let requestsReady = false;
let publicRequestLinks = [];
let publicRequestLinksReady = true;
let preventiveSchedules = [];
let companyMembers = [];
let teamInvites = [];
let teamInvitesReady = true;
let teamInviteCancelError = "";
let messageThreads = [];
let messageThreadMembers = [];
let messagesByThreadId = {};
let messageReadsByThreadId = {};
let messagesReady = true;
let messageWorkOrderLinksReady = true;
let appIssueReports = [];
let appIssueReportsReady = true;
let reportIssueMode = false;
let activeMessageThreadId = localStorage.getItem("maintainops.activeMessageThreadId") || "";
let messageThreadFilter = localStorage.getItem("maintainops.messageThreadFilter") || "all";
let messageSearchQuery = localStorage.getItem("maintainops.messageSearchQuery") || "";
let messageComposerWorkOrderId = localStorage.getItem("maintainops.messageComposerWorkOrderId") || "";
let messageComposerOpen = false;
let parts = [];
let partCostsReady = true;
let partSuppliersReady = true;
let partDocumentsReady = true;
let partDocumentsByPartId = {};
let procedureTemplates = [];
let proceduresReady = false;
let schedulesReady = false;
let outcomesReady = true;
let safetyChecksReady = true;
let photosReady = true;
let adminDeleteSqlConfirmed = localStorage.getItem("maintainops.adminDeleteSqlConfirmed") === "true";
let partsUsedByWorkOrder = {};
let eventsByWorkOrder = {};
let commentsByWorkOrder = {};
let photosByWorkOrder = {};
let stepResultsByWorkOrder = {};
let profilesByUserId = {};
let commentsError = "";
let requestPhotosReady = true;
let activeWorkOrderId = null;
let activeAssetId = null;
let activePartId = null;
let pendingDeleteWorkOrderId = null;
let pendingDeletePartId = null;
let pendingDeleteAssetId = null;
let pendingDeleteRequestId = null;
let pendingDeleteScheduleId = null;
let pendingDeleteProcedureId = null;
let pendingCancelInviteId = null;
let showPartSourceManager = false;
let createWorkOrderMode = false;
let quickFixMode = false;
let quickFixAssetId = null;
let quickFixRequestId = null;
let publicAppUrlOverride = localStorage.getItem("maintainops.publicAppUrl") || "";
let activeStatusFilter = "active";
let myWorkFilter = localStorage.getItem("maintainops.myWorkFilter") || "assigned";
let workOrderFilter = localStorage.getItem("maintainops.workOrderFilter") || "all";
let workOrderAssigneeFilter = localStorage.getItem("maintainops.workOrderAssigneeFilter") || "";
let workSort = localStorage.getItem("maintainops.workSort") || "newest";
let workOrderPage = Number(localStorage.getItem("maintainops.workOrderPage")) || 1;
let partsPage = Number(localStorage.getItem("maintainops.partsPage")) || 1;
let assetsPage = Number(localStorage.getItem("maintainops.assetsPage")) || 1;
let requestsPage = Number(localStorage.getItem("maintainops.requestsPage")) || 1;
let requestViewFilter = localStorage.getItem("maintainops.requestViewFilter") || "active";
let schedulesPage = Number(localStorage.getItem("maintainops.schedulesPage")) || 1;
let proceduresPage = Number(localStorage.getItem("maintainops.proceduresPage")) || 1;
let membersPage = Number(localStorage.getItem("maintainops.membersPage")) || 1;
let assetStatusFilter = localStorage.getItem("maintainops.assetStatusFilter") || "all";
let partInventoryFilter = localStorage.getItem("maintainops.partInventoryFilter") || "all";
let partSearchQuery = localStorage.getItem("maintainops.partSearchQuery") || "";
let activeSection = localStorage.getItem("maintainops.activeSection") || "mywork";
if (!localStorage.getItem("maintainops.sectionSplitDone") && activeSection === "work") {
  activeSection = "mywork";
  localStorage.setItem("maintainops.activeSection", activeSection);
  localStorage.setItem("maintainops.sectionSplitDone", "true");
}
let searchQuery = localStorage.getItem("maintainops.searchQuery") || "";
let workOrderSearchMode = localStorage.getItem("maintainops.workOrderSearchMode") === "true";
let appError = "";
let appNotice = "";
let appNoticeTone = "success";
let noticeTimer;
let workOrderActionWarningId = "";
let workOrderActionWarning = "";

const {
  teamMemberName,
} = createTeamMemberDisplayHelpers({
  getProfilesByUserId: () => profilesByUserId,
  getCurrentUser: () => session?.user,
});
const {
  teamMemberWorkload,
} = createTeamWorkloadDisplayHelpers({
  getWorkOrders: () => workOrders,
  matchesActiveLocation,
  getDueState,
});
const {
  activeLocationName,
} = createLocationDisplayHelpers({
  getLocations: () => locations,
  getActiveLocationId: () => activeLocationId,
});
const {
  downtimeEmailSubject,
  downtimeEmailBody,
} = createDowntimeEmailDisplayHelpers({
  formatDate,
  assignmentLabel,
  cleanWorkOrderDescription,
});
const relationshipDisplayHelpers = createRelationshipDisplayHelpers({
  escapeHtml,
  photoMetaText,
  partUsageUnitCost,
  money,
  checklistProgress,
  getProfilesByUserId: () => profilesByUserId,
  getProcedureTemplates: () => procedureTemplates,
  getPartsUsedByWorkOrder: () => partsUsedByWorkOrder,
  getCommentsByWorkOrder: () => commentsByWorkOrder,
  getPhotosByWorkOrder: () => photosByWorkOrder,
  getMessageThreads: () => messageThreads,
});
const {
  renderActivityItem,
  renderRelationshipChips,
  relationshipChip,
  relationshipIcon,
} = relationshipDisplayHelpers;
const dashboardDisplayHelpers = createDashboardDisplayHelpers({
  escapeHtml,
  getActiveStatusFilter: () => activeStatusFilter,
  getWorkOrderDashboardCounts: () => workOrderDashboardCounts,
  getRequestsReady: () => requestsReady,
  openMaintenanceRequests,
  matchesActiveLocation,
});
const {
  renderGaugeReadout,
  renderWorkOrderGaugeDashboard,
  renderWorkloadStrip,
} = dashboardDisplayHelpers;
const emptyStateTextHelpers = createEmptyStateTextHelpers({
  getSearchQuery: () => searchQuery,
  getAssetStatusFilter: () => assetStatusFilter,
  getPartSearchQuery: () => partSearchQuery,
  getPartInventoryFilter: () => partInventoryFilter,
  assetStatusLabel,
});
const {
  requestEmptyStateText,
  assetEmptyStateText,
  partEmptyStateText,
} = emptyStateTextHelpers;
const {
  requestPanelSubtitle,
  renderRequestFilterBar,
} = createRequestDisplayHelpers({
  segmentIcon,
});
const {
  renderGlobalSearchResults,
} = createGlobalSearchDisplayHelpers({
  escapeHtml,
  statusLabel,
  assignmentLabel,
  activeLocationName,
  getSearchQuery: () => searchQuery,
});
const {
  workOrdersPanelTitle,
  myWorkPanelTitle,
  workQueuePanelTitle,
  workQueuePanelSubtitle,
} = createWorkQueueDisplayHelpers({
  statusLabel,
  teamMemberName,
  getWorkOrderAssigneeFilter: () => workOrderAssigneeFilter,
  getWorkOrderFilter: () => workOrderFilter,
  getActiveStatusFilter: () => activeStatusFilter,
  getMyWorkFilter: () => myWorkFilter,
  getActiveSection: () => activeSection,
});
const {
  renderPlanningGroup,
  renderPlanningItem,
} = createPlanningDisplayHelpers({
  escapeHtml,
  statusLabel,
  renderRelationshipChips,
});
const {
  renderMiniWorkOrder,
  renderAssetMiniWorkOrder,
} = createMiniWorkOrderDisplayHelpers({
  escapeHtml,
  statusLabel,
  relationshipIcon,
  getPartsUsedByWorkOrder: () => partsUsedByWorkOrder,
  getPhotosByWorkOrder: () => photosByWorkOrder,
});
const {
  renderWorkPagination,
  renderPartsPagination,
  renderAssetsPagination,
  renderListPagination,
} = createPaginationDisplayHelpers({
  WORK_ORDERS_PER_PAGE,
  PARTS_PER_PAGE,
  ASSETS_PER_PAGE,
  LIST_ITEMS_PER_PAGE,
  getWorkOrderPage: () => workOrderPage,
  getPartsPage: () => partsPage,
  getAssetsPage: () => assetsPage,
});
const {
  renderPart,
  renderPartsHealth,
  renderPartSearch,
} = createPartsDisplayHelpers({
  escapeHtml,
  money,
  isLowStockPart,
  matchesActiveLocation,
  getParts: () => parts,
  getPartCostsReady: () => partCostsReady,
  getPartInventoryFilter: () => partInventoryFilter,
  getPartSearchQuery: () => partSearchQuery,
});
const {
  renderLocationOptions,
  renderAssetOptions,
  renderParentAssetOptions,
  assetOptionLabel,
} = createOptionDisplayHelpers({
  escapeHtml,
  getLocations: () => locations,
  getActiveLocationId: () => activeLocationId,
  getAssets: () => assets,
  filteredAssets,
  matchesActiveLocation,
  isAssetDescendantOf,
  parentAssetFor,
});
const {
  renderSetupItem,
} = createSetupDisplayHelpers({
  escapeHtml,
});
const {
  renderMaintenanceRequestPhoto,
} = createRequestPhotoDisplayHelpers({
  escapeHtml,
  requestPhotoMetaText,
  getRequestPhotosReady: () => requestPhotosReady,
});
const {
  renderMessageNavBadge,
} = createMessageBadgeDisplayHelpers({
  directUnreadMessages,
  totalUnreadMessages,
});
const {
  renderAppIssueReport,
} = createAppIssueDisplayHelpers({
  escapeHtml,
  getProfilesByUserId: () => profilesByUserId,
  getLocations: () => locations,
});
const {
  directThreadNames,
  messageThreadScopeLabel,
} = createMessageThreadLabelDisplayHelpers({
  getLocations: () => locations,
  getMessageThreadMembers: () => messageThreadMembers,
  teamMemberName,
});
const {
  renderWorkOrderMessages,
  renderLinkedWorkMessageThread,
} = createWorkMessageDisplayHelpers({
  escapeHtml,
  formatMessageTime,
  messageThreadScopeLabel,
  getMessageThreads: () => messageThreads,
  getMessagesByThreadId: () => messagesByThreadId,
  getMessageWorkOrderLinksReady: () => messageWorkOrderLinksReady,
});
const {
  renderWorkOrderRecommendation,
} = createWorkRecommendationDisplayHelpers({
  escapeHtml,
  recommendedWorkOrderStep,
});
const {
  renderEmailHelperCommandCard,
  commandShortcut,
} = createCommandCardDisplayHelpers({
  escapeHtml,
});
const {
  renderWorkOrderCommandSummary,
} = createWorkCommandDisplayHelpers({
  escapeHtml,
  statusLabel,
  assignmentLabel,
  isVendorAssigned,
  hasCompletedSafetyDeviceCheck,
  renderEmailHelperCommandCard,
  getMessageThreads: () => messageThreads,
  getPartsUsedByWorkOrder: () => partsUsedByWorkOrder,
});
const {
  renderMissingWorkOrderDetail,
} = createMissingWorkDetailDisplayHelpers();
const {
  renderPartSourceOptions,
  renderPartSourceManager,
} = createPartSourceDisplayHelpers({
  escapeHtml,
  getPartSources: () => partSourceOptions(),
  getPartSuppliersReady: () => partSuppliersReady,
});
const {
  renderAssetCard,
} = createAssetCardDisplayHelpers({
  escapeHtml,
  assetTypeLabel,
  getWorkOrders: () => workOrders,
  getActiveAssetId: () => activeAssetId,
  parentAssetFor,
  childAssetsFor,
});
const {
  renderProcedureOptions,
} = createProcedureOptionsDisplayHelpers({
  escapeHtml,
  getProceduresReady: () => proceduresReady,
  getProcedureTemplates: () => procedureTemplates,
});
const {
  renderMessageThreadButton,
} = createMessageThreadButtonDisplayHelpers({
  escapeHtml,
  formatMessageTime,
  teamMemberName,
  messageThreadScopeLabel,
  unreadMessageCount,
  getMessagesByThreadId: () => messagesByThreadId,
  getActiveMessageThreadId: () => activeMessageThreadId,
});
const {
  messageComposerScopeNote,
} = createMessageComposerDisplayHelpers({
  activeLocationName,
});
const {
  renderAppIssueReportsPanel,
} = createAppIssuePanelDisplayHelpers({
  canManageTeam,
  renderAppIssueReport,
  getAppIssueReportsReady: () => appIssueReportsReady,
  getAppIssueReports: () => appIssueReports,
});
const {
  inviteDefaultLocationLabel,
} = createInviteLocationDisplayHelpers({
  getLocations: () => locations,
});
const {
  partSetupMessage,
} = createPartSetupDisplayHelpers({
  getPartCostsReady: () => partCostsReady,
  getPartSuppliersReady: () => partSuppliersReady,
});
const messageDisplayHelpers = createMessageDisplayHelpers({
  escapeHtml,
  getCurrentUserId: () => session?.user?.id,
  teamMemberName,
  initials,
  formatMessageTime,
  formatMessageDay,
});
const {
  renderMessageBubble,
  renderMessageList,
} = messageDisplayHelpers;

// LFES-OBSERVABILITY: Active location is operational state; keep it scoped per user/company so reopen behavior stays explainable.
function activeLocationStorageKey(companyId = activeCompanyId, userId = session?.user?.id) {
  return companyId && userId
    ? `${ACTIVE_LOCATION_STORAGE_KEY}:${userId}:${companyId}`
    : ACTIVE_LOCATION_STORAGE_KEY;
}

function readStoredActiveLocationId(companyId = activeCompanyId, userId = session?.user?.id) {
  const scopedKey = activeLocationStorageKey(companyId, userId);
  if (scopedKey !== ACTIVE_LOCATION_STORAGE_KEY) {
    const scopedValue = localStorage.getItem(scopedKey);
    if (scopedValue) return scopedValue;
  }
  return localStorage.getItem(ACTIVE_LOCATION_STORAGE_KEY) || "";
}

function persistActiveLocationId(locationId, companyId = activeCompanyId, userId = session?.user?.id) {
  const value = locationId || "";
  const scopedKey = activeLocationStorageKey(companyId, userId);
  if (scopedKey !== ACTIVE_LOCATION_STORAGE_KEY) {
    localStorage.setItem(scopedKey, value);
    localStorage.removeItem(ACTIVE_LOCATION_STORAGE_KEY);
    return;
  }
  localStorage.setItem(ACTIVE_LOCATION_STORAGE_KEY, value);
}

function activeCompanyMembership() {
  return companies.find((company) => company.id === activeCompanyId) || null;
}

function storedLocationForLoadedCompany() {
  const scopedKey = activeLocationStorageKey();
  const scopedLocationId = scopedKey !== ACTIVE_LOCATION_STORAGE_KEY ? localStorage.getItem(scopedKey) : "";
  if (scopedLocationId && locations.some((location) => location.id === scopedLocationId)) {
    return scopedLocationId;
  }
  const storedLocationId = readStoredActiveLocationId();
  if (storedLocationId && locations.some((location) => location.id === storedLocationId)) {
    return storedLocationId;
  }
  if (activeLocationId && locations.some((location) => location.id === activeLocationId)) {
    return activeLocationId;
  }
  const defaultLocationId = activeCompanyMembership()?.default_location_id || "";
  if (defaultLocationId && locations.some((location) => location.id === defaultLocationId)) {
    return defaultLocationId;
  }
  return locations[0]?.id || "";
}

document.addEventListener("click", (event) => {
  const confirmPartDeleteButton = event.target.closest("[data-confirm-delete-part]");
  if (!confirmPartDeleteButton) return;
  event.preventDefault();
  deletePart(confirmPartDeleteButton.dataset.confirmDeletePart);
});

document.addEventListener("submit", (event) => {
  if (event.target?.id !== "request-form") return;
  createRequest(event);
});

init();

async function init() {
  if (!window.SUPABASE_URL || !window.SUPABASE_ANON_KEY) {
    renderAuth("login", "Supabase config is missing. Add your project URL and publishable anon key to supabase-config.js.");
    return;
  }

  if (window.SUPABASE_ANON_KEY === "PASTE_MY_PUBLISHABLE_KEY_HERE") {
    renderAuth("login", "Invalid API key: replace PASTE_MY_PUBLISHABLE_KEY_HERE in supabase-config.js with your Supabase publishable anon key.");
    return;
  }

  try {
    const recoveryParams = passwordRecoveryParamsFromHref(window.location.href);
    supabaseClient = window.supabase.createClient(window.SUPABASE_URL, window.SUPABASE_ANON_KEY);
    if (isPasswordRecoveryParams(recoveryParams)) {
      await startPasswordRecovery(recoveryParams);
      return;
    }
    const qrToken = publicRequestQrTokenFromUrl();
    if (qrToken) {
      await renderPublicRequestQrPage(qrToken);
      return;
    }
    const requestToken = publicRequestTokenFromUrl();
    if (requestToken) {
      await renderPublicRequestIntake(requestToken);
      return;
    }
    renderAuth("login");
    const { data } = await supabaseClient.auth.getSession();
    session = data.session;
  } catch (error) {
    renderAuth("login", `Supabase initialization failed: ${error.message}`);
    return;
  }

  supabaseClient.auth.onAuthStateChange((_event, nextSession) => {
    session = nextSession;
    setTimeout(() => {
      render().catch((error) => {
        appError = `Could not load workspace: ${error.message || error}`;
        if (session) renderWorkspaceLoadError(appError);
        else renderAuth("login", appError);
      });
    }, 0);
  });

  await render();
}

async function render() {
  if (!session) {
    renderAuth("login");
    return;
  }

  try {
    renderWorkspaceLoading("Checking team access...");
    const inviteError = await withOperationTimeout(
      acceptTeamInvites(),
      "Team invite check timed out.",
      5000
    ).catch((error) => error);
    if (inviteError) {
      appNotice = `Team invite check skipped: ${inviteError.message || inviteError}`;
      appNoticeTone = "warning";
    }

    renderWorkspaceLoading("Loading companies...");
    await withOperationTimeout(
      loadCompanies(),
      "Company membership load timed out. Supabase may be slow or blocking the request.",
      16000
    );
  } catch (error) {
    appError = error.message || String(error);
    renderWorkspaceLoadError(appError);
    return;
  }

  if (!companies.length || appError) {
    renderCompanyCreate();
    return;
  }

  if (!activeCompanyId || !companies.some((company) => company.id === activeCompanyId)) {
    activeCompanyId = companies[0].id;
    localStorage.setItem("maintainops.activeCompanyId", activeCompanyId);
  }

  try {
    renderWorkspaceLoading("Preparing your company profile...");
    const profileReady = await withOperationTimeout(
      ensureProfileForActiveCompany(),
      "Company profile setup timed out. Refresh and try again.",
      12000
    );
    if (!profileReady) throw new Error(appError || "Could not prepare your company profile.");

    renderWorkspaceLoading("Loading workspace data...");
    await withOperationTimeout(
      loadCompanyData(),
      "Workspace data load timed out. One of the Supabase data requests is not returning.",
      22000
    );
    renderWorkspace();
  } catch (error) {
    appError = error.message || String(error);
    renderWorkspaceLoadError(appError);
  }
}

function renderWorkspaceLoading(message) {
  document.body.classList.remove("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell">
      <div class="auth-card">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Loading Workspace</h1>
            <p>${escapeHtml(message)}</p>
          </div>
        </div>
        <p class="muted auth-status">Your login was accepted. We are loading company data now.</p>
      </div>
    </section>
  `;
}

function renderWorkspaceLoadError(message) {
  document.body.classList.remove("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell">
      <div class="auth-card">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Workspace Load Stopped</h1>
            <p>Login worked, but the workspace did not finish loading.</p>
          </div>
        </div>
        <p class="error-text">${escapeHtml(message)}</p>
        <button class="primary-button" id="retry-workspace-load" type="button">Try Again</button>
        <button class="text-button" id="auth-reset" type="button">Reset login on this browser</button>
      </div>
    </section>
  `;
  document.querySelector("#retry-workspace-load").addEventListener("click", () => render());
  document.querySelector("#auth-reset").addEventListener("click", resetLoginState);
}

function renderAuth(mode, initialError = "") {
  document.body.classList.remove("public-qr-mode");
  const isSignup = mode === "signup";
  app.innerHTML = `
    <section class="auth-shell">
      <form class="auth-card" id="auth-form">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>${isSignup ? "Create Account" : "Welcome Back"}</h1>
            <p>${isSignup ? "Start with email and password." : "Sign in to your maintenance workspace."}</p>
          </div>
        </div>
        <div class="form-grid">
          ${isSignup ? `<label>Full name<input name="fullName" required autocomplete="name"></label>` : ""}
          <label>Email<input name="email" type="email" required autocomplete="email"></label>
          <label>Password<input name="password" type="password" minlength="6" required autocomplete="${isSignup ? "new-password" : "current-password"}"></label>
        </div>
        <p class="error-text" id="auth-error">${escapeHtml(initialError)}</p>
        <p class="muted auth-status" id="auth-status"></p>
        <button class="primary-button" type="submit">${isSignup ? "Sign Up" : "Log In"}</button>
        <button class="text-button" id="auth-mode" type="button">${isSignup ? "I already have an account" : "Create an account"}</button>
        ${isSignup ? "" : `<button class="text-button" id="auth-forgot-password" type="button">Forgot password?</button>`}
        <button class="text-button" id="auth-reset" type="button">Reset login on this browser</button>
      </form>
    </section>
  `;

  document.querySelector("#auth-mode").addEventListener("click", () => renderAuth(isSignup ? "login" : "signup"));
  document.querySelector("#auth-forgot-password")?.addEventListener("click", () => renderPasswordResetRequest());
  document.querySelector("#auth-reset").addEventListener("click", resetLoginState);
  document.querySelector("#auth-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const formElement = event.target;
    const submitButton = formElement.querySelector("button[type='submit']");
    const originalButtonText = submitButton?.textContent || (isSignup ? "Sign Up" : "Log In");
    const form = new FormData(formElement);
    const email = form.get("email");
    const password = form.get("password");
    const fullName = form.get("fullName");
    const errorTarget = document.querySelector("#auth-error");
    const statusTarget = document.querySelector("#auth-status");
    errorTarget.textContent = "";
    if (statusTarget) statusTarget.textContent = "Connecting to Supabase...";

    if (submitButton) {
      submitButton.disabled = true;
      submitButton.textContent = isSignup ? "Creating..." : "Logging in...";
    }

    try {
      const response = isSignup
        ? await withOperationTimeout(
          supabaseClient.auth.signUp({ email, password, options: { data: { full_name: fullName } } }),
          "Sign up timed out. Check your connection and try again.",
          20000
        )
        : await signInWithPasswordWithFallback(email, password);

      if (response.error) {
        if (statusTarget) statusTarget.textContent = "";
        errorTarget.textContent = response.error.message;
        return;
      }

      if (isSignup && !response.data.session) {
        if (statusTarget) statusTarget.textContent = "";
        errorTarget.textContent = "Check your email to confirm your account, then log in.";
        return;
      }

      if (response.data.session) {
        if (statusTarget) statusTarget.textContent = "Login accepted. Loading workspace...";
        session = response.data.session;
        await render();
        return;
      }
      if (statusTarget) statusTarget.textContent = "";
      errorTarget.textContent = "Supabase did not return a login session. Check that email confirmation is complete, then try again.";
    } catch (error) {
      if (statusTarget) statusTarget.textContent = "";
      errorTarget.textContent = error.message || "Login failed. Please try again.";
    } finally {
      if (submitButton && document.body.contains(submitButton)) {
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
      }
    }
  });
}

function passwordRecoveryParamsFromUrl() {
  return passwordRecoveryParamsFromHref(window.location.href);
}

function passwordRecoveryParamsFromHref(href) {
  const url = new URL(href);
  const hashParams = new URLSearchParams(url.hash.replace(/^#/, ""));
  const queryParams = url.searchParams;
  return {
    type: hashParams.get("type") || queryParams.get("type") || "",
    accessToken: hashParams.get("access_token") || queryParams.get("access_token") || "",
    refreshToken: hashParams.get("refresh_token") || queryParams.get("refresh_token") || "",
  };
}

function isPasswordRecoveryUrl() {
  return isPasswordRecoveryParams(passwordRecoveryParamsFromUrl());
}

function isPasswordRecoveryParams(params) {
  return params.type === "recovery" || Boolean(params.accessToken && params.refreshToken);
}

function passwordResetRedirectUrl() {
  const url = new URL(window.location.href);
  [
    "access_token",
    "expires_at",
    "expires_in",
    "refresh_token",
    "token_type",
    "type",
    "sb",
  ].forEach((key) => url.searchParams.delete(key));
  url.hash = "";
  return url.href;
}

function clearPasswordRecoveryUrl() {
  const url = new URL(window.location.href);
  [
    "access_token",
    "expires_at",
    "expires_in",
    "refresh_token",
    "token_type",
    "type",
    "sb",
  ].forEach((key) => url.searchParams.delete(key));
  url.hash = "";
  window.history.replaceState({}, document.title, url.href);
}

async function startPasswordRecovery(params = passwordRecoveryParamsFromUrl()) {
  let ready = false;
  let initialError = "";

  if (params.accessToken && params.refreshToken) {
    const { data, error } = await supabaseClient.auth.setSession({
      access_token: params.accessToken,
      refresh_token: params.refreshToken,
    });
    ready = Boolean(data?.session && !error);
    if (error) {
      initialError = "This reset link is expired or invalid. Send a new password reset email and use the newest link.";
    }
  } else {
    initialError = "This reset link is missing the secure session. Send a new password reset email and use the newest link.";
  }

  renderPasswordRecovery({ ready, initialError });
}

function renderPasswordResetRequest(initialError = "", initialStatus = "") {
  document.body.classList.remove("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell">
      <form class="auth-card" id="password-reset-request-form">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Reset Password</h1>
            <p>Send a secure reset link to your email.</p>
          </div>
        </div>
        <div class="form-grid">
          <label>Email<input name="email" type="email" required autocomplete="email"></label>
        </div>
        <p class="error-text" id="auth-error">${escapeHtml(initialError)}</p>
        <p class="muted auth-status" id="auth-status">${escapeHtml(initialStatus)}</p>
        <button class="primary-button" type="submit">Send Reset Link</button>
        <button class="text-button" id="auth-back-to-login" type="button">Back to sign in</button>
        <button class="text-button" id="auth-reset" type="button">Reset login on this browser</button>
      </form>
    </section>
  `;

  document.querySelector("#auth-back-to-login").addEventListener("click", () => renderAuth("login"));
  document.querySelector("#auth-reset").addEventListener("click", resetLoginState);
  document.querySelector("#password-reset-request-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const formElement = event.target;
    const submitButton = formElement.querySelector("button[type='submit']");
    const errorTarget = document.querySelector("#auth-error");
    const statusTarget = document.querySelector("#auth-status");
    const email = String(new FormData(formElement).get("email") || "").trim();
    errorTarget.textContent = "";
    statusTarget.textContent = "Sending reset link...";
    submitButton.disabled = true;
    submitButton.textContent = "Sending...";

    try {
      const { error } = await withOperationTimeout(
        supabaseClient.auth.resetPasswordForEmail(email, { redirectTo: passwordResetRedirectUrl() }),
        "Password reset email timed out. Check your connection and try again.",
        20000
      );
      if (error) {
        statusTarget.textContent = "";
        errorTarget.textContent = error.message;
        return;
      }
      statusTarget.textContent = "If that email exists in Supabase, a reset link has been sent.";
    } catch (error) {
      statusTarget.textContent = "";
      errorTarget.textContent = error.message || "Could not send reset link.";
    } finally {
      if (document.body.contains(submitButton)) {
        submitButton.disabled = false;
        submitButton.textContent = "Send Reset Link";
      }
    }
  });
}

function renderPasswordRecovery({ ready = false, initialError = "" } = {}) {
  document.body.classList.remove("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell">
      <form class="auth-card" id="password-recovery-form">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Set New Password</h1>
            <p>Enter a new password for this MaintainOps login.</p>
          </div>
        </div>
        <div class="form-grid">
          <label>New password<input name="password" type="password" minlength="6" required autocomplete="new-password" ${ready ? "" : "disabled"}></label>
          <label>Confirm password<input name="confirmPassword" type="password" minlength="6" required autocomplete="new-password" ${ready ? "" : "disabled"}></label>
        </div>
        <p class="error-text" id="auth-error">${escapeHtml(initialError)}</p>
        <p class="muted auth-status" id="auth-status">${ready ? "Reset link accepted. Choose your new password." : ""}</p>
        <button class="primary-button" type="submit" ${ready ? "" : "disabled"}>Update Password</button>
        <button class="text-button" id="auth-back-to-login" type="button">Back to sign in</button>
        <button class="text-button" id="auth-send-new-reset" type="button">Send a new reset link</button>
      </form>
    </section>
  `;

  document.querySelector("#auth-back-to-login").addEventListener("click", () => {
    clearPasswordRecoveryUrl();
    renderAuth("login");
  });
  document.querySelector("#auth-send-new-reset").addEventListener("click", () => {
    clearPasswordRecoveryUrl();
    renderPasswordResetRequest();
  });
  document.querySelector("#password-recovery-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!ready) return;
    const formElement = event.target;
    const submitButton = formElement.querySelector("button[type='submit']");
    const form = new FormData(formElement);
    const password = String(form.get("password") || "");
    const confirmPassword = String(form.get("confirmPassword") || "");
    const errorTarget = document.querySelector("#auth-error");
    const statusTarget = document.querySelector("#auth-status");
    errorTarget.textContent = "";

    if (password.length < 6) {
      errorTarget.textContent = "Password must be at least 6 characters.";
      return;
    }
    if (password !== confirmPassword) {
      errorTarget.textContent = "Passwords do not match.";
      return;
    }

    statusTarget.textContent = "Updating password...";
    submitButton.disabled = true;
    submitButton.textContent = "Updating...";

    try {
      const { error } = await withOperationTimeout(
        supabaseClient.auth.updateUser({ password }),
        "Password update timed out. Try the newest reset link again.",
        20000
      );
      if (error) {
        statusTarget.textContent = "";
        errorTarget.textContent = error.message;
        return;
      }
      clearPasswordRecoveryUrl();
      const { data } = await supabaseClient.auth.getSession();
      session = data.session;
      statusTarget.textContent = session ? "Password updated. Loading workspace..." : "Password updated. Sign in with your new password.";
      if (session) {
        await render();
        return;
      }
      renderAuth("login", "Password updated. Sign in with your new password.");
    } catch (error) {
      statusTarget.textContent = "";
      errorTarget.textContent = error.message || "Could not update password.";
    } finally {
      if (document.body.contains(submitButton)) {
        submitButton.disabled = false;
        submitButton.textContent = "Update Password";
      }
    }
  });
}

async function signInWithPasswordWithFallback(email, password) {
  try {
    return await withOperationTimeout(
      supabaseClient.auth.signInWithPassword({ email, password }),
      "Login timed out. Retrying secure login...",
      12000
    );
  } catch (error) {
    if (!String(error?.message || error).includes("Retrying secure login")) throw error;
  }

  const response = await withOperationTimeout(
    fetch(`${window.SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: {
        apikey: window.SUPABASE_ANON_KEY,
        "content-type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    }),
    "Login timed out. Check your connection and try again.",
    20000
  );
  let payload = null;
  try {
    payload = await response.json();
  } catch (error) {
    payload = null;
  }
  if (!response.ok) {
    return { error: { message: payload?.error_description || payload?.msg || payload?.message || "Login failed. Check your email and password." } };
  }
  if (!payload?.access_token || !payload?.refresh_token) {
    return { error: { message: "Supabase did not return a login session. Try again." } };
  }
  return supabaseClient.auth.setSession({
    access_token: payload.access_token,
    refresh_token: payload.refresh_token,
  });
}

async function resetLoginState() {
  const statusTarget = document.querySelector("#auth-status");
  const errorTarget = document.querySelector("#auth-error");
  if (errorTarget) errorTarget.textContent = "";
  if (statusTarget) statusTarget.textContent = "Clearing saved login state...";

  try {
    if (supabaseClient) await supabaseClient.auth.signOut({ scope: "local" });
  } catch (error) {
    console.warn("Could not sign out before reset", error);
  }

  Object.keys(localStorage)
    .filter((key) => key.startsWith("maintainops.") || key.startsWith("sb-"))
    .forEach((key) => localStorage.removeItem(key));

  session = null;
  activeCompanyId = "";
  activeLocationId = "";
  appError = "";
  if (statusTarget) statusTarget.textContent = "Login reset. Try signing in again.";
  renderAuth("login", "Login reset. Try signing in again.");
}

function publicRequestTokenFromUrl() {
  const url = new URL(window.location.href);
  return String(url.searchParams.get("request") || url.searchParams.get("public_request") || "").trim();
}

function publicRequestQrTokenFromUrl() {
  const url = new URL(window.location.href);
  return String(url.searchParams.get("qr") || "").trim();
}

async function renderPublicRequestQrPage(token) {
  document.body.classList.add("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell public-request-shell qr-page-shell">
      <div class="auth-card public-qr-card">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Maintenance Request QR</h1>
            <p>Loading QR code...</p>
          </div>
        </div>
      </div>
    </section>
  `;

  let intake = null;
  try {
    const { data, error } = await withOperationTimeout(
      supabaseClient.rpc("get_public_request_intake", { request_token: token }),
      "Request QR lookup timed out."
    );
    intake = Array.isArray(data) ? data[0] : data;
    if (error || !intake) {
      renderPublicRequestError("This QR code link is inactive or invalid.");
      return;
    }
  } catch (error) {
    renderPublicRequestError("This QR code link is inactive or invalid.");
    return;
  }

  const requestUrl = publicRequestUrl(token);
  app.innerHTML = `
    <section class="auth-shell public-request-shell qr-page-shell">
      <article class="auth-card public-qr-card">
        <div class="public-qr-heading">
          <span class="brand-mark">MO</span>
          <div>
            <h1>${escapeHtml(intake.location_name)}</h1>
            <p>${escapeHtml(intake.company_name)}</p>
          </div>
        </div>
        <div class="public-qr-code">${qrSvgFor(requestUrl, 8)}</div>
        <div class="public-qr-instructions">
          <h2>Scan To Request Maintenance</h2>
          <p>Point your phone camera at this code and describe what needs attention.</p>
        </div>
        <p class="public-qr-url">${escapeHtml(requestUrl)}</p>
        <div class="button-row no-print">
          <button class="primary-button request-action-button" id="print-public-qr" type="button">Print / Save PDF</button>
          <a class="secondary-button" href="${escapeHtml(requestUrl)}" target="_blank" rel="noreferrer">Test Form</a>
        </div>
      </article>
    </section>
  `;

  document.querySelector("#print-public-qr").addEventListener("click", () => window.print());
}

async function renderPublicRequestIntake(token) {
  document.body.classList.remove("public-qr-mode");
  app.innerHTML = `
    <section class="auth-shell public-request-shell">
      <div class="auth-card public-request-card">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Maintenance Request</h1>
            <p>Loading request form...</p>
          </div>
        </div>
      </div>
    </section>
  `;

  let intake = null;
  try {
    const { data, error } = await withOperationTimeout(
      supabaseClient.rpc("get_public_request_intake", { request_token: token }),
      "Request form lookup timed out."
    );
    if (error) {
      renderPublicRequestError("This request link is not ready yet. The company needs to run the public request link setup in Supabase.");
      return;
    }
    intake = Array.isArray(data) ? data[0] : data;
  } catch (error) {
    renderPublicRequestError(error.message || "This request link could not be loaded.");
    return;
  }
  if (!intake) {
    renderPublicRequestError("This request link is inactive or invalid.");
    return;
  }

  app.innerHTML = `
    <section class="auth-shell public-request-shell">
      <form class="auth-card public-request-card" id="public-request-form">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>${escapeHtml(intake.company_name)}</h1>
            <p>${escapeHtml(intake.location_name)} maintenance request</p>
          </div>
        </div>
        <div class="form-grid">
          <label>What needs attention?<input name="title" required maxlength="140" placeholder="Short issue description"></label>
          <label>Machine / area<input name="equipment_note" maxlength="140" placeholder="Roll former 1, saw area, aisle 3"></label>
          <label>Details<textarea name="description" rows="4" maxlength="1000" placeholder="What is happening? Any noise, leak, jam, alarm, or safety concern?"></textarea></label>
          <label>Photo<input name="photo" type="file" accept="image/*" capture="environment"><small>Optional. Photos are optimized up to 2400px before upload.</small></label>
          <label>Your name<input name="requester_name" maxlength="120" placeholder="Optional"></label>
          <label>Contact<input name="requester_contact" maxlength="160" placeholder="Optional phone, radio, or email"></label>
          <label>Urgency
            <select name="priority">
              <option value="medium">Normal</option>
              <option value="high">High</option>
              <option value="critical">Critical / down</option>
              <option value="low">Low</option>
            </select>
          </label>
        </div>
        <p class="error-text" id="public-request-error"></p>
        <button class="primary-button request-action-button" type="submit">Send Request</button>
      </form>
    </section>
  `;

  document.querySelector("#public-request-form").addEventListener("submit", (event) => submitPublicRequest(event, token, intake));
}

function renderPublicRequestError(message) {
  app.innerHTML = `
    <section class="auth-shell public-request-shell">
      <div class="auth-card public-request-card">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Request Link Unavailable</h1>
            <p>${escapeHtml(message)}</p>
          </div>
        </div>
      </div>
    </section>
  `;
}

// LFES-SECURITY: Public QR intake is intentionally anonymous; all company/location authority must stay inside scoped Supabase RPCs.
async function submitPublicRequest(event, token, intake) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  const errorElement = document.querySelector("#public-request-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Sending...";
  }

  try {
    const { data: requestId, error } = await withOperationTimeout(
      supabaseClient.rpc("submit_public_location_request", {
        request_token: token,
        request_title: requiredText(form.get("title"), "Request title"),
        equipment_note: String(form.get("equipment_note") || "").trim() || null,
        request_description: String(form.get("description") || "").trim() || null,
        requester_name: String(form.get("requester_name") || "").trim() || null,
        requester_contact: String(form.get("requester_contact") || "").trim() || null,
        request_priority: form.get("priority") || "medium",
      }),
      "Request send timed out."
    );

    if (error) throw error;
    const photo = form.get("photo");
    let photoWarning = "";
    if (photo && photo.name) {
      const photoError = await addPhotoToMaintenanceRequest(requestId, photo);
      if (photoError) photoWarning = `Request sent, but the photo did not upload: ${photoError.message || photoError}`;
    }

    app.innerHTML = `
      <section class="auth-shell public-request-shell">
        <div class="auth-card public-request-card">
          <div class="brand-row">
            <span class="brand-mark">MO</span>
            <div>
              <h1>Request Sent</h1>
              <p>${escapeHtml(intake.location_name)} maintenance has received it.</p>
            </div>
          </div>
          ${photoWarning ? `<p class="error-text">${escapeHtml(photoWarning)}</p>` : ""}
          <button class="secondary-button request-action-button" id="public-request-another" type="button">Send Another Request</button>
        </div>
      </section>
    `;
    document.querySelector("#public-request-another").addEventListener("click", () => renderPublicRequestIntake(token));
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not send the request.";
  } finally {
    if (submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Send Request";
    }
  }
}

async function loadCompanies() {
  appError = "";
  const companyRpc = await getMyCompanies(supabaseClient);
  if (!companyRpc.error) {
    const seenCompanies = new Set();
    companies = (companyRpc.data || [])
      .filter((company) => {
        const key = String(company.name || "").trim().toLowerCase();
        if (seenCompanies.has(key)) return false;
        seenCompanies.add(key);
        return true;
      })
      .map((company) => ({
        id: company.id,
        name: company.name,
        logo_path: company.logo_path,
        created_at: company.created_at,
        role: normalizeRole(company.role),
        default_location_id: company.default_location_id || "",
      }));

    await loadCompanyLogoUrls();
    return;
  }

  if (!String(companyRpc.error.message || "").includes("get_my_companies")) {
    appError = `Could not load companies: ${companyRpc.error.message}`;
    companies = [];
    return;
  }

  const { data: memberships, error: membershipError } = await listUserCompanyMemberships(supabaseClient, session.user.id);

  if (membershipError && isColumnSchemaError(membershipError, ["default_location_id"])) {
    const retry = await listUserCompanyMembershipsLegacy(supabaseClient, session.user.id);
    if (!retry.error) {
      return loadCompaniesFromMembershipRows(retry.data || []);
    }
  }

  if (membershipError) {
    appError = `Could not load company memberships: ${membershipError.message}`;
    companies = [];
    return;
  }

  await loadCompaniesFromMembershipRows(memberships || []);
}

async function loadCompaniesFromMembershipRows(memberships) {
  if (!memberships.length) {
    companies = [];
    return;
  }

  const ids = memberships.map((membership) => membership.company_id);
  let { data: companyRows, error: companyError } = await listCompaniesByIds(supabaseClient, ids);

  if (companyError && isColumnSchemaError(companyError, ["logo_path"])) {
    const retry = await listCompaniesByIdsLegacy(supabaseClient, ids);
    companyRows = retry.data;
    companyError = retry.error;
  }

  if (companyError) {
    appError = `Could not load companies: ${companyError.message}`;
    companies = [];
    return;
  }

  const seenCompanies = new Set();
  companies = companyRows
    .filter((company) => {
      const key = company.name.trim().toLowerCase();
      if (seenCompanies.has(key)) return false;
      seenCompanies.add(key);
      return true;
    })
    .map((company) => ({
      ...company,
      role: normalizeRole(memberships.find((membership) => membership.company_id === company.id)?.role),
      default_location_id: memberships.find((membership) => membership.company_id === company.id)?.default_location_id || "",
    }));

  await loadCompanyLogoUrls();
}

async function loadCompanyLogoUrls() {
  await Promise.all(companies.map(async (company) => {
    company.logoUrl = "";
    company.logoError = "";
    if (!company.logo_path) return;
    const { data, error } = await supabaseClient.storage
      .from("company-logos")
      .createSignedUrl(company.logo_path, 60 * 10);
    if (error) {
      company.logoError = error.message;
      return;
    }
    company.logoUrl = data?.signedUrl || "";
  }));
}

function renderCompanyCreate() {
  app.innerHTML = `
    <section class="auth-shell">
      <form class="auth-card" id="company-form">
        <div class="brand-row">
          <span class="brand-mark">MO</span>
          <div>
            <h1>Create Company</h1>
            <p>Your shared maintenance data will live inside this company.</p>
          </div>
        </div>
        <label>Company name<input name="name" required placeholder="North Plant Operations"></label>
        <p class="error-text" id="company-error">${escapeHtml(appError)}</p>
        <button class="primary-button" type="submit">Create Company</button>
        <button class="text-button" type="button" id="sign-out">Sign out</button>
      </form>
    </section>
  `;

  document.querySelector("#company-form").addEventListener("submit", createCompany);
  document.querySelector("#sign-out").addEventListener("click", () => supabaseClient.auth.signOut());
}

async function createCompany(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#company-error");
  const name = String(new FormData(formElement).get("name") || "").trim();
  submitButton.disabled = true;
  submitButton.textContent = "Creating...";
  errorTarget.textContent = "";

  try {
    if (!name) throw new Error("Company name is required.");
    const existing = companies.find((company) => company.name.trim().toLowerCase() === name.trim().toLowerCase());
    if (existing) {
      activeCompanyId = existing.id;
      localStorage.setItem("maintainops.activeCompanyId", activeCompanyId);
      await render();
      return;
    }

    const { data, error } = await withOperationTimeout(
      supabaseClient.rpc("create_company", { company_name: name }),
      "Company creation timed out."
    );

    if (error) {
      errorTarget.textContent = error.message.includes("create_company")
        ? "Database setup is not finished. Run supabase/schema.sql in the Supabase SQL editor, then wait a few seconds and try again."
        : error.message;
      return;
    }

    activeCompanyId = data;
    localStorage.setItem("maintainops.activeCompanyId", activeCompanyId);
    const profileReady = await ensureProfileForActiveCompany(name);
    if (!profileReady) throw new Error(appError || "Could not create your company profile.");
    await seedStarterAssets();
    await render();
  } catch (error) {
    errorTarget.textContent = error.message || "Could not create company.";
  } finally {
    if (submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Create Company";
    }
  }
}

async function ensureProfileForActiveCompany() {
  const { error } = await withOperationTimeout(
    supabaseClient.rpc("ensure_company_profile", {
      target_company_id: activeCompanyId,
    }),
    "Profile setup timed out."
  );

  if (error) {
    appError = `Could not create your company profile: ${error.message}`;
    return false;
  }
  return true;
}

async function acceptTeamInvites() {
  if (!teamInvitesReady) return;
  const { error } = await supabaseClient.rpc("accept_company_invites");
  if (error && (error.message.includes("accept_company_invites") || isColumnSchemaError(error, ["company_invites"]))) {
    teamInvitesReady = false;
  }
}

async function seedStarterAssets() {
  const locationId = activeLocationDatabaseId();
  await withOperationTimeout(
    supabaseClient.from("assets").insert([
      { company_id: activeCompanyId, location_id: locationId, name: "Packaging Line 2", asset_code: "PKG-002", location: "Plant A / Floor 1", status: "running" },
      { company_id: activeCompanyId, location_id: locationId, name: "Boiler Room Pump", asset_code: "BLR-P-014", location: "Utilities / Boiler Room", status: "watch" },
    ]),
    "Starter equipment setup timed out."
  );
}

const WORK_ORDER_RELATION_SELECT = "*, assets(name, location_id), locations!work_orders_company_location_fkey(name), assigned_profile:profiles!work_orders_company_assigned_profile_fkey(full_name)";
const WORK_ORDER_FALLBACK_SELECT = "*, assets(name), assigned_profile:profiles!work_orders_company_assigned_profile_fkey(full_name)";

async function loadServerWorkOrderSlice() {
  await refreshWorkOrderRelatedSearch();
  const [pageResponse, dashboardCounts, myCounts] = await Promise.all([
    fetchWorkOrderPage(),
    loadWorkOrderDashboardCounts(),
    loadMyWorkDashboardCounts(),
  ]);

  if (pageResponse.error && isColumnSchemaError(pageResponse.error, ["location_id", "locations"])) {
    const fallbackResponse = await fetchWorkOrderPage({ includeLocationRelation: false });
    workOrders = fallbackResponse.data || [];
    workOrderServerTotal = fallbackResponse.count ?? workOrders.length;
    workOrderDashboardCounts = dashboardCounts;
    myWorkDashboardCounts = myCounts;
    return fallbackResponse;
  }

  workOrders = pageResponse.data || [];
  workOrderServerTotal = pageResponse.count ?? workOrders.length;
  workOrderDashboardCounts = dashboardCounts;
  myWorkDashboardCounts = myCounts;
  return pageResponse;
}

const REQUEST_RELATION_SELECT = "*, assets(name, location_id), locations(name)";
const REQUEST_ASSET_FALLBACK_SELECT = "*, assets(name)";
const REQUEST_FALLBACK_SELECT = "*";

async function loadServerRequestSlice() {
  const activeFilter = requestViewFilter || "active";
  const [pageResponse, counts] = await Promise.all([
    fetchRequestPage(activeFilter),
    loadRequestDashboardCounts(),
  ]);

  maintenanceRequests = pageResponse.data || [];
  requestServerTotal = pageResponse.count ?? maintenanceRequests.length;
  requestDashboardCounts = counts;

  return pageResponse;
}

async function fetchRequestPage(filter = requestViewFilter, options = {}) {
  const page = Math.max(1, requestsPage);
  const from = (page - 1) * LIST_ITEMS_PER_PAGE;
  const to = from + LIST_ITEMS_PER_PAGE - 1;
  const selectClause = options.includeRelations === false
    ? REQUEST_FALLBACK_SELECT
    : options.includeLocationRelation === false
      ? REQUEST_ASSET_FALLBACK_SELECT
      : REQUEST_RELATION_SELECT;

  const response = await applyRequestQueryFilters(
    supabaseClient
      .from("maintenance_requests")
      .select(selectClause, { count: "exact" }),
    filter
  )
    .order("created_at", { ascending: false })
    .range(from, to);

  if (response.error && options.includeLocationRelation !== false && isColumnSchemaError(response.error, ["location_id", "locations"])) {
    return fetchRequestPage(filter, { includeLocationRelation: false });
  }
  if (response.error && options.includeRelations !== false) {
    return fetchRequestPage(filter, { includeRelations: false });
  }
  if (!response.error && response.count && page > 1 && from >= response.count) {
    requestsPage = Math.max(1, Math.ceil(response.count / LIST_ITEMS_PER_PAGE));
    localStorage.setItem("maintainops.requestsPage", String(requestsPage));
    return fetchRequestPage(filter, options);
  }
  return response;
}

async function loadRequestDashboardCounts() {
  const [active, converted, all] = await Promise.all([
    countRequests("active"),
    countRequests("converted"),
    countRequests("all"),
  ]);
  return { active, converted, all };
}

async function countRequests(filter) {
  const response = await applyRequestQueryFilters(
    supabaseClient
      .from("maintenance_requests")
      .select("id", { count: "exact", head: true }),
    filter
  );
  if (response.error) {
    console.warn("Request count failed", response.error);
    return 0;
  }
  return response.count || 0;
}

function applyRequestQueryFilters(query, filter = requestViewFilter) {
  let nextQuery = query.eq("company_id", activeCompanyId);
  if (locationsReady && activeLocationId) nextQuery = nextQuery.eq("location_id", activeLocationId);

  if (filter === "converted") {
    nextQuery = nextQuery.or("status.eq.converted,converted_work_order_id.not.is.null");
  } else if (filter !== "all") {
    nextQuery = nextQuery.eq("status", "submitted").is("converted_work_order_id", null);
  }

  const term = postgrestSearchTerm(searchQuery);
  if (term) {
    const pattern = `%${term}%`;
    const matchedAssetIds = assets
      .filter(matchesActiveLocation)
      .filter((asset) => matchesQuery([
        asset.name,
        asset.asset_code,
        asset.location,
        asset.status,
        asset.asset_type,
        parentAssetFor(asset)?.name,
      ], term))
      .map((asset) => asset.id)
      .slice(0, SEARCH_ID_PAGE_SIZE);
    nextQuery = nextQuery.or([
      `title.ilike.${pattern}`,
      `description.ilike.${pattern}`,
      `status.ilike.${pattern}`,
      `priority.ilike.${pattern}`,
      `requested_by_name.ilike.${pattern}`,
      `requested_by_contact.ilike.${pattern}`,
      ...(matchedAssetIds.length ? [`asset_id.in.(${matchedAssetIds.join(",")})`] : []),
    ].join(","));
  }

  return nextQuery;
}

async function refreshWorkOrderRelatedSearch() {
  const query = searchQuery.trim();
  if (!query || workOrderSearchMode) {
    workOrderRelatedSearch = { assetIds: [], workOrderIds: [], procedureIds: [] };
    return;
  }

  const matchedAssets = assets
    .filter(matchesActiveLocation)
    .filter((asset) => matchesQuery([
      asset.name,
      asset.asset_code,
      asset.location,
      asset.status,
      asset.asset_type,
      parentAssetFor(asset)?.name,
    ], query))
    .map((asset) => asset.id);

  const matchedProcedures = procedureTemplates
    .filter((template) => matchesQuery([
      template.name,
      template.description,
      ...(template.procedure_steps || []).map((step) => step.prompt),
    ], query))
    .map((template) => template.id);

  const matchedPartIds = parts
    .filter(matchesActiveLocation)
    .filter((part) => matchesQuery([
      part.name,
      part.sku,
      part.supplier_name,
      part.quantity_on_hand,
      part.reorder_point,
      part.unit_cost,
    ], query))
    .map((part) => part.id);

  const workOrderIds = new Set();
  await Promise.all([
    addRelatedWorkOrderIdsFromParts(workOrderIds, matchedPartIds),
    addRelatedWorkOrderIdsFromTable(workOrderIds, "work_order_comments", ["body"], query),
    addRelatedWorkOrderIdsFromTable(workOrderIds, "work_order_events", ["event_type", "summary"], query),
    addRelatedWorkOrderIdsFromTable(workOrderIds, "work_order_photos", ["file_name"], query),
    addRelatedWorkOrderIdsFromTable(workOrderIds, "work_order_step_results", ["value"], query),
  ]);

  workOrderRelatedSearch = {
    assetIds: matchedAssets.slice(0, 200),
    procedureIds: matchedProcedures.slice(0, 200),
    workOrderIds: [...workOrderIds].slice(0, 300),
  };
}

async function addRelatedWorkOrderIdsFromParts(target, partIds, options = {}) {
  if (!partIds.length) return;
  const maxRows = options.maxRows ?? 300;
  let remaining = maxRows;
  for (const chunk of chunkArray(partIds, SEARCH_ID_CHUNK_SIZE)) {
    if (remaining <= 0) break;
    try {
      await fetchPagedSearchRows(
        () => supabaseClient
          .from("work_order_parts")
          .select("work_order_id")
          .eq("company_id", activeCompanyId)
          .in("part_id", chunk),
        (rows) => {
          rows.forEach((row) => {
            if (row.work_order_id) target.add(row.work_order_id);
          });
          remaining -= rows.length;
        },
        remaining
      );
    } catch (error) {
      console.warn("Part-linked work order search failed", error);
      return;
    }
  }
}

async function addRelatedWorkOrderIdsFromTable(target, tableName, columns, query, options = {}) {
  const term = postgrestSearchTerm(query);
  if (!term) return;
  const orClause = columns.map((column) => `${column}.ilike.%${term}%`).join(",");
  const maxRows = options.maxRows ?? 300;
  try {
    await fetchPagedSearchRows(
      () => supabaseClient
        .from(tableName)
        .select("work_order_id")
        .eq("company_id", activeCompanyId)
        .or(orClause),
      (rows) => {
        rows.forEach((row) => {
          if (row.work_order_id) target.add(row.work_order_id);
        });
      },
      maxRows
    );
  } catch (error) {
    console.warn(`${tableName} work order search failed`, error);
  }
}

async function fetchWorkOrderPage(options = {}) {
  if (workOrderSearchMode && searchQuery.trim()) {
    return fetchExactSearchedWorkOrderPage(options);
  }

  const page = Math.max(1, workOrderPage);
  const from = (page - 1) * WORK_ORDERS_PER_PAGE;
  const to = from + WORK_ORDERS_PER_PAGE - 1;
  const selectClause = options.includeLocationRelation === false ? WORK_ORDER_FALLBACK_SELECT : WORK_ORDER_RELATION_SELECT;
  const response = await applyWorkOrderListFilters(
    selectWorkOrders(supabaseClient, selectClause, { count: "exact" })
  )
    .range(from, to);

  if (!response.error && response.count && page > 1 && from >= response.count) {
    workOrderPage = Math.max(1, Math.ceil(response.count / WORK_ORDERS_PER_PAGE));
    localStorage.setItem("maintainops.workOrderPage", String(workOrderPage));
    return fetchWorkOrderPage(options);
  }

  return response;
}

async function fetchExactSearchedWorkOrderPage(options = {}) {
  const rows = await exactWorkOrderSearchRows();
  const total = rows.length;
  const totalPages = Math.max(1, Math.ceil(total / WORK_ORDERS_PER_PAGE));
  if (workOrderPage > totalPages) {
    workOrderPage = totalPages;
    localStorage.setItem("maintainops.workOrderPage", String(workOrderPage));
  }
  if (workOrderPage < 1) {
    workOrderPage = 1;
    localStorage.setItem("maintainops.workOrderPage", String(workOrderPage));
  }

  const from = (workOrderPage - 1) * WORK_ORDERS_PER_PAGE;
  const pageIds = rows.slice(from, from + WORK_ORDERS_PER_PAGE).map((row) => row.id);
  if (!pageIds.length) return { data: [], error: null, count: total };

  const selectClause = options.includeLocationRelation === false ? WORK_ORDER_FALLBACK_SELECT : WORK_ORDER_RELATION_SELECT;
  const response = await fetchWorkOrdersByIds(supabaseClient, {
    companyId: activeCompanyId,
    locationId: activeLocationId,
    locationsReady,
    selectClause,
    ids: pageIds,
  });
  if (response.error) return response;
  const byId = new Map((response.data || []).map((workOrder) => [workOrder.id, workOrder]));
  return {
    ...response,
    data: pageIds.map((id) => byId.get(id)).filter(Boolean),
    count: total,
  };
}

async function exactWorkOrderSearchRows() {
  const key = [
    activeCompanyId || "",
    locationsReady ? activeLocationId || "" : "all-locations",
    workSort,
    searchQuery.trim().toLowerCase(),
  ].join("|");
  if (exactWorkOrderSearchCache.key === key) return exactWorkOrderSearchCache.rows;

  const query = searchQuery.trim();
  const rowMap = new Map();
  await addDirectWorkOrderSearchRows(rowMap, query);

  const matchedAssets = assets
    .filter(matchesActiveLocation)
    .filter((asset) => matchesQuery([
      asset.name,
      asset.asset_code,
      asset.location,
      asset.status,
      asset.asset_type,
      parentAssetFor(asset)?.name,
    ], query))
    .map((asset) => asset.id);

  const matchedProcedures = procedureTemplates
    .filter((template) => matchesQuery([
      template.name,
      template.description,
      ...(template.procedure_steps || []).map((step) => step.prompt),
    ], query))
    .map((template) => template.id);

  const matchedPartIds = parts
    .filter(matchesActiveLocation)
    .filter((part) => matchesQuery([
      part.name,
      part.sku,
      part.supplier_name,
      part.quantity_on_hand,
      part.reorder_point,
      part.unit_cost,
    ], query))
    .map((part) => part.id);

  await Promise.all([
    addWorkOrderSearchRowsByColumn(rowMap, "asset_id", matchedAssets),
    addWorkOrderSearchRowsByColumn(rowMap, "procedure_template_id", matchedProcedures),
  ]);

  const relatedIds = new Set();
  await Promise.all([
    addRelatedWorkOrderIdsFromParts(relatedIds, matchedPartIds, { maxRows: Infinity }),
    addRelatedWorkOrderIdsFromTable(relatedIds, "work_order_comments", ["body"], query, { maxRows: Infinity }),
    addRelatedWorkOrderIdsFromTable(relatedIds, "work_order_events", ["event_type", "summary"], query, { maxRows: Infinity }),
    addRelatedWorkOrderIdsFromTable(relatedIds, "work_order_photos", ["file_name"], query, { maxRows: Infinity }),
    addRelatedWorkOrderIdsFromTable(relatedIds, "work_order_step_results", ["value"], query, { maxRows: Infinity }),
  ]);
  await addWorkOrderSearchRowsByIds(rowMap, [...relatedIds]);

  const rows = [...rowMap.values()].sort(compareWorkOrders);
  exactWorkOrderSearchCache = { key, rows };
  return rows;
}

async function addDirectWorkOrderSearchRows(target, query) {
  const term = postgrestSearchTerm(query);
  if (!term) return;
  const orClause = [
    "title",
    "description",
    "priority",
    "type",
    "status",
    "failure_cause",
    "resolution_summary",
    "completion_notes",
  ].map((column) => `${column}.ilike.%${term}%`).join(",");

  await fetchPagedSearchRows(
    () => scopedWorkOrderSearchQuery().or(orClause),
    (rows) => addWorkOrderSearchRows(target, rows)
  );
}

async function addWorkOrderSearchRowsByColumn(target, column, values) {
  if (!values.length) return;
  for (const chunk of chunkArray(values, SEARCH_ID_CHUNK_SIZE)) {
    await fetchPagedSearchRows(
      () => scopedWorkOrderSearchQuery().in(column, chunk),
      (rows) => addWorkOrderSearchRows(target, rows)
    );
  }
}

async function addWorkOrderSearchRowsByIds(target, ids) {
  if (!ids.length) return;
  for (const chunk of chunkArray(ids, SEARCH_ID_CHUNK_SIZE)) {
    await fetchPagedSearchRows(
      () => scopedWorkOrderSearchQuery().in("id", chunk),
      (rows) => addWorkOrderSearchRows(target, rows)
    );
  }
}

function scopedWorkOrderSearchQuery() {
  return buildScopedWorkOrderSearchQuery(supabaseClient, {
    companyId: activeCompanyId,
    locationId: activeLocationId,
    locationsReady,
  });
}

function addWorkOrderSearchRows(target, rows) {
  (rows || []).forEach((row) => {
    if (!row?.id) return;
    target.set(row.id, { ...(target.get(row.id) || {}), ...row });
  });
}

async function loadWorkOrderDashboardCounts() {
  const [activeWork, newWork, inProgress, blocked, overdue, completedMonth, completedWeek] = await Promise.all([
    countWorkOrders({ statusFilter: "active", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "open", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "in_progress", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "blocked", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "overdue", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "completed_month", includeQueue: false, includeSearch: false }),
    countWorkOrders({ statusFilter: "completed_week", includeQueue: false, includeSearch: false }),
  ]);
  return { activeWork, newWork, inProgress, blocked, overdue, completedMonth, completedWeek };
}

async function loadMyWorkDashboardCounts() {
  const [activeWork, newWork, inProgress, blocked, overdue, completedMonth, completedWeek] = await Promise.all([
    countWorkOrders({ statusFilter: "active", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "open", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "in_progress", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "blocked", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "overdue", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "completed_month", section: "mywork", includeQueue: true, includeSearch: true }),
    countWorkOrders({ statusFilter: "completed_week", section: "mywork", includeQueue: true, includeSearch: true }),
  ]);
  return { activeWork, newWork, inProgress, blocked, overdue, completedMonth, completedWeek };
}

async function countWorkOrders(options = {}) {
  const response = await applyWorkOrderFilters(countWorkOrdersQuery(supabaseClient), options);
  if (response.error) {
    console.warn("Work order count failed", response.error);
    return 0;
  }
  return response.count || 0;
}

function applyWorkOrderListFilters(query) {
  const isGlobalSearch = Boolean(searchQuery.trim());
  const statusFilter = isGlobalSearch
    ? "__any__"
    : activeSection === "work" && activeStatusFilter === "requests"
      ? "__none__"
      : activeStatusFilter;
  return applyWorkOrderSort(applyWorkOrderFilters(query, {
    statusFilter,
    section: activeSection,
    includeQueue: !isGlobalSearch,
    includeSearch: true,
  }));
}

function applyWorkOrderFilters(query, options = {}) {
  let nextQuery = query.eq("company_id", activeCompanyId);
  if (locationsReady && activeLocationId) nextQuery = nextQuery.eq("location_id", activeLocationId);

  if (options.includeQueue !== false) {
    nextQuery = applyWorkOrderQueueFilters(nextQuery, options.section || activeSection);
  }

  nextQuery = applyWorkOrderStatusFilter(nextQuery, options.statusFilter || activeStatusFilter);

  if (options.includeSearch !== false) {
    const term = postgrestSearchTerm(searchQuery);
    if (term) {
      const searchClauses = [
        `title.ilike.%${term}%`,
        `description.ilike.%${term}%`,
        `priority.ilike.%${term}%`,
        `type.ilike.%${term}%`,
        `status.ilike.%${term}%`,
        ...(workOrderRelatedSearch.assetIds.length ? [`asset_id.in.(${workOrderRelatedSearch.assetIds.join(",")})`] : []),
        ...(workOrderRelatedSearch.procedureIds.length ? [`procedure_template_id.in.(${workOrderRelatedSearch.procedureIds.join(",")})`] : []),
        ...(workOrderRelatedSearch.workOrderIds.length ? [`id.in.(${workOrderRelatedSearch.workOrderIds.join(",")})`] : []),
      ];
      nextQuery = nextQuery.or(searchClauses.join(","));
    }
  }

  return nextQuery;
}

function applyWorkOrderQueueFilters(query, section) {
  if (section === "mywork") {
    return myWorkFilter === "created"
      ? query.eq("created_by", session.user.id)
      : query.eq("assigned_to", session.user.id);
  }

  if (section !== "work") return query;
  if (workOrderAssigneeFilter) return query.eq("assigned_to", workOrderAssigneeFilter);
  if (workOrderFilter === "assigned") return query.not("assigned_to", "is", null);
  if (workOrderFilter === "vendor") return query.ilike("description", `%${OUTSIDE_VENDOR_NOTE}%`);
  if (workOrderFilter === "unassigned") {
    return query
      .is("assigned_to", null)
      .not("description", "ilike", `%${OUTSIDE_VENDOR_NOTE}%`);
  }
  return query;
}

function applyWorkOrderStatusFilter(query, statusFilter) {
  const today = isoDate(startOfToday());
  if (statusFilter === "__any__") return query;
  if (statusFilter === "__none__") return query.eq("id", "00000000-0000-0000-0000-000000000000");
  if (statusFilter === "overdue") return query.neq("status", "completed").lt("due_at", today);
  if (statusFilter === "completed_month") return query.gte("completed_at", isoDateTime(monthStartDate()));
  if (statusFilter === "completed_week") return query.gte("completed_at", isoDateTime(daysAgoDate(7)));
  if (statusFilter === "active" || statusFilter === "all") return query.neq("status", "completed");
  return query.eq("status", statusFilter);
}

function applyWorkOrderSort(query) {
  if (["completed", "completed_month", "completed_week"].includes(activeStatusFilter)) {
    return query
      .order("completed_at", { ascending: false, nullsFirst: false })
      .order("created_at", { ascending: false });
  }

  if (workSort === "due") {
    return query
      .order("due_at", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });
  }

  if (workSort === "priority") {
    return query
      .order("priority", { ascending: true })
      .order("due_at", { ascending: true, nullsFirst: false })
      .order("created_at", { ascending: false });
  }

  return query.order("created_at", { ascending: false });
}

async function loadCompanyData() {
  let [locationResponse, assetResponse, scheduleResponse, partsResponse, procedureResponse, issueReportResponse] = await Promise.all([
    listLocations(supabaseClient, activeCompanyId),
    listAssets(supabaseClient, activeCompanyId),
    supabaseClient
      .from("preventive_schedules")
      .select("*, assets(name, location_id)")
      .eq("company_id", activeCompanyId)
      .order("next_due_at", { ascending: true }),
    listParts(supabaseClient, activeCompanyId),
    supabaseClient
      .from("procedure_templates")
      .select("*, procedure_steps(*)")
      .eq("company_id", activeCompanyId)
      .order("name"),
    listAppIssueReports(supabaseClient, activeCompanyId),
  ]);

  locationsReady = !locationResponse.error;
  locations = locationResponse.error ? [] : (locationResponse.data || []);
  activeLocationId = storedLocationForLoadedCompany();
  persistActiveLocationId(activeLocationId);
  assets = assetResponse.data || [];
  preventiveSchedules = scheduleResponse.error ? [] : (scheduleResponse.data || []);
  parts = partsResponse.error ? [] : (partsResponse.data || []);
  appIssueReportsReady = !issueReportResponse.error;
  appIssueReports = issueReportResponse.error ? [] : (issueReportResponse.data || []);
  procedureTemplates = procedureResponse.error ? [] : (procedureResponse.data || []).map((template) => ({
    ...template,
    procedure_steps: (template.procedure_steps || []).sort((a, b) => Number(a.position) - Number(b.position)),
  }));
  const workOrderResponse = await loadServerWorkOrderSlice();
  const requestResponse = await loadServerRequestSlice();
  if (activeWorkOrderId && !workOrders.some((workOrder) => workOrder.id === activeWorkOrderId)) {
    const activeResponse = await fetchWorkOrderById(supabaseClient, activeCompanyId, activeWorkOrderId, WORK_ORDER_RELATION_SELECT);
    if (!activeResponse.error && activeResponse.data) {
      workOrders = [activeResponse.data, ...workOrders];
    }
  }
  requestsReady = !requestResponse.error;
  partCostsReady = !parts.length || Object.prototype.hasOwnProperty.call(parts[0], "unit_cost");
  partSuppliersReady = !parts.length || Object.prototype.hasOwnProperty.call(parts[0], "supplier_name");
  schedulesReady = !scheduleResponse.error;
  outcomesReady = !workOrders.length || Object.prototype.hasOwnProperty.call(workOrders[0], "resolution_summary");
  safetyChecksReady = !workOrders.length || Object.prototype.hasOwnProperty.call(workOrders[0], "safety_devices_checked");
  proceduresReady = !procedureResponse.error;
  await Promise.all([loadProfiles(), loadMembers(), loadMessageCenter(), loadPublicRequestLinks(), addSignedRequestPhotoUrls(), loadComments(), loadPhotos(), loadPartsUsed(), loadPartDocuments(), loadStepResults(), loadWorkOrderEvents()]);
}

async function reloadWorkOrderQueue() {
  try {
    const response = await loadServerWorkOrderSlice();
    if (response.error) {
      showNotice(`Could not load work orders: ${response.error.message}`, "warning");
      return;
    }
    await Promise.all([loadComments(), loadPhotos(), loadPartsUsed(), loadStepResults(), loadWorkOrderEvents()]);
    renderWorkspace();
  } catch (error) {
    showNotice(`Could not load work orders: ${error.message || error}`, "warning");
  }
}

async function reloadRequestQueue() {
  try {
    const response = await loadServerRequestSlice();
    requestsReady = !response.error;
    if (response.error) {
      showNotice(`Could not load requests: ${response.error.message}`, "warning");
      return;
    }
    await addSignedRequestPhotoUrls();
    renderWorkspace();
  } catch (error) {
    requestsReady = false;
    showNotice(`Could not load requests: ${error.message || error}`, "warning");
  }
}

async function loadProfiles() {
  const { data } = await listProfiles(supabaseClient, activeCompanyId);

  profilesByUserId = (data || []).reduce((profiles, profile) => {
    profiles[profile.user_id] = profile;
    return profiles;
  }, {});
}

async function loadMembers() {
  const { data } = await listCompanyMembers(supabaseClient, activeCompanyId);

  companyMembers = data || [];
  await loadTeamInvites();
}

async function loadTeamInvites() {
  if (!teamInvitesReady) {
    teamInvites = [];
    return;
  }
  const { data, error } = await listTeamInvites(supabaseClient, activeCompanyId);

  if (error) {
    if (isColumnSchemaError(error, ["default_location_id"])) {
      const retry = await listTeamInvitesLegacy(supabaseClient, activeCompanyId);
      teamInvites = retry.error ? [] : (retry.data || []);
      if (retry.error && (isColumnSchemaError(retry.error, ["company_invites"]) || retry.error.message.includes("company_invites"))) {
        teamInvitesReady = false;
      }
      return;
    }
    if (isColumnSchemaError(error, ["company_invites"]) || error.message.includes("company_invites")) {
      teamInvitesReady = false;
      teamInvites = [];
      return;
    }
    teamInvites = [];
    return;
  }

  teamInvites = data || [];
}

async function loadMessageCenter() {
  messagesReady = true;
  messageThreads = [];
  messageThreadMembers = [];
  messagesByThreadId = {};
  messageReadsByThreadId = {};

  const { data: threads, error: threadError } = await supabaseClient
    .from("message_threads")
    .select("*")
    .eq("company_id", activeCompanyId)
    .order("updated_at", { ascending: false });

  if (threadError) {
    messagesReady = false;
    return;
  }

  messageThreads = threads || [];
  if (!messageThreads.length) {
    activeMessageThreadId = "";
    localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
    return;
  }

  const threadIds = messageThreads.map((thread) => thread.id);
  const [memberResponse, messageResponse, readResponse] = await Promise.all([
    supabaseClient
      .from("message_thread_members")
      .select("*")
      .eq("company_id", activeCompanyId)
      .in("thread_id", threadIds),
    supabaseClient
      .from("messages")
      .select("*")
      .eq("company_id", activeCompanyId)
      .in("thread_id", threadIds)
      .order("created_at", { ascending: true }),
    supabaseClient
      .from("message_reads")
      .select("*")
      .eq("company_id", activeCompanyId)
      .eq("user_id", session.user.id)
      .in("thread_id", threadIds),
  ]);

  if (memberResponse.error || messageResponse.error || readResponse.error) {
    messagesReady = false;
    return;
  }

  messageThreadMembers = memberResponse.data || [];
  messagesByThreadId = (messageResponse.data || []).reduce((groups, message) => {
    if (!groups[message.thread_id]) groups[message.thread_id] = [];
    groups[message.thread_id].push(message);
    return groups;
  }, {});
  messageReadsByThreadId = (readResponse.data || []).reduce((reads, read) => {
    reads[read.thread_id] = read;
    return reads;
  }, {});

  if (!activeMessageThreadId || !messageThreads.some((thread) => thread.id === activeMessageThreadId)) {
    activeMessageThreadId = messageThreads[0]?.id || "";
    localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
  }
}

async function loadPublicRequestLinks() {
  publicRequestLinks = [];
  publicRequestLinksReady = true;
  if (!requestsReady || !locationsReady) return;

  const { data, error } = await supabaseClient
    .from("public_request_links")
    .select("*")
    .eq("company_id", activeCompanyId)
    .order("created_at", { ascending: true });

  if (error) {
    publicRequestLinksReady = false;
    publicRequestLinks = [];
    return;
  }

  publicRequestLinks = data || [];
}

async function loadComments() {
  commentsError = "";
  if (!workOrders.length) {
    commentsByWorkOrder = {};
    return;
  }

  const ids = workOrders.map((workOrder) => workOrder.id);
  const { data, error } = await supabaseClient
    .from("work_order_comments")
    .select("*")
    .eq("company_id", activeCompanyId)
    .in("work_order_id", ids)
    .order("created_at", { ascending: true });

  if (error) {
    commentsByWorkOrder = {};
    commentsError = `Could not load comments: ${error.message}`;
    return;
  }

  commentsByWorkOrder = (data || []).reduce((groups, comment) => {
    groups[comment.work_order_id] ||= [];
    groups[comment.work_order_id].push(comment);
    return groups;
  }, {});
}

async function loadPhotos() {
  if (!workOrders.length) {
    photosByWorkOrder = {};
    return;
  }

  const ids = workOrders.map((workOrder) => workOrder.id);
  const { data, error } = await supabaseClient
    .from("work_order_photos")
    .select("*")
    .eq("company_id", activeCompanyId)
    .in("work_order_id", ids)
    .order("created_at", { ascending: false });

  if (error) {
    photosReady = false;
    photosByWorkOrder = {};
    return;
  }
  photosReady = true;

  photosByWorkOrder = (data || []).reduce((groups, photo) => {
    groups[photo.work_order_id] ||= [];
    groups[photo.work_order_id].push(photo);
    return groups;
  }, {});

  await addSignedPhotoUrls();
}

async function loadPartsUsed() {
  if (!workOrders.length) {
    partsUsedByWorkOrder = {};
    return;
  }

  const ids = workOrders.map((workOrder) => workOrder.id);
  const { data } = await supabaseClient
    .from("work_order_parts")
    .select("*, parts(*)")
    .eq("company_id", activeCompanyId)
    .in("work_order_id", ids)
    .order("created_at", { ascending: true });

  partsUsedByWorkOrder = (data || []).reduce((groups, row) => {
    groups[row.work_order_id] ||= [];
    groups[row.work_order_id].push(row);
    return groups;
  }, {});
}

async function loadPartDocuments() {
  if (!parts.length) {
    partDocumentsByPartId = {};
    partDocumentsReady = true;
    return;
  }

  const ids = parts.map((part) => part.id);
  const { data, error } = await supabaseClient
    .from("part_documents")
    .select("*")
    .eq("company_id", activeCompanyId)
    .in("part_id", ids)
    .order("created_at", { ascending: false });

  if (error) {
    partDocumentsReady = false;
    partDocumentsByPartId = {};
    return;
  }

  partDocumentsReady = true;
  partDocumentsByPartId = (data || []).reduce((groups, document) => {
    groups[document.part_id] ||= [];
    groups[document.part_id].push(document);
    return groups;
  }, {});

  await addSignedPartDocumentUrls();
}

async function loadWorkOrderEvents() {
  if (!workOrders.length) {
    eventsByWorkOrder = {};
    return;
  }

  const ids = workOrders.map((workOrder) => workOrder.id);
  const { data } = await supabaseClient
    .from("work_order_events")
    .select("*")
    .eq("company_id", activeCompanyId)
    .in("work_order_id", ids)
    .order("created_at", { ascending: false });

  if (!data) {
    eventsByWorkOrder = {};
    return;
  }

  eventsByWorkOrder = (data || []).reduce((groups, event) => {
    groups[event.work_order_id] ||= [];
    groups[event.work_order_id].push(event);
    return groups;
  }, {});
}

async function loadStepResults() {
  if (!workOrders.length) {
    stepResultsByWorkOrder = {};
    return;
  }

  const ids = workOrders.map((workOrder) => workOrder.id);
  const { data } = await supabaseClient
    .from("work_order_step_results")
    .select("*")
    .eq("company_id", activeCompanyId)
    .in("work_order_id", ids);

  stepResultsByWorkOrder = (data || []).reduce((groups, result) => {
    groups[result.work_order_id] ||= {};
    groups[result.work_order_id][result.procedure_step_id] = result;
    return groups;
  }, {});
}

async function addSignedPhotoUrls() {
  const photos = Object.values(photosByWorkOrder).flat();
  await Promise.all(photos.map(async (photo) => {
    const { data } = await supabaseClient.storage
      .from("work-order-photos")
      .createSignedUrl(photo.storage_path, 60 * 10);
    photo.signedUrl = data?.signedUrl || "";
  }));
}

async function addSignedRequestPhotoUrls() {
  requestPhotosReady = true;
  const requestsWithPhotos = maintenanceRequests.filter((request) => request.photo_storage_path);
  if (!requestsWithPhotos.length) return;

  await Promise.all(requestsWithPhotos.map(async (request) => {
    const { data, error } = await supabaseClient.storage
      .from("maintenance-request-photos")
      .createSignedUrl(request.photo_storage_path, 60 * 10);
    if (error) {
      requestPhotosReady = false;
      request.photoSignedUrl = "";
      return;
    }
    request.photoSignedUrl = data?.signedUrl || "";
  }));
}

async function addSignedPartDocumentUrls() {
  const documents = Object.values(partDocumentsByPartId).flat();
  await Promise.all(documents.map(async (document) => {
    const { data } = await supabaseClient.storage
      .from("part-documents")
      .createSignedUrl(document.storage_path, 60 * 10);
    document.signedUrl = data?.signedUrl || "";
  }));
}

function renderWorkspace() {
  const activeCompany = companies.find((company) => company.id === activeCompanyId);
  const navItems = visibleNavItems();
  if (!navItems.some(([id]) => id === activeSection)) {
    activeSection = "mywork";
    localStorage.setItem("maintainops.activeSection", activeSection);
  }
  const isWorkArea = activeSection === "mywork" || activeSection === "work";
  const myWorkGaugeFilters = ["active", "open", "in_progress", "blocked", "overdue", "completed_month", "completed_week"];
  if (activeSection === "mywork" && !myWorkGaugeFilters.includes(activeStatusFilter)) {
    activeStatusFilter = "active";
  }
  const isViewingWorkOrderSearch = activeSection === "work" && workOrderSearchMode && Boolean(searchQuery.trim());
  const profile = profilesByUserId[session.user.id] || {};
  const canSwitchLocation = canSwitchLocations();
  const locationSwitchDisabled = locationsReady && canSwitchLocation ? "" : "disabled";
  const locationSwitchNote = locationsReady
    ? (canSwitchLocation ? "Changing this moves your active workspace." : "Enable Mobile tech in Team to switch locations.")
    : "Run location setup to enable locations.";
  const showWorkDashboard = activeSection === "work" && !isViewingWorkOrderSearch && !activeAssetId && !activeWorkOrderId && !quickFixMode && !createWorkOrderMode;
  const showIssueReportPanel = reportIssueMode && !activeAssetId && !activeWorkOrderId && !quickFixMode && !createWorkOrderMode;
  const showingRequestsInWorkQueue = activeSection === "work" && activeStatusFilter === "requests";
  const activeRequestViewFilter = showingRequestsInWorkQueue ? "active" : requestViewFilter;
  const requestCounts = requestFilterCounts();
  const visibleRequests = filteredRequests(activeRequestViewFilter);
  const visibleRequestCount = requestCounts[activeRequestViewFilter] ?? requestServerTotal;
  const visibleWorkOrders = workOrders;
  const visibleWorkOrderCount = showingRequestsInWorkQueue ? 0 : workOrderServerTotal;
  const totalWorkOrderPages = Math.max(1, Math.ceil(visibleWorkOrderCount / WORK_ORDERS_PER_PAGE));
  if (workOrderPage > totalWorkOrderPages) workOrderPage = totalWorkOrderPages;
  if (workOrderPage < 1) workOrderPage = 1;
  const pagedWorkOrders = visibleWorkOrders;
  const myWork = workOrders.filter((workOrder) => workOrder.assigned_to === session.user.id);
  const myOpenWork = myWork.filter((workOrder) => workOrder.status !== "completed");
  const createdByMe = workOrders.filter((workOrder) => workOrder.created_by === session.user.id && workOrder.status !== "completed");
  const visibleAssets = filteredAssets();
  const visibleSchedules = filteredPreventiveSchedules();
  const visibleProcedures = filteredProcedureTemplates();
  const visibleParts = filteredParts();
  const showGlobalSearch = Boolean(searchQuery.trim()) && !workOrderSearchMode && !activeAssetId && !activeWorkOrderId && !activePartId && !quickFixMode && !createWorkOrderMode;
  const globalResults = showGlobalSearch ? globalSearchResults() : null;
  const totalPartsPages = Math.max(1, Math.ceil(visibleParts.length / PARTS_PER_PAGE));
  if (partsPage > totalPartsPages) partsPage = totalPartsPages;
  if (partsPage < 1) partsPage = 1;
  const pagedParts = visibleParts.slice((partsPage - 1) * PARTS_PER_PAGE, partsPage * PARTS_PER_PAGE);
  const totalAssetPages = Math.max(1, Math.ceil(visibleAssets.length / ASSETS_PER_PAGE));
  if (assetsPage > totalAssetPages) assetsPage = totalAssetPages;
  if (assetsPage < 1) assetsPage = 1;
  const pagedAssets = visibleAssets.slice((assetsPage - 1) * ASSETS_PER_PAGE, assetsPage * ASSETS_PER_PAGE);
  const visibleMembers = filteredMembers();
  const totalRequestPages = Math.max(1, Math.ceil(visibleRequestCount / LIST_ITEMS_PER_PAGE));
  if (requestsPage > totalRequestPages) requestsPage = totalRequestPages;
  if (requestsPage < 1) requestsPage = 1;
  const pagedRequests = visibleRequests;
  const totalSchedulePages = Math.max(1, Math.ceil(visibleSchedules.length / LIST_ITEMS_PER_PAGE));
  if (schedulesPage > totalSchedulePages) schedulesPage = totalSchedulePages;
  if (schedulesPage < 1) schedulesPage = 1;
  const pagedSchedules = visibleSchedules.slice((schedulesPage - 1) * LIST_ITEMS_PER_PAGE, schedulesPage * LIST_ITEMS_PER_PAGE);
  const totalProcedurePages = Math.max(1, Math.ceil(visibleProcedures.length / LIST_ITEMS_PER_PAGE));
  if (proceduresPage > totalProcedurePages) proceduresPage = totalProcedurePages;
  if (proceduresPage < 1) proceduresPage = 1;
  const pagedProcedures = visibleProcedures.slice((proceduresPage - 1) * LIST_ITEMS_PER_PAGE, proceduresPage * LIST_ITEMS_PER_PAGE);
  const totalMemberPages = Math.max(1, Math.ceil(visibleMembers.length / LIST_ITEMS_PER_PAGE));
  if (membersPage > totalMemberPages) membersPage = totalMemberPages;
  if (membersPage < 1) membersPage = 1;
  const pagedMembers = visibleMembers.slice((membersPage - 1) * LIST_ITEMS_PER_PAGE, membersPage * LIST_ITEMS_PER_PAGE);
  const renderCommandStack = (variant = "desktop") => {
    const isMobile = variant === "mobile";
    const suffix = isMobile ? "-mobile" : "";
    return `
      <div class="command-stack ${isMobile ? "mobile-command-stack" : "desktop-command-stack"}">
        <header class="topbar">
          <div class="topbar-main">
            <p class="eyebrow">Authenticated Multi-Tenant MVP</p>
            <div class="company-banner-title">
              ${activeCompany?.logoUrl ? `<img class="company-banner-logo" src="${escapeHtml(activeCompany.logoUrl)}" alt="${escapeHtml(activeCompany?.name || "Company")} logo">` : ""}
              <div>
                <h1>${escapeHtml(activeCompany?.name || "Company")}</h1>
                <label class="topbar-location-switcher">
                  <span>Location</span>
                  <select class="location-select-control" data-location-select ${locationSwitchDisabled} title="${escapeHtml(locationSwitchNote)}">
                    ${locations.length ? "" : `<option value="">Run location setup</option>`}
                    ${locations.map((location) => `<option value="${location.id}" ${location.id === activeLocationId ? "selected" : ""}>${escapeHtml(location.name)}</option>`).join("")}
                  </select>
                  <small>${escapeHtml(locationSwitchNote)}</small>
                </label>
              </div>
            </div>
          </div>
          <div class="topbar-actions">
            <button class="primary-button quick-fix-button" id="show-quick-fix${suffix}" data-command-action="quick-fix" type="button">Quick Fix</button>
            <button class="secondary-button report-issue-button" id="show-report-issue${suffix}" data-command-action="report-issue" type="button">Report Issue</button>
            <details class="topbar-more">
              <summary>More</summary>
              <div>
                <button class="primary-button work-action-button" id="show-create-work-order${suffix}" data-command-action="create-work-order" type="button">New Work Order</button>
                <button class="secondary-button request-action-button" id="show-request${suffix}" data-command-action="request" type="button">Submit Request</button>
                <button class="secondary-button export-action-button" id="export-csv${suffix}" data-command-action="export-csv" type="button">Export CSV</button>
              </div>
            </details>
          </div>
        </header>

        ${appNotice ? `<div class="app-notice ${appNoticeTone}">${escapeHtml(appNotice)}</div>` : ""}
        ${appNotice && appNoticeTone === "success" ? `<div class="save-overlay" aria-hidden="true">SAVED</div>` : ""}
        ${appNotice && appNoticeTone === "warning" ? `<div class="warning-overlay" aria-hidden="true">ACTION NEEDED</div>` : ""}

        <label class="search-bar">
          Search workspace
          <input id="workspace-search${suffix}" class="workspace-search-input" type="search" value="${escapeHtml(searchQuery)}" placeholder="Search work, equipment, parts, people">
        </label>
      </div>
    `;
  };
  app.innerHTML = `
    <div class="app-shell">
      <aside class="sidebar">
        <div class="brand">
          <span class="brand-mark">MO</span>
          <span><strong>MaintainOps</strong><small>Maintenance work, clearly tracked.</small></span>
        </div>
        <details class="sidebar-controls">
          <summary>Workspace</summary>
          <label class="company-switcher">
            Company
            <select id="company-select">
              ${companies.map((company) => `<option value="${escapeHtml(company.id)}" ${company.id === activeCompanyId ? "selected" : ""}>${escapeHtml(company.name)}</option>`).join("")}
            </select>
          </label>
          <label class="company-switcher">
            Location
            <select id="location-select" ${locationSwitchDisabled}>
              ${locations.length ? "" : `<option value="">Run location setup</option>`}
              ${locations.map((location) => `<option value="${location.id}" ${location.id === activeLocationId ? "selected" : ""}>${escapeHtml(location.name)}</option>`).join("")}
            </select>
          </label>
          ${locationsReady ? "" : `<p class="warning-text">Run supabase/step-next-locations.sql to enable locations.</p>`}
          <button class="secondary-button" id="new-company" type="button">New Company</button>
          <button class="text-button inverse" data-sign-out type="button">Sign out</button>
        </details>
        <button class="text-button inverse desktop-sign-out" data-sign-out type="button">Sign out</button>
        ${renderCommandStack("mobile")}
        <nav class="section-nav" aria-label="Workspace sections">
          ${navItems.map(([id, label]) => `<button class="nav-${id} ${activeSection === id ? "active" : ""}" data-section="${id}" type="button">${navIcon(id)}<span>${label}</span>${id === "messages" ? renderMessageNavBadge() : ""}</button>`).join("")}
        </nav>
      </aside>

      <main class="workspace">
        ${renderCommandStack("desktop")}

        ${showGlobalSearch ? renderGlobalSearchResults(globalResults) : ""}

        ${showIssueReportPanel ? renderAppIssueReportForm() : ""}

        ${showWorkDashboard ? `
          <section class="panel full-width screen-gauge-panel">
            <div class="panel-header">
              <h2>Work Orders</h2>
              <span>${escapeHtml(activeLocationName())}</span>
            </div>
            ${renderWorkOrderGaugeDashboard()}
          </section>
        ` : ""}

        <section class="layout-grid single-column ${showGlobalSearch ? "hidden-section" : ""}">
          ${isWorkArea ? `
            ${activeSection !== "assets" && (activeAssetId || activeWorkOrderId || quickFixMode || createWorkOrderMode) ? `
              <section class="panel full-width focus-panel">
                <div class="panel-header">
                  <h2>${activeAssetId ? "Equipment Detail" : activeWorkOrderId ? "Work Order Detail" : quickFixMode ? "Quick Fix" : "Create Work Order"}</h2>
                  <button class="secondary-button back-action-button" id="back-to-my-work" type="button">Back to ${activeSection === "work" ? "Work Orders" : "My Work"}</button>
                </div>
                <div id="detail-panel">${activeAssetId ? renderAssetDetail() : activeWorkOrderId ? renderWorkOrderDetail() : quickFixMode ? renderQuickFixForm() : renderCreateWorkOrder()}</div>
              </section>
            ` : `
              <section class="panel full-width my-work-panel queue-panel">
                <div class="panel-header">
                  <h2>${isViewingWorkOrderSearch ? "Matching Work Orders" : showingRequestsInWorkQueue ? "Requests" : workQueuePanelTitle()}</h2>
                  <span>${isViewingWorkOrderSearch ? `${visibleWorkOrderCount} found for "${escapeHtml(searchQuery.trim())}"` : showingRequestsInWorkQueue ? `${visibleRequestCount} shown` : workQueuePanelSubtitle(visibleWorkOrderCount)}</span>
                </div>
                ${activeSection === "mywork" ? renderWorkloadStrip(myWorkDashboardCounts) : ""}
                ${activeSection === "mywork" ? `
                  <div class="segmented-control" aria-label="My work filter">
                    <button class="segment ${myWorkFilter === "assigned" ? "active" : ""}" data-my-work-filter="assigned" type="button">${segmentIcon("mine")}Assigned To Me</button>
                    <button class="segment ${myWorkFilter === "created" ? "active" : ""}" data-my-work-filter="created" type="button">${segmentIcon("created")}Created By Me</button>
                  </div>
                ` : showingRequestsInWorkQueue ? `
                  ${renderRequestFilterBar(requestCounts, activeRequestViewFilter, { locked: true })}
                  <p class="muted inline-request-note">Active requests waiting for review at this location. Converted requests stay out of this queue.</p>
                ` : isViewingWorkOrderSearch ? `
                  <div class="active-team-filter search-mode-filter">
                    <span>Showing exact paged work order matches at this location.</span>
                    <button class="text-button" data-close-work-search type="button">Back to search preview</button>
                  </div>
                ` : `
                  <div class="segmented-control" aria-label="Work order filter">
                    <button class="segment ${workOrderFilter === "all" ? "active" : ""}" data-work-order-filter="all" type="button">${segmentIcon("all")}All Work Orders</button>
                    <button class="segment ${workOrderFilter === "assigned" ? "active" : ""}" data-work-order-filter="assigned" type="button">${segmentIcon("mine")}Assigned</button>
                    <button class="segment ${workOrderFilter === "vendor" ? "active" : ""}" data-work-order-filter="vendor" type="button">${segmentIcon("vendor")}Vendor</button>
                    <button class="segment ${workOrderFilter === "unassigned" ? "active" : ""}" data-work-order-filter="unassigned" type="button">${segmentIcon("unassigned")}Unassigned</button>
                  </div>
                  ${workOrderAssigneeFilter ? `
                    <div class="active-team-filter">
                      <span>Assigned to ${escapeHtml(teamMemberName(workOrderAssigneeFilter))}</span>
                      <button class="text-button" data-clear-assignee-filter type="button">Clear</button>
                    </div>
                  ` : ""}
                `}
                ${showingRequestsInWorkQueue ? "" : `
                  <div class="segmented-control" aria-label="Work order sort">
                    ${[
                      ["newest", "Newest"],
                      ["due", "Due First"],
                      ["priority", "Priority"],
                    ].map(([id, label]) => `
                      <button class="segment ${workSort === id ? "active" : ""}" data-work-sort="${id}" type="button">${segmentIcon(id)}${label}</button>
                    `).join("")}
                  </div>
                `}
                ${!showingRequestsInWorkQueue && ["completed", "completed_month", "completed_week"].includes(activeStatusFilter) ? `
                  <p class="completion-note completed-history-note">Completed history is paged ${WORK_ORDERS_PER_PAGE} at a time and sorted by most recently completed.</p>
                ` : ""}
                ${showingRequestsInWorkQueue ? `
                  <div class="request-list">
                    ${pagedRequests.map(renderMaintenanceRequest).join("") || `<p class="muted">${escapeHtml(requestEmptyStateText(activeRequestViewFilter))}</p>`}
                  </div>
                  ${renderListPagination("requests", visibleRequestCount, requestsPage, totalRequestPages)}
                ` : `
                  <div class="work-list" id="work-order-list">
                    ${pagedWorkOrders.map(renderWorkOrderCard).join("") || `<p class="muted">No work orders match this filter.</p>`}
                  </div>
                  ${renderWorkPagination(visibleWorkOrderCount, totalWorkOrderPages)}
                `}
              </section>
            `}
          ` : ""}

          <section class="panel full-width ${activeSection === "planning" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Planning</h2>
              <span>${planningItems().length + followUpItems().length} items</span>
            </div>
            <div class="planning-grid">
              ${renderPlanningGroup("Overdue", planningItems("overdue"), "overdue")}
              ${renderPlanningGroup("Due Today", planningItems("today"), "due_today")}
              ${renderPlanningGroup("Next 7 Days", planningItems("soon"), "in_progress")}
              ${renderPlanningGroup("Follow-up Needed", followUpItems(), "blocked")}
              ${renderPlanningGroup("PM Due Soon", planningPmItems(), "open")}
            </div>
          </section>

          <section class="panel full-width ${activeSection === "requests" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Requests</h2>
              <span>${requestsReady ? requestPanelSubtitle(activeRequestViewFilter, visibleRequestCount) : "setup needed"}</span>
            </div>
            ${renderRequestFormContent()}
            ${requestsReady ? `
              ${renderRequestFilterBar(requestCounts, activeRequestViewFilter)}
              <div class="request-list">
                ${pagedRequests.map(renderMaintenanceRequest).join("") || `<p class="muted">${escapeHtml(requestEmptyStateText(activeRequestViewFilter))}</p>`}
              </div>
              ${renderListPagination("requests", visibleRequestCount, requestsPage, totalRequestPages)}
            ` : `<p class="muted">Run supabase/step-next-maintenance-requests.sql before submitting and reviewing requests.</p>`}
          </section>

          <section class="panel full-width ${activeSection === "assets" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>${activeAssetId ? "Equipment Detail" : "Equipment"}</h2>
              ${activeAssetId ? `<button class="secondary-button back-action-button" id="back-to-equipment" type="button">Back to Equipment</button>` : `<span>${visibleAssets.length} shown</span>`}
            </div>
            ${activeAssetId ? renderAssetDetail() : `
            <form class="inline-form" id="create-asset-form">
              <input name="name" required placeholder="Machine or equipment name">
              <input name="asset_code" placeholder="Equipment ID">
              <input name="location" placeholder="Area / line">
              <select name="asset_type" aria-label="Equipment type">
                ${ASSET_TYPE_OPTIONS.map((type) => `<option value="${type}">${assetTypeLabel(type)}</option>`).join("")}
              </select>
              <select name="parent_asset_id" aria-label="Part of equipment">
                <option value="">Top level equipment</option>
                ${renderParentAssetOptions()}
              </select>
              <select name="location_id" ${locations.length ? "required" : "disabled"}>
                ${renderLocationOptions()}
              </select>
              <label class="check-row compact-check"><input name="safety_devices_required" type="checkbox" checked> Safety devices</label>
              <button class="secondary-button asset-action-button" type="submit">Add Equipment</button>
            </form>
            <p class="error-text" id="asset-create-error"></p>
            <div class="asset-health-grid">
              ${["running", "watch", "degraded", "offline"].map((status) => `
                <button class="asset-health ${status} ${assetStatusFilter === status ? "active" : ""}" data-asset-status-filter="${status}" type="button">
                  <span>${assetStatusLabel(status)}</span>
                  <strong>${assets.filter((asset) => matchesActiveLocation(asset) && asset.status === status).length}</strong>
                </button>
              `).join("")}
            </div>
            <div class="asset-list">
              ${pagedAssets.map(renderAssetCard).join("") || `<p class="muted">${assetEmptyStateText()}</p>`}
            </div>
            ${renderAssetsPagination(visibleAssets.length, totalAssetPages)}
            `}
          </section>

          <section class="panel full-width ${activeSection === "pm" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Preventive Maintenance</h2>
              <span>${visibleSchedules.length} shown</span>
            </div>
            <form class="inline-form pm-form" id="create-pm-form">
              <input name="title" required placeholder="Monthly compressor PM">
              <select name="asset_id" required data-location-sensitive-asset>
                <option value="">Machine / equipment</option>
                ${renderAssetOptions()}
              </select>
              <p class="error-text" data-asset-location-warning></p>
              <select name="frequency">
                <option value="weekly">Weekly</option>
                <option value="monthly">Monthly</option>
                <option value="quarterly">Quarterly</option>
              </select>
              <select name="procedure_template_id">
                ${renderProcedureOptions()}
              </select>
              <input name="next_due_at" type="date" required>
              <p class="error-text" id="pm-error"></p>
              <button class="secondary-button" type="submit">Add Schedule</button>
            </form>
            <div class="pm-list">
              ${pagedSchedules.map(renderPreventiveSchedule).join("") || `<p class="muted">No schedules match this search.</p>`}
            </div>
            ${renderListPagination("schedules", visibleSchedules.length, schedulesPage, totalSchedulePages)}
          </section>

          <section class="panel full-width ${activeSection === "procedures" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Procedures</h2>
              <span>${visibleProcedures.length} shown</span>
            </div>
            ${proceduresReady ? `
            <form class="form-grid procedure-form relationship-detail procedure" id="create-procedure-form">
              <label>Procedure name<input name="name" required placeholder="Monthly compressor inspection"></label>
              <label>Description<textarea name="description" rows="3" placeholder="Use this checklist when creating repeat work."></textarea></label>
              <p class="error-text" id="procedure-error"></p>
              <button class="secondary-button" type="submit">Add Procedure</button>
            </form>
            <button class="text-button" id="seed-sample-procedure" type="button">Add sample inspection procedure</button>
            <div class="procedure-list">
              ${pagedProcedures.map(renderProcedureTemplate).join("") || `<p class="muted">No procedures match this search.</p>`}
            </div>
            ${renderListPagination("procedures", visibleProcedures.length, proceduresPage, totalProcedurePages)}
            ` : `<p class="muted">Run supabase/step-next-procedures.sql to turn on procedure templates.</p>`}
          </section>

          <section class="panel full-width ${activeSection === "messages" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Messages</h2>
              <span>${messagesReady ? `${messageThreads.length} threads` : "setup needed"}</span>
            </div>
            ${renderMessageCenter()}
          </section>

          <section class="panel full-width ${activeSection === "team" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Team</h2>
              <span>${visibleMembers.length} shown</span>
            </div>
            ${renderMyProfileForm()}
            ${renderRoleGuide()}
            ${canManageTeam() ? `
              ${renderTeamInviteForm()}
              ${teamInvitesReady ? renderTeamInvites() : `<p class="warning-text">Run supabase/step-next-invite-default-location.sql to invite teammates by email.</p>`}
              <details class="developer-details">
                <summary>Developer add by User UUID</summary>
                <form class="inline-form team-form" id="add-member-form">
                  <input name="user_id" required placeholder="User UUID">
                  <select name="role">
                    <option value="technician">Technician</option>
                    <option value="manager">Manager</option>
                    <option value="admin">Admin</option>
                  </select>
                  <button class="secondary-button" type="submit">Add Member</button>
                </form>
              </details>
            ` : `<p class="muted team-permission-note">Admins and managers can invite teammates and change roles.</p>`}
            <div class="member-list">
              ${pagedMembers.map(renderMember).join("") || `<p class="muted">No team members match this search.</p>`}
            </div>
            ${renderListPagination("members", visibleMembers.length, membersPage, totalMemberPages)}
          </section>

          <section class="panel full-width ${activeSection === "parts" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>${activePartId ? "Part Detail" : "Parts Inventory"}</h2>
              <span>${activePartId ? "editing" : `${visibleParts.length} shown`}</span>
            </div>
            ${activePartId ? renderPartDetail() : `
              <div class="parts-health-grid">
                ${renderPartsHealth()}
              </div>
              ${renderPartSearch()}
              ${renderPartSourceOptions()}
              <form class="inline-form parts-form relationship-detail parts" id="create-part-form">
                <div class="parts-form-header">
                  <h3>Add Part</h3>
                  <button class="text-button danger-link source-edit-button" data-toggle-part-sources type="button">Edit sources</button>
                </div>
                <label>Part name<input name="name" required placeholder="Motor bearing"></label>
                <label>SKU<input name="sku" placeholder="BRG-204"></label>
                <label>Source / vendor<input name="supplier_name" list="part-source-options" placeholder="Grainger, McMaster, local supplier"></label>
                <label>On hand<input name="quantity_on_hand" type="number" min="0" step="1" value="0"></label>
                <label>Reorder at<input name="reorder_point" type="number" min="0" step="1" value="0"></label>
                <label>Unit cost<input name="unit_cost" type="number" min="0" step="0.01" value="0"></label>
                <p class="error-text" id="part-create-error">${partSetupMessage()}</p>
                <button class="secondary-button add-part-button" type="submit">Add Part</button>
              </form>
              ${showPartSourceManager ? renderPartSourceManager() : ""}
              <div class="parts-list" id="parts-list">
                ${pagedParts.map(renderPart).join("") || `<p class="muted">${partEmptyStateText()}</p>`}
              </div>
              ${renderPartsPagination(visibleParts.length, totalPartsPages)}
            `}
          </section>

          <section class="panel full-width ${activeSection === "settings" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Company Settings</h2>
              <span>${escapeHtml(roleLabel(activeCompany?.role))}</span>
            </div>
            ${canManageTeam() ? `
              <form class="form-grid settings-form" id="company-settings-form">
                <label>Company name<input name="name" required value="${escapeHtml(activeCompany?.name || "")}"></label>
                <button class="secondary-button" type="submit">Save Company</button>
              </form>
              <form class="form-grid settings-form logo-form" id="company-logo-form">
                <div class="company-logo-preview">
                  ${activeCompany?.logoUrl ? `<img src="${escapeHtml(activeCompany.logoUrl)}" alt="${escapeHtml(activeCompany?.name || "Company")} logo preview">` : `<span>MO</span>`}
                </div>
                <label>Company logo<input name="logo" type="file" accept="image/*"><small>Optional. Logos are optimized before upload.</small></label>
                <p class="error-text" id="company-logo-error">${escapeHtml(activeCompany?.logoError || "")}</p>
                <button class="secondary-button" type="submit">Upload Logo</button>
              </form>
              <div class="settings-summary logo-status">
                <article><strong>Logo status</strong><span>${activeCompany?.logo_path ? (activeCompany?.logoUrl ? "loaded" : "saved, cannot display") : "none uploaded"}</span></article>
                ${activeCompany?.logo_path ? `<article><strong>Logo path</strong><span>${escapeHtml(activeCompany.logo_path)}</span></article>` : ""}
              </div>
              <form class="form-grid settings-form" id="location-form">
                <label>New location<input name="name" required placeholder="North Plant"></label>
                <p class="error-text" id="location-error">${locationsReady ? "" : "Run supabase/step-next-locations.sql before adding locations."}</p>
                <button class="secondary-button" type="submit" ${locationsReady ? "" : "disabled"}>Add Location</button>
              </form>
              <div class="settings-summary">
                ${locations.map((location) => `<article><strong>${escapeHtml(location.name)}</strong><span>${location.id === activeLocationId ? "active location" : "available"}</span></article>`).join("") || `<article><strong>No locations yet</strong><span>Run the location setup SQL</span></article>`}
              </div>
              ${renderPublicRequestLinkManager()}
              <div class="settings-summary">
                <article><strong>Company ID</strong><span>${escapeHtml(activeCompanyId)}</span></article>
                <article><strong>Signed in as</strong><span>${escapeHtml(session.user.email || session.user.id)}</span></article>
                <article><strong>Active section</strong><span>${escapeHtml(activeSection)}</span></article>
              </div>
            ` : `<p class="muted">Company settings are available to managers and admins.</p>`}
          </section>

          <section class="panel full-width ${activeSection === "setup" ? "" : "hidden-section"}">
            <div class="panel-header">
              <h2>Admin Setup</h2>
              <span>${setupItems().filter((item) => item.ready).length}/${setupItems().length} ready</span>
            </div>
            <p class="muted setup-note">Builder diagnostic area. Use this to confirm Supabase tables, columns, storage, and config are ready before demos or deployment.</p>
            <div class="setup-list">
              ${setupItems().map(renderSetupItem).join("")}
            </div>
            ${renderAppIssueReportsPanel()}
          </section>
        </section>
      </main>
    </div>
  `;

  bindWorkspaceEvents();
}

function filteredWorkOrders() {
  return workOrders.filter((workOrder) => {
    if (!matchesActiveLocation(workOrder)) return false;
    const statusMatch = workOrderMatchesStatusFilter(workOrder);
    const queueMatch = activeSection === "mywork"
      ? (myWorkFilter === "created" ? workOrder.created_by === session.user.id : workOrder.assigned_to === session.user.id)
      : workOrderAssigneeFilter
        ? workOrder.assigned_to === workOrderAssigneeFilter
        : workOrderFilter === "all" ||
          (workOrderFilter === "assigned" && Boolean(workOrder.assigned_to)) ||
          (workOrderFilter === "vendor" && isVendorAssigned(workOrder)) ||
          (workOrderFilter === "unassigned" && !workOrder.assigned_to && !isVendorAssigned(workOrder));
    return statusMatch && queueMatch && matchesSearch(workOrderSearchValues(workOrder));
  }).sort(compareWorkOrders);
}

function workOrderMatchesStatusFilter(workOrder) {
  if (activeStatusFilter === "overdue") return getDueState(workOrder)?.className === "overdue";
  if (activeStatusFilter === "completed_month") return isCompletedThisMonth(workOrder);
  if (activeStatusFilter === "completed_week") return isCompletedThisWeek(workOrder);
  if (activeStatusFilter === "active" || activeStatusFilter === "all") return workOrder.status !== "completed";
  return workOrder.status === activeStatusFilter;
}

function myWorkQueueOrders() {
  return workOrders.filter((workOrder) => {
    if (!matchesActiveLocation(workOrder)) return false;
    const queueMatch = myWorkFilter === "created"
      ? workOrder.created_by === session.user.id
      : workOrder.assigned_to === session.user.id;
    return queueMatch && matchesSearch(workOrderSearchValues(workOrder));
  });
}

function resetWorkOrderPage() {
  workOrderPage = 1;
  localStorage.setItem("maintainops.workOrderPage", String(workOrderPage));
}

function setWorkOrderSearchMode(enabled) {
  workOrderSearchMode = Boolean(enabled && searchQuery.trim());
  if (workOrderSearchMode) {
    localStorage.setItem("maintainops.workOrderSearchMode", "true");
  } else {
    localStorage.removeItem("maintainops.workOrderSearchMode");
  }
}

function invalidateExactWorkOrderSearchCache() {
  exactWorkOrderSearchCache = { key: "", rows: [] };
}

function resetPartsPage() {
  partsPage = 1;
  localStorage.setItem("maintainops.partsPage", String(partsPage));
}

function resetRequestsPage() {
  requestsPage = 1;
  localStorage.setItem("maintainops.requestsPage", String(requestsPage));
}

function clearPartSearchState() {
  partSearchQuery = "";
  localStorage.setItem("maintainops.partSearchQuery", "");
  resetPartsPage();
}

function resetAssetsPage() {
  assetsPage = 1;
  localStorage.setItem("maintainops.assetsPage", String(assetsPage));
}

function activeLocationDatabaseId() {
  return locationsReady && activeLocationId ? activeLocationId : null;
}

function recordLocationId(record) {
  return record?.location_id || record?.assets?.location_id || null;
}

function locationIdForAsset(assetId) {
  return assets.find((asset) => asset.id === assetId)?.location_id || activeLocationDatabaseId();
}

function assetLocationMismatch(assetId) {
  if (!assetId || !locationsReady || !activeLocationId) return null;
  const asset = assets.find((item) => item.id === assetId);
  if (!asset?.location_id || asset.location_id === activeLocationId) return null;
  const assetLocation = locations.find((location) => location.id === asset.location_id);
  const activeLocation = locations.find((location) => location.id === activeLocationId);
  return {
    asset,
    assetLocationName: assetLocation?.name || "another location",
    activeLocationName: activeLocation?.name || "the selected location",
  };
}

function assetLocationRoutingMessage(assetId) {
  const mismatch = assetLocationMismatch(assetId);
  if (!mismatch) return "";
  return `${mismatch.asset.name} belongs to ${mismatch.assetLocationName}. This will save to ${mismatch.assetLocationName}, not ${mismatch.activeLocationName}.`;
}

// LFES-TRACEABILITY: Cross-location equipment routing is allowed only with visible user intent because it changes where work lands.
function confirmAssetLocationRouting(assetId, actionLabel, errorTarget) {
  const message = assetLocationRoutingMessage(assetId);
  if (!message) return true;
  const confirmed = window.confirm(`${message}\n\nContinue ${actionLabel}?`);
  if (!confirmed && errorTarget) {
    errorTarget.textContent = "Save cancelled. Switch location or choose equipment from the current location before trying again.";
  }
  return confirmed;
}

function updateAssetLocationWarning(select) {
  const form = select.closest("form");
  const warning = form?.querySelector("[data-asset-location-warning]");
  if (!warning) return;
  warning.textContent = assetLocationRoutingMessage(select.value);
}

function matchesActiveLocation(record) {
  if (!locationsReady || !activeLocationId) return true;
  return recordLocationId(record) === activeLocationId;
}

function showNotice(message, tone = "success") {
  appNotice = message;
  appNoticeTone = tone;
  clearTimeout(noticeTimer);
  noticeTimer = setTimeout(() => {
    appNotice = "";
    appNoticeTone = "success";
    renderWorkspace();
  }, tone === "warning" ? 4200 : 2600);
}

function setWorkOrderActionWarning(id, message) {
  workOrderActionWarningId = id || "";
  workOrderActionWarning = message || "";
}

function bindAutoGrowTextareas() {
  document.querySelectorAll("textarea").forEach((field) => {
    autoGrowTextarea(field);
    field.addEventListener("input", () => autoGrowTextarea(field));
  });
}

function autoGrowTextarea(field) {
  field.style.height = "auto";
  field.style.height = `${field.scrollHeight}px`;
}

function compareWorkOrders(a, b) {
  if (["completed", "completed_month", "completed_week"].includes(activeStatusFilter)) {
    return completedSortValue(b) - completedSortValue(a) || new Date(b.created_at) - new Date(a.created_at);
  }

  if (workSort === "due") {
    return dueSortValue(a) - dueSortValue(b) || new Date(b.created_at) - new Date(a.created_at);
  }

  if (workSort === "priority") {
    return prioritySortValue(b.priority) - prioritySortValue(a.priority) || dueSortValue(a) - dueSortValue(b);
  }

  return new Date(b.created_at) - new Date(a.created_at);
}

function dueSortValue(workOrder) {
  if (!workOrder.due_at) return Number.MAX_SAFE_INTEGER;
  return new Date(`${workOrder.due_at}T00:00:00`).getTime();
}

function prioritySortValue(priority) {
  return { low: 1, medium: 2, high: 3, critical: 4 }[priority] || 0;
}

function completedSortValue(workOrder) {
  return workOrder.completed_at ? new Date(workOrder.completed_at).getTime() : 0;
}

function requestMatchesBaseFilters(request) {
  return matchesActiveLocation(request) && matchesSearch([
    request.title,
    request.description,
    request.status,
    request.priority,
    request.assets?.name,
    profilesByUserId[request.requested_by]?.full_name,
  ]);
}

function isConvertedRequest(request) {
  return request.status === "converted" || Boolean(request.converted_work_order_id);
}

function requestMatchesViewFilter(request, filter = requestViewFilter) {
  if (filter === "converted") return isConvertedRequest(request);
  if (filter === "all") return true;
  return !isConvertedRequest(request) && request.status === "submitted";
}

function filteredRequests(filter = requestViewFilter) {
  return maintenanceRequests.filter((request) => requestMatchesBaseFilters(request) && requestMatchesViewFilter(request, filter));
}

function requestFilterCounts() {
  return requestDashboardCounts || { active: 0, converted: 0, all: 0 };
}

function filteredAssets() {
  return assets.filter((asset) => {
    if (!matchesActiveLocation(asset)) return false;
    if (assetStatusFilter !== "all" && asset.status !== assetStatusFilter) return false;
    return matchesSearch([
      asset.name,
      asset.asset_code,
      asset.location,
      asset.status,
      asset.asset_type,
      parentAssetFor(asset)?.name,
    ]);
  });
}

function parentAssetFor(asset) {
  return assets.find((item) => item.id === asset?.parent_asset_id) || null;
}

function childAssetsFor(assetId) {
  return assets
    .filter((asset) => asset.parent_asset_id === assetId)
    .sort((a, b) => a.name.localeCompare(b.name));
}

function isAssetDescendantOf(assetId, ancestorId) {
  if (!assetId || !ancestorId) return false;
  let current = assets.find((asset) => asset.id === assetId);
  const seen = new Set();
  while (current?.parent_asset_id && !seen.has(current.id)) {
    if (current.parent_asset_id === ancestorId) return true;
    seen.add(current.id);
    current = assets.find((asset) => asset.id === current.parent_asset_id);
  }
  return false;
}

function filteredPreventiveSchedules() {
  return preventiveSchedules.filter((schedule) => matchesActiveLocation(schedule) && matchesSearch([
    schedule.title,
    schedule.frequency,
    schedule.next_due_at,
    schedule.assets?.name,
  ]));
}

function filteredProcedureTemplates() {
  return procedureTemplates.filter((template) => matchesSearch([
    template.name,
    template.description,
    ...(template.procedure_steps || []).map((step) => step.prompt),
  ]));
}

function filteredParts() {
  return parts.filter((part) => {
    if (!matchesActiveLocation(part)) return false;
    if (partInventoryFilter === "low" && !isLowStockPart(part)) return false;
    return matchesPartSearch([
      part.name,
      part.sku,
      part.supplier_name,
      part.quantity_on_hand,
      part.reorder_point,
      part.unit_cost,
    ]);
  });
}

function matchesPartSearch(values) {
  const query = partSearchQuery.trim().toLowerCase();
  if (!query) return true;
  return values.some((value) => String(value ?? "").toLowerCase().includes(query));
}

function partSourceOptions() {
  return [...new Set(parts.filter(matchesActiveLocation)
    .map((part) => String(part.supplier_name || "").trim())
    .filter(Boolean))]
    .sort((a, b) => a.localeCompare(b));
}

function filteredMembers() {
  return companyMembers.filter((member) => matchesSearch([
    member.user_id,
    member.role,
    profilesByUserId[member.user_id]?.full_name,
  ]));
}

function matchesSearch(values) {
  const query = searchQuery.trim().toLowerCase();
  if (!query) return true;
  return values.some((value) => String(value ?? "").toLowerCase().includes(query));
}

function matchesQuery(values, query = searchQuery) {
  const normalized = query.trim().toLowerCase();
  if (!normalized) return true;
  return values.some((value) => String(value ?? "").toLowerCase().includes(normalized));
}

function workOrderSearchValues(workOrder) {
  const usedParts = partsUsedByWorkOrder[workOrder.id] || [];
  const comments = commentsByWorkOrder[workOrder.id] || [];
  const events = eventsByWorkOrder[workOrder.id] || [];
  const photos = photosByWorkOrder[workOrder.id] || [];
  const procedure = procedureTemplates.find((template) => template.id === workOrder.procedure_template_id);
  const stepResults = Object.values(stepResultsByWorkOrder[workOrder.id] || {});

  return [
    workOrder.title,
    workOrder.description,
    workOrder.status,
    statusLabel(workOrder.status),
    workOrder.priority,
    workOrder.type,
    workOrder.assets?.name,
    assignmentLabel(workOrder),
    workOrder.failure_cause,
    workOrder.resolution_summary,
    workOrder.completion_notes,
    workOrder.current_update,
    procedure?.name,
    procedure?.description,
    ...(procedure?.procedure_steps || []).flatMap((step) => [step.prompt, step.step_type]),
    ...usedParts.flatMap((row) => [
      row.parts?.name,
      row.parts?.sku,
      row.parts?.supplier_name,
      row.quantity_used,
      row.unit_cost,
    ]),
    ...comments.flatMap((comment) => [
      comment.body,
      profilesByUserId[comment.author_id]?.full_name,
    ]),
    ...events.flatMap((event) => [
      event.event_type,
      event.summary,
      profilesByUserId[event.actor_id]?.full_name,
    ]),
    ...photos.flatMap((photo) => [
      photo.file_name,
      photo.original_file_name,
      photo.content_type,
    ]),
    ...stepResults.flatMap((result) => [
      result.value,
      result.notes,
    ]),
  ];
}

function globalSearchResults() {
  const query = searchQuery.trim();
  const work = workOrders
    .filter(matchesActiveLocation)
    .sort(compareWorkOrders)
    .slice(0, SEARCH_PREVIEW_LIMIT);

  const assetResults = assets
    .filter(matchesActiveLocation)
    .filter((asset) => matchesQuery([asset.name, asset.asset_code, asset.location, asset.status], query))
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, SEARCH_PREVIEW_LIMIT);

  const partResults = parts
    .filter(matchesActiveLocation)
    .filter((part) => matchesQuery([part.name, part.sku, part.supplier_name, part.quantity_on_hand, part.reorder_point], query))
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, SEARCH_PREVIEW_LIMIT);

  const requestResults = maintenanceRequests
    .filter(matchesActiveLocation)
    .filter((request) => matchesQuery([
      request.title,
      request.description,
      request.status,
      request.priority,
      request.assets?.name,
      profilesByUserId[request.requested_by]?.full_name,
    ], query))
    .sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
    .slice(0, SEARCH_PREVIEW_LIMIT);

  const pmResults = preventiveSchedules
    .filter(matchesActiveLocation)
    .filter((schedule) => matchesQuery([schedule.title, schedule.frequency, schedule.next_due_at, schedule.assets?.name], query))
    .sort((a, b) => String(a.next_due_at || "").localeCompare(String(b.next_due_at || "")))
    .slice(0, SEARCH_PREVIEW_LIMIT);

  const procedureResults = procedureTemplates
    .filter((template) => matchesQuery([
      template.name,
      template.description,
      ...(template.procedure_steps || []).map((step) => step.prompt),
    ], query))
    .sort((a, b) => a.name.localeCompare(b.name))
    .slice(0, SEARCH_PREVIEW_LIMIT);

  return { work, assets: assetResults, parts: partResults, requests: requestResults, pm: pmResults, procedures: procedureResults };
}

function renderAssetDetail() {
  const asset = assets.find((item) => item.id === activeAssetId);
  if (!asset) return renderCreateWorkOrder();
  const parent = parentAssetFor(asset);
  const children = childAssetsFor(asset.id);
  const assetWorkOrders = workOrders.filter((workOrder) => workOrder.asset_id === asset.id);
  const openWork = assetWorkOrders.filter((workOrder) => workOrder.status !== "completed");
  const completedWork = assetWorkOrders.filter((workOrder) => workOrder.status === "completed");
  const assetSchedules = preventiveSchedules.filter((schedule) => schedule.asset_id === asset.id);
  const usedParts = Object.values(partsUsedByWorkOrder)
    .flat()
    .filter((row) => assetWorkOrders.some((workOrder) => workOrder.id === row.work_order_id));

  return `
    <div class="detail-stack">
      <div>
        <div class="chip-row">
          <span class="chip asset-${asset.status}">${escapeHtml(asset.status)}</span>
          <span class="chip">${escapeHtml(assetTypeLabel(asset.asset_type))}</span>
          ${asset.asset_code ? `<span class="chip">${escapeHtml(asset.asset_code)}</span>` : ""}
          ${asset.safety_devices_required === false ? `<span class="chip">no safety check</span>` : `<span class="chip overdue">safety check required</span>`}
        </div>
        <h2>${escapeHtml(asset.name)}</h2>
        <p>${escapeHtml(asset.location || "No location set")}</p>
        ${parent ? `<p>Part of <button class="text-button inline-link-button" data-open-asset="${escapeHtml(parent.id)}" type="button">${escapeHtml(parent.name)}</button></p>` : ""}
      </div>

      <div class="quick-actions detail-quick-actions">
        <button class="assign-action" data-quick-fix-asset="${asset.id}" type="button">Quick Fix for this equipment</button>
      </div>

      <form class="form-grid" id="edit-asset-form">
        <label>Equipment name<input name="name" required value="${escapeHtml(asset.name)}"></label>
        <label>Equipment ID<input name="asset_code" value="${escapeHtml(asset.asset_code || "")}"></label>
        <label>Type
          <select name="asset_type">
            ${ASSET_TYPE_OPTIONS.map((type) => `<option value="${type}" ${type === (asset.asset_type || "machine") ? "selected" : ""}>${assetTypeLabel(type)}</option>`).join("")}
          </select>
        </label>
        <label>Part of
          <select name="parent_asset_id">
            <option value="">Top level equipment</option>
            ${renderParentAssetOptions(asset.parent_asset_id || "", asset.id)}
          </select>
        </label>
        <label>Location
          <select name="location_id" ${locations.length ? "" : "disabled"}>
            ${renderLocationOptions(asset.location_id || activeLocationId)}
          </select>
        </label>
        <label>Area / spot<input name="location" value="${escapeHtml(asset.location || "")}"></label>
        <label>Status
          <select name="status">
            ${["running", "watch", "degraded", "offline"].map((status) => `<option value="${status}" ${status === asset.status ? "selected" : ""}>${assetStatusLabel(status)}</option>`).join("")}
          </select>
        </label>
        <label class="check-row safety-check-toggle"><input name="safety_devices_required" type="checkbox" ${asset.safety_devices_required === false ? "" : "checked"}> Safety devices required before completion</label>
        <p class="error-text" id="asset-edit-error"></p>
        <button class="secondary-button asset-action-button" type="submit">Save Equipment</button>
      </form>

      <section>
        <h3>Linked Equipment</h3>
        <div class="mini-list asset-link-list">
          ${children.map((child) => `
            <article class="mini-work-order" data-open-asset="${escapeHtml(child.id)}">
              <strong>${escapeHtml(child.name)}</strong>
              <span>${escapeHtml(assetTypeLabel(child.asset_type))} - ${escapeHtml(assetStatusLabel(child.status))}</span>
            </article>
          `).join("") || `<p class="muted">No equipment is linked under this item yet.</p>`}
        </div>
      </section>

      <section>
        <h3>Open Work</h3>
        <div class="mini-list">
          ${openWork.map(renderAssetMiniWorkOrder).join("") || `<p class="muted">No open work for this equipment.</p>`}
        </div>
      </section>

      <section>
        <h3>Completed History</h3>
        <div class="mini-list">
          ${completedWork.map(renderAssetMiniWorkOrder).join("") || `<p class="muted">No completed work yet.</p>`}
        </div>
      </section>

      <section>
        <h3>PM Schedules</h3>
        <div class="mini-list">
          ${assetSchedules.map((schedule) => `<article><strong>${escapeHtml(schedule.title)}</strong><span>${schedule.frequency} - next due ${schedule.next_due_at}</span></article>`).join("") || `<p class="muted">No PM schedules for this equipment.</p>`}
        </div>
      </section>

      <section>
        <h3>Parts Used</h3>
        <div class="mini-list">
          ${usedParts.map((row) => `<article><strong>${escapeHtml(row.parts?.name || "Part")}</strong><span>${row.quantity_used} used</span></article>`).join("") || `<p class="muted">No parts history yet.</p>`}
        </div>
      </section>

      ${renderAssetDangerZone(asset)}
    </div>
  `;
}

function renderAssetDangerZone(asset) {
  const workCount = workOrders.filter((workOrder) => workOrder.asset_id === asset.id).length;
  const childCount = childAssetsFor(asset.id).length;
  const scheduleCount = preventiveSchedules.filter((schedule) => schedule.asset_id === asset.id).length;
  const requestCount = maintenanceRequests.filter((request) => request.asset_id === asset.id).length;
  const blockerMessage = assetDeleteBlockerMessage({
    workOrders: workCount,
    children: childCount,
    schedules: scheduleCount,
    requests: requestCount,
  });
  const confirming = pendingDeleteAssetId === asset.id;
  if (!canDeleteEquipment()) {
    return `<p class="muted">Admins and managers can delete unused equipment.</p>`;
  }

  return `
    <section class="delete-zone asset-delete-zone">
      <div>
        <h3>Delete Equipment</h3>
        <p>${blockerMessage
          ? blockerMessage
          : `This permanently removes "${escapeHtml(asset.name)}" from the equipment list.`}</p>
      </div>
      <p class="error-text" id="asset-delete-error"></p>
      ${blockerMessage ? `
        <button class="danger-action-button large-delete-button" type="button" disabled>Kept For Traceability</button>
      ` : confirming ? `
        <div class="delete-warning-panel">
          <strong>Permanent Delete Warning</strong>
          <p>You are about to permanently delete "${escapeHtml(asset.name)}". This cannot be undone.</p>
          <div class="button-row">
            <button class="secondary-button" data-cancel-delete-asset type="button">Cancel</button>
            <button class="danger-action-button confirm-delete-button" data-confirm-delete-asset="${escapeHtml(asset.id)}" type="button">Permanently Delete</button>
          </div>
        </div>
      ` : `
        <button class="danger-action-button large-delete-button" data-delete-asset="${escapeHtml(asset.id)}" type="button">Delete Equipment</button>
      `}
    </section>
  `;
}

function renderPreventiveSchedule(schedule) {
  const dueState = getDueState({ due_at: schedule.next_due_at, status: "open" });
  const confirming = pendingDeleteScheduleId === schedule.id;
  return `
    <article class="pm-card">
      <div>
        <div class="chip-row">
          <span class="chip">${escapeHtml(schedule.frequency)}</span>
          ${dueState ? `<span class="chip ${dueState.className}">${dueState.label}</span>` : ""}
        </div>
        <h3>${escapeHtml(schedule.title)}</h3>
        <p>${escapeHtml(schedule.assets?.name || "No equipment")} - Next due ${schedule.next_due_at}</p>
      </div>
      <div class="request-actions">
        <button class="secondary-button" data-generate-pm="${schedule.id}" type="button">Generate Work</button>
        ${canDeleteOperationalRecords() ? confirming ? `
          <button class="secondary-button" data-cancel-delete-schedule type="button">Cancel</button>
          <button class="danger-action-button confirm-delete-button" data-confirm-delete-schedule="${escapeHtml(schedule.id)}" type="button">Permanently Delete</button>
        ` : `
          <button class="danger-action-button" data-delete-schedule="${escapeHtml(schedule.id)}" type="button">Delete</button>
        ` : ""}
      </div>
    </article>
  `;
}

function renderProcedureTemplate(template) {
  const linkedWorkCount = workOrders.filter((workOrder) => workOrder.procedure_template_id === template.id).length;
  const linkedScheduleCount = preventiveSchedules.filter((schedule) => schedule.procedure_template_id === template.id).length;
  const blockerMessage = procedureDeleteBlockerMessage({
    workOrders: linkedWorkCount,
    schedules: linkedScheduleCount,
  });
  const confirming = pendingDeleteProcedureId === template.id;
  return `
    <article class="procedure-card">
      <div>
        <div class="chip-row">
          <span class="chip">${template.procedure_steps?.length || 0} steps</span>
          <span class="chip">${linkedWorkCount} linked work orders</span>
          ${linkedScheduleCount ? `<span class="chip">${linkedScheduleCount} PM schedules</span>` : ""}
        </div>
        <h3>${escapeHtml(template.name)}</h3>
        <p>${escapeHtml(template.description || "No description.")}</p>
      </div>
      <div class="checklist-list">
        ${(template.procedure_steps || []).map((step) => `
          <div class="checklist-step">
            <span>${step.position}. ${escapeHtml(step.prompt)}</span>
            <small>${escapeHtml(step.response_type)} ${step.required ? "- required" : "- optional"}</small>
          </div>
        `).join("") || `<p class="muted">No steps yet.</p>`}
      </div>
      <form class="inline-form add-step-form relationship-detail procedure" data-add-step="${template.id}">
        <input name="prompt" required placeholder="Step prompt">
        <select name="response_type">
          <option value="checkbox">Checkbox</option>
          <option value="pass_fail">Pass / Fail</option>
          <option value="number">Number</option>
          <option value="text">Text</option>
        </select>
        <select name="required">
          <option value="true">Required</option>
          <option value="false">Optional</option>
        </select>
        <p class="error-text" data-step-error="${template.id}"></p>
        <button class="secondary-button" type="submit">Add Step</button>
      </form>
      ${canDeleteOperationalRecords() ? `
        <section class="delete-zone procedure-delete-zone">
          <div>
            <h3>Delete Procedure</h3>
            <p>${blockerMessage || "This removes the template and checklist steps."}</p>
          </div>
          <p class="error-text" data-procedure-delete-error="${escapeHtml(template.id)}"></p>
          ${blockerMessage ? `
            <button class="danger-action-button" type="button" disabled>Kept For Traceability</button>
          ` : confirming ? `
            <div class="delete-warning-panel">
              <strong>Permanent Delete Warning</strong>
              <p>You are about to permanently delete "${escapeHtml(template.name)}". This cannot be undone.</p>
              <div class="button-row">
                <button class="secondary-button" data-cancel-delete-procedure type="button">Cancel</button>
                <button class="danger-action-button permanent-delete-button" data-confirm-delete-procedure="${escapeHtml(template.id)}" type="button">Permanently Delete</button>
              </div>
            </div>
          ` : `
            <button class="danger-action-button" data-delete-procedure="${escapeHtml(template.id)}" type="button">Delete Procedure</button>
          `}
        </section>
      ` : ""}
    </article>
  `;
}

function procedureColumn(value) {
  return proceduresReady ? { procedure_template_id: value || null } : {};
}

function isProcedureSchemaError(error) {
  const message = error?.message || "";
  return Boolean(message.includes("procedure_template_id") || message.includes("procedure_templates") || message.includes("procedure_steps"));
}

function isAssetHierarchySchemaError(error) {
  return isColumnSchemaError(error, ["parent_asset_id", "asset_type", "safety_devices_required", "safety_check_required"]);
}

function equipmentSchemaMessage(error) {
  const message = error?.message || "";
  if (message.includes("assets_asset_type_check") || message.includes("asset_type")) {
    return "Run supabase/step-next-asset-type-shop-item.sql before saving Shop Item equipment.";
  }
  return "Run supabase/step-next-asset-hierarchy.sql before saving equipment hierarchy.";
}

function isColumnSchemaError(error, columns) {
  const message = error?.message || "";
  return columns.some((column) => message.includes(column));
}

function withSetupError(response, message) {
  return {
    ...response,
    error: {
      ...(response.error || {}),
      message,
      originalMessage: response.error?.message || "",
    },
  };
}

function markSchemaReadiness(error) {
  if (isMissingColumnError(error, "location_id") || error?.message?.includes("locations")) locationsReady = false;
  if (isProcedureSchemaError(error)) proceduresReady = false;
  if (isColumnSchemaError(error, ["safety_devices_checked", "safety_devices_checked_at", "safety_check_required"])) safetyChecksReady = false;
}

function databaseSetupRequiredMessage(area = "this save") {
  return `Database update required before ${area}. Run the current Supabase SQL steps from docs/supabase-architecture.md, then refresh and try again.`;
}

function withOperationTimeout(promise, message, timeoutMs = 20000) {
  let timeoutId;
  const timeout = new Promise((_, reject) => {
    timeoutId = setTimeout(() => reject(new Error(message)), timeoutMs);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timeoutId));
}

function workOrderDateValue(value) {
  const trimmed = String(value || "").trim();
  if (!trimmed) return null;
  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    const parsed = new Date(`${trimmed}T00:00:00`);
    if (Number.isNaN(parsed.getTime())) throw new Error("Enter a real expected back up / due date as YYYY-MM-DD.");
    const parsedIso = parsed.toISOString().slice(0, 10);
    if (parsedIso === trimmed) return trimmed;
    throw new Error("Enter a real expected back up / due date as YYYY-MM-DD.");
  }
  const parsed = new Date(trimmed);
  if (Number.isNaN(parsed.getTime())) {
    throw new Error("Enter the expected back up / due date as YYYY-MM-DD.");
  }
  return parsed.toISOString().slice(0, 10);
}

function requiredText(value, label) {
  const text = String(value || "").trim();
  if (!text) throw new Error(`${label} is required.`);
  return text;
}

const WORK_ORDER_SCHEMA_FIELDS = [
  "location_id",
  "assigned_to",
  "procedure_template_id",
  "actual_minutes",
  "failure_cause",
  "resolution_summary",
  "follow_up_needed",
  "completion_notes",
  "completed_at",
  "safety_devices_checked",
  "safety_devices_checked_at",
  "safety_check_required",
];

async function insertWithOptionalProcedure(table, payload, options = {}) {
  let query = supabaseClient.from(table).insert(payload);
  if (options.returnSingle) query = query.select().single();
  const response = await query;
  if (!response.error) return response;
  const setupColumns = table === "work_orders" ? WORK_ORDER_SCHEMA_FIELDS : ["location_id", "procedure_template_id"];
  if (isColumnSchemaError(response.error, setupColumns)) {
    markSchemaReadiness(response.error);
    return withSetupError(response, databaseSetupRequiredMessage(`saving ${table.replaceAll("_", " ")}`));
  }
  return response;
}

async function updateWithOptionalProcedure(table, payload, id) {
  const response = await supabaseClient
    .from(table)
    .update(payload)
    .eq("id", id)
    .eq("company_id", activeCompanyId);
  if (response.error && isColumnSchemaError(response.error, ["location_id", "procedure_template_id"])) {
    markSchemaReadiness(response.error);
    return withSetupError(response, databaseSetupRequiredMessage(`saving ${table.replaceAll("_", " ")}`));
  }
  return response;
}

async function updateWorkOrderSafely(payload, id) {
  const response = await updateWithOptionalProcedure("work_orders", payload, id);
  if (response.error && isColumnSchemaError(response.error, WORK_ORDER_SCHEMA_FIELDS)) {
    markSchemaReadiness(response.error);
    return withSetupError(response, databaseSetupRequiredMessage("saving work order details"));
  }
  return response;
}

function renderChecklistStep(workOrder, step) {
  const result = stepResultsByWorkOrder[workOrder.id]?.[step.id];
  const value = result?.value || "";
  const baseAttrs = `data-step-result="${step.id}" data-work-order-id="${workOrder.id}"`;
  let control = `<input ${baseAttrs} value="${escapeHtml(value)}" placeholder="Result">`;

  if (step.response_type === "checkbox") {
    control = `<label class="check-row"><input ${baseAttrs} type="checkbox" ${value === "checked" ? "checked" : ""}> Done</label>`;
  }

  if (step.response_type === "pass_fail") {
    control = `
      <select ${baseAttrs}>
        <option value="">Not checked</option>
        <option value="pass" ${value === "pass" ? "selected" : ""}>Pass</option>
        <option value="fail" ${value === "fail" ? "selected" : ""}>Fail</option>
      </select>
    `;
  }

  if (step.response_type === "number") {
    control = `<input ${baseAttrs} type="number" value="${escapeHtml(value)}" placeholder="Reading">`;
  }

  return `
    <div class="checklist-step relationship-detail procedure">
      <span>${step.position}. ${escapeHtml(step.prompt)} ${step.required ? `<small class="required-mark">Required</small>` : ""}</span>
      ${control}
      ${result?.completed_at ? `<small>Recorded ${new Date(result.completed_at).toLocaleString()}</small>` : ""}
    </div>
  `;
}

function checklistProgress(workOrder, procedure) {
  const steps = procedure.procedure_steps || [];
  const results = stepResultsByWorkOrder[workOrder.id] || {};
  const done = steps.filter((step) => Boolean(results[step.id]?.value)).length;
  return { done, total: steps.length };
}

function requiredChecklistProgress(workOrder, procedure) {
  const steps = (procedure?.procedure_steps || []).filter((step) => step.required);
  const results = stepResultsByWorkOrder[workOrder.id] || {};
  const done = steps.filter((step) => Boolean(results[step.id]?.value)).length;
  return { done, total: steps.length };
}

function requiredChecklistProgressFor(workOrder, procedureTemplateId = workOrder?.procedure_template_id) {
  const procedure = procedureTemplates.find((template) => template.id === procedureTemplateId);
  if (!procedure) return { done: 0, total: 0 };
  if (!workOrder?.id) return { done: 0, total: (procedure.procedure_steps || []).filter((step) => step.required).length };
  return requiredChecklistProgress(workOrder, procedure);
}

function requiredChecklistCompletionMessage(workOrder, procedureTemplateId = workOrder?.procedure_template_id) {
  const progress = requiredChecklistProgressFor(workOrder, procedureTemplateId);
  if (progress.done >= progress.total) return "";
  return `Complete required procedure checklist steps first (${progress.done}/${progress.total}).`;
}

function blocksProcedureCompletion(workOrder, procedureTemplateId = workOrder?.procedure_template_id) {
  return requiredChecklistCompletionMessage(workOrder, procedureTemplateId);
}

function renderMember(member) {
  const profile = profilesByUserId[member.user_id];
  const isCurrentUser = member.user_id === session.user.id;
  const canEditRole = canManageTeam() && !isCurrentUser;
  const workload = teamMemberWorkload(member.user_id);
  return `
    <article class="member-card">
      <div>
        <strong>${escapeHtml(profile?.full_name || (isCurrentUser ? session.user.email : member.user_id))}</strong>
        <p>${escapeHtml(roleDescription(member.role))}</p>
        <p>${isCurrentUser ? escapeHtml(session.user.email || member.user_id) : escapeHtml(member.user_id)}</p>
        <div class="member-workload">
          <span class="chip open">${workload.newWork} New</span>
          <span class="chip in_progress">${workload.inProgress} In Progress</span>
          <span class="chip blocked">${workload.blocked} Blocked</span>
          ${workload.overdue ? `<span class="chip overdue">${workload.overdue} Overdue</span>` : ""}
        </div>
      </div>
      <div class="member-card-actions">
        <button class="secondary-button view-member-work-button" data-view-member-work="${member.user_id}" type="button">View Work</button>
        ${canEditRole ? `
          <form class="member-role-form" data-member-role="${member.user_id}">
            <select name="role" aria-label="Role for ${escapeHtml(profile?.full_name || member.user_id)}">
              ${COMPANY_ROLES.map((role) => `<option value="${role}" ${role === normalizeRole(member.role) ? "selected" : ""}>${roleLabel(role)}</option>`).join("")}
            </select>
            <button class="secondary-button" type="submit">Save Role</button>
          </form>
        ` : `<span class="chip">${escapeHtml(roleLabel(member.role))}</span>`}
      </div>
    </article>
  `;
}

function renderMyProfileForm() {
  const profile = profilesByUserId[session.user.id] || {};
  return `
    <form class="team-profile-form relationship-detail comment" id="profile-form">
      <div>
        <h3>My Profile</h3>
        <p class="muted">${escapeHtml(session.user.email || "Signed in user")}</p>
      </div>
      <label>Display name<input name="full_name" value="${escapeHtml(profile.full_name || "")}" placeholder="Name shown on work orders"></label>
      <label class="check-row mobile-tech-setting"><input name="mobile_tech" type="checkbox" ${profile.mobile_tech ? "checked" : ""}> Mobile tech - I intentionally work across locations</label>
      <p class="muted">When Mobile tech is off, your location is locked so work does not accidentally land in the wrong branch.</p>
      <p class="error-text" id="profile-error"></p>
      <button class="secondary-button" type="submit">Save My Settings</button>
    </form>
  `;
}

function renderTeamInviteForm() {
  return `
    <form class="team-invite-form relationship-detail comment" id="team-invite-form">
      <div>
        <h3>Invite Teammate</h3>
        <p class="muted">They sign up with this email, then the app adds them to this company automatically.</p>
      </div>
      <label>Email<input name="email" type="text" inputmode="email" autocomplete="email" autocapitalize="none" spellcheck="false" required pattern="[^@\\s]+@[^@\\s]+\\.[^@\\s]+" placeholder="tech@company.com" ${teamInvitesReady ? "" : "disabled"}></label>
      <label>Role
        <select name="role" ${teamInvitesReady ? "" : "disabled"}>
          <option value="technician">Technician</option>
          <option value="manager">Manager</option>
          <option value="admin">Admin</option>
        </select>
      </label>
      <label>Default location
        <select name="default_location_id" ${teamInvitesReady && locations.length ? "" : "disabled"}>
          ${locations.length ? "" : `<option value="">Run location setup first</option>`}
          ${renderLocationOptions(activeLocationId)}
        </select>
      </label>
      <p class="error-text" id="team-invite-error">${teamInvitesReady ? "" : "Run supabase/step-next-invite-default-location.sql before inviting by email."}</p>
      <button class="secondary-button" type="submit" ${teamInvitesReady ? "" : "disabled"}>Create Invite</button>
    </form>
  `;
}

function renderTeamInvites() {
  const pending = teamInvites.filter((invite) => !invite.accepted_at);
  return `
    <section class="team-invites">
      <div class="panel-header compact">
        <h3>Pending Invites</h3>
        <span>${pending.length}</span>
      </div>
      <p class="error-text" id="team-invite-cancel-error">${escapeHtml(teamInviteCancelError)}</p>
      <div class="member-list">
        ${pending.map((invite) => `
          <article class="member-card invite-card">
            <div>
              <strong>${escapeHtml(invite.email)}</strong>
              <p>Sent ${new Date(invite.created_at).toLocaleString()}</p>
              <p>${escapeHtml(inviteDefaultLocationLabel(invite))}</p>
            </div>
            <div class="button-row">
              <span class="chip">${escapeHtml(invite.role)}</span>
              ${pendingCancelInviteId === invite.id ? `
                <button class="secondary-button" data-cancel-invite-cancel type="button">Keep</button>
                <button class="danger-action-button confirm-delete-button" data-confirm-cancel-invite="${escapeHtml(invite.id)}" type="button">Cancel Invite</button>
              ` : `
                <button class="danger-action-button" data-cancel-invite="${escapeHtml(invite.id)}" type="button">Cancel Invite</button>
              `}
            </div>
          </article>
        `).join("") || `<p class="muted">No pending invites.</p>`}
      </div>
    </section>
  `;
}

function renderMessageCenter() {
  if (!messagesReady) {
    return `<p class="muted">Run supabase/step-next-message-center.sql to enable company, location, and direct message threads.</p>`;
  }

  const activeThread = messageThreads.find((thread) => thread.id === activeMessageThreadId) || messageThreads[0];
  const threadMessages = activeThread ? (messagesByThreadId[activeThread.id] || []) : [];
  const visibleThreads = filteredMessageThreads();
  const linkedDraftWorkOrder = workOrders.find((workOrder) => workOrder.id === messageComposerWorkOrderId);

  return `
    <section class="message-center">
      <div class="message-layout">
        <aside class="message-thread-rail">
          <div class="message-rail-header">
            <div>
              <h3>Messages</h3>
              <p>${totalUnreadMessages()} unread</p>
            </div>
          </div>
          <form class="message-thread-form" id="message-thread-form">
            <details ${messageComposerOpen || linkedDraftWorkOrder ? "open" : ""}>
              <summary>New message</summary>
              <div class="message-thread-fields">
                <label>Send to
                  <select name="thread_type" id="message-thread-type">
                    <option value="company">Whole company</option>
                    <option value="location">Current location</option>
                    <option value="direct">Direct message</option>
                  </select>
                </label>
                <label class="message-direct-field">Person
                  <select name="direct_user_id">
                    ${companyMembers.filter((member) => member.user_id !== session.user.id).map((member) => `<option value="${member.user_id}">${escapeHtml(teamMemberName(member.user_id))}</option>`).join("") || `<option value="">No teammates yet</option>`}
                  </select>
                </label>
                <div class="message-scope-note" id="message-scope-note">${messageComposerScopeNote("company")}</div>
                <label>Subject<input name="title" required placeholder="Thread subject" value="${linkedDraftWorkOrder ? `Work order: ${escapeHtml(linkedDraftWorkOrder.title)}` : ""}"></label>
                ${linkedDraftWorkOrder ? `
                  <input name="work_order_id" type="hidden" value="${linkedDraftWorkOrder.id}">
                  <div class="message-linked-draft">
                    <span>Linked work order</span>
                    <strong>${escapeHtml(linkedDraftWorkOrder.title)}</strong>
                    <button class="text-button" data-clear-message-work-link type="button">Clear</button>
                  </div>
                ` : `
                  <label>Recent work order
                    <select name="work_order_id" ${messageWorkOrderLinksReady ? "" : "disabled"}>
                      <option value="">No work order</option>
                      ${recentMessageLinkWorkOrders().map((workOrder) => `<option value="${workOrder.id}">${escapeHtml(workOrder.title)} - ${statusLabel(workOrder.status)}</option>`).join("")}
                    </select>
                  </label>
                `}
                <label>Message<textarea name="body" rows="3" required placeholder="Type the first message..."></textarea></label>
                <p class="error-text" id="message-thread-error">${messageWorkOrderLinksReady ? "" : "Run supabase/step-next-message-work-order-links.sql before linking threads to work orders."}</p>
                <button class="secondary-button message-action-button" type="submit">Start Thread</button>
              </div>
            </details>
          </form>
          <label class="message-search">
            <input id="message-search" type="search" value="${escapeHtml(messageSearchQuery)}" placeholder="Search messages">
          </label>
          <div class="message-filter-bar" aria-label="Message thread filter">
            ${[
              ["all", "All"],
              ["unread", "Unread"],
              ["company", "Company"],
              ["location", "Location"],
              ["direct", "Direct"],
            ].map(([id, label]) => `<button class="${messageThreadFilter === id ? "active" : ""}" data-message-filter="${id}" type="button">${label}</button>`).join("")}
          </div>
          <div class="message-thread-list">
            ${visibleThreads.map(renderMessageThreadButton).join("") || `<p class="muted">No threads match this filter.</p>`}
          </div>
        </aside>
        <section class="message-thread-detail">
          ${activeThread ? `
            <div class="message-chat-header">
              <div>
                <h3>${escapeHtml(activeThread.title)}</h3>
                <p class="muted">${messageThreadScopeLabel(activeThread)}</p>
              </div>
              <div class="message-header-actions">
                ${activeThread.work_order_id ? `<button class="secondary-button message-linked-work-button" data-open-linked-work-order="${activeThread.work_order_id}" type="button">Open Work Order</button>` : ""}
                <span class="chip comment">${threadMessages.length} message${threadMessages.length === 1 ? "" : "s"}</span>
              </div>
            </div>
            <div class="message-list">
              ${renderMessageList(threadMessages)}
            </div>
            <form class="message-reply-form" id="message-reply-form" data-thread-id="${activeThread.id}">
              <div class="message-quick-replies">
                ${["On it", "Need more info", "Waiting on parts", "Complete"].map((reply) => `<button data-quick-reply="${escapeHtml(reply)}" type="button">${escapeHtml(reply)}</button>`).join("")}
              </div>
              <textarea name="body" rows="2" required placeholder="Reply to this thread..."></textarea>
              <p class="error-text" id="message-reply-error"></p>
              <button class="secondary-button message-action-button" type="submit">Send Reply</button>
            </form>
          ` : `<p class="muted">Choose or start a thread.</p>`}
        </section>
      </div>
    </section>
  `;
}

function messageThreadMembersForType(threadType, directUserId) {
  if (threadType === "direct") return [session.user.id, directUserId].filter(Boolean);
  return companyMembers.map((member) => member.user_id);
}

function recentMessageLinkWorkOrders() {
  return workOrders
    .filter((workOrder) => matchesActiveLocation(workOrder) && workOrder.status !== "completed")
    .slice(0, 8);
}

function filteredMessageThreads() {
  return messageThreads.filter((thread) => {
    const filterMatch =
      messageThreadFilter === "all" ||
      (messageThreadFilter === "unread" && unreadMessageCount(thread.id) > 0) ||
      thread.thread_type === messageThreadFilter;
    return filterMatch && matchesQuery(messageThreadSearchValues(thread), messageSearchQuery);
  });
}

function messageThreadSearchValues(thread) {
  const messages = messagesByThreadId[thread.id] || [];
  const participants = messageThreadMembers
    .filter((member) => member.thread_id === thread.id)
    .map((member) => teamMemberName(member.user_id));
  return [
    thread.title,
    messageThreadScopeLabel(thread),
    ...participants,
    ...messages.map((message) => message.body),
  ];
}

function unreadMessageCount(threadId) {
  const lastReadAt = messageReadsByThreadId[threadId]?.last_read_at;
  const lastReadTime = lastReadAt ? new Date(lastReadAt).getTime() : 0;
  return (messagesByThreadId[threadId] || []).filter((message) => {
    if (message.sender_id === session.user.id) return false;
    return new Date(message.created_at).getTime() > lastReadTime;
  }).length;
}

function totalUnreadMessages() {
  return messageThreads.reduce((total, thread) => total + unreadMessageCount(thread.id), 0);
}

function directUnreadMessages() {
  return messageThreads
    .filter((thread) => thread.thread_type === "direct")
    .reduce((total, thread) => total + unreadMessageCount(thread.id), 0);
}

function renderAppIssueReportForm() {
  return `
    <section class="panel full-width focus-panel app-issue-report-panel">
      <div class="panel-header">
        <h2>Report App Issue</h2>
        <button class="secondary-button back-action-button" data-cancel-app-issue-report type="button">Cancel</button>
      </div>
      <form class="form-grid app-issue-report-form" id="app-issue-report-form">
        <label>Short title<input name="title" required maxlength="140" placeholder="What broke or felt confusing?"></label>
        <label>Details<textarea name="details" rows="4" required placeholder="What were you trying to do, what happened, and what device were you on?"></textarea></label>
        <label>Severity
          <select name="severity">
            <option value="normal">Normal</option>
            <option value="blocking">Blocking</option>
            <option value="minor">Minor</option>
          </select>
        </label>
        <input name="screen" type="hidden" value="${escapeHtml(activeSection)}">
        <p class="muted">This sends the current company, location, screen, and signed-in user with the report.</p>
        <p class="error-text" id="app-issue-report-error">${appIssueReportsReady ? "" : "Run supabase/step-next-app-issue-reports.sql before saving app issue reports."}</p>
        <button class="primary-button" type="submit" ${appIssueReportsReady ? "" : "disabled"}>Send Report</button>
      </form>
    </section>
  `;
}

function setupItems() {
  return [
    {
      name: "Supabase config",
      ready: Boolean(window.SUPABASE_URL && window.SUPABASE_ANON_KEY),
      detail: window.SUPABASE_URL || "Missing supabase-config.js",
    },
    {
      name: "Company data",
      ready: Boolean(activeCompanyId),
      detail: activeCompanyId ? "Active tenant selected" : "Create or select a company",
    },
    {
      name: "Requests",
      ready: requestsReady,
      detail: requestsReady ? "Stored in maintenance_requests" : "Run step-next-maintenance-requests.sql",
    },
    {
      name: "Public request QR links",
      ready: publicRequestLinksReady,
      detail: publicRequestLinksReady ? "External location intake is available" : "Run step-next-public-request-links.sql",
    },
    {
      name: "Preventive schedules",
      ready: schedulesReady,
      detail: schedulesReady ? "PM schedules available" : "Run step-next-preventive-schedules.sql",
    },
    {
      name: "Procedures",
      ready: proceduresReady,
      detail: proceduresReady ? "Procedure templates available" : "Run step-next-procedures.sql",
    },
    {
      name: "Part costs",
      ready: partCostsReady,
      detail: partCostsReady ? "Unit costs available" : "Run step-next-part-costs.sql",
    },
    {
      name: "Part sources",
      ready: partSuppliersReady,
      detail: partSuppliersReady ? "Vendor/source names available" : "Run step-next-part-suppliers.sql",
    },
    {
      name: "Part files",
      ready: partDocumentsReady,
      detail: partDocumentsReady ? "Receipts and invoices can be filed with parts" : "Run step-next-part-documents.sql",
    },
    {
      name: "App issue reports",
      ready: appIssueReportsReady,
      detail: appIssueReportsReady ? "Live tester feedback can be captured" : "Run step-next-app-issue-reports.sql",
    },
    {
      name: "Message center",
      ready: messagesReady,
      detail: messagesReady ? "Company, location, and direct message threads available" : "Run step-next-message-center.sql",
    },
    {
      name: "Message work links",
      ready: messageWorkOrderLinksReady,
      detail: messageWorkOrderLinksReady ? "Message threads can link back to work orders" : "Run step-next-message-work-order-links.sql",
    },
    {
      name: "Work outcomes",
      ready: outcomesReady,
      detail: outcomesReady ? "Cause/resolution/follow-up available" : "Run step-next-work-order-outcomes.sql",
    },
    {
      name: "Safety checks",
      ready: safetyChecksReady,
      detail: safetyChecksReady ? "Asset safety check completion available" : "Run step-next-safety-checks.sql",
    },
    {
      name: "Admin delete protection",
      ready: adminDeleteSqlConfirmed,
      detail: adminDeleteSqlConfirmed
        ? "Admin-only delete SQL marked applied"
        : "Run step-next-admin-delete-work-orders.sql, then mark it applied",
      action: adminDeleteSqlConfirmed ? "" : "confirm-admin-delete-sql",
      actionLabel: "Mark SQL Applied",
    },
    {
      name: "Photos",
      ready: photosReady,
      detail: photosReady ? "Photo records available" : "Check storage bucket and photo table policies",
    },
  ];
}

function renderPartDetail() {
  const part = parts.find((item) => item.id === activePartId);
  if (!part) {
    activePartId = null;
    return `<p class="muted">Part not found.</p>`;
  }
  const quantity = Number(part.quantity_on_hand) || 0;
  const reorderPoint = Number(part.reorder_point) || 0;
  const unitCost = Number(part.unit_cost) || 0;
  const documents = partDocumentsByPartId[part.id] || [];
  return `
    <section class="part-detail-shell">
      ${renderPartSourceOptions()}
      <div class="part-detail-summary relationship-detail parts">
        <button class="secondary-button part-back-button" data-close-part-detail type="button">Back to parts</button>
        <div>
          <div class="chip-row">
            ${part.sku ? `<span class="chip">${escapeHtml(part.sku)}</span>` : ""}
            ${part.supplier_name ? `<span class="chip part-source-chip">${escapeHtml(part.supplier_name)}</span>` : ""}
            <span class="chip ${quantity <= reorderPoint ? "overdue" : "open"}">${quantity <= reorderPoint ? "low stock" : "stocked"}</span>
          </div>
          <h3>${escapeHtml(part.name)}</h3>
          <p>${quantity} on hand - reorder at ${reorderPoint}</p>
        </div>
      </div>

      <section class="part-detail-files relationship-detail parts">
        <div class="panel-header compact">
          <h3>Quick Inventory</h3>
          <span>stock movement</span>
        </div>
        <div class="part-card-actions">
          <form class="part-quantity-form use-part-form" data-use-part="${part.id}">
            <input name="quantity" type="number" min="1" step="1" value="1" aria-label="Use quantity for ${escapeHtml(part.name)}">
            <button class="secondary-button use-part-button" type="submit">Use</button>
          </form>
          <form class="part-quantity-form restock-form" data-restock-part="${part.id}">
            <input name="quantity" type="number" min="1" step="1" value="1" aria-label="Restock quantity for ${escapeHtml(part.name)}">
            <button class="secondary-button" type="submit">Restock</button>
          </form>
        </div>
      </section>

      <form class="part-detail-form relationship-detail parts" data-edit-part="${part.id}">
        <label>Name<input name="name" required value="${escapeHtml(part.name)}"></label>
        <label>SKU<input name="sku" value="${escapeHtml(part.sku || "")}"></label>
        <label>Source / vendor<input name="supplier_name" list="part-source-options" value="${escapeHtml(part.supplier_name || "")}" placeholder="Where this part usually comes from"><button class="text-button danger-link inline-label-action" data-toggle-part-sources type="button">Edit sources</button></label>
        <label>On hand<input name="quantity_on_hand" type="number" min="0" step="1" value="${quantity}"></label>
        <label>Reorder at<input name="reorder_point" type="number" min="0" step="1" value="${reorderPoint}"></label>
        <label>Listed unit cost<input name="unit_cost" type="number" min="0" step="0.01" value="${unitCost}"></label>
        <p class="error-text" data-part-edit-error="${part.id}"></p>
        <div class="button-row">
          <button class="secondary-button" type="submit">Save Part</button>
          <button class="text-button" data-close-part-detail type="button">Cancel</button>
        </div>
      </form>

      ${showPartSourceManager ? renderPartSourceManager() : ""}

      <section class="part-detail-files relationship-detail parts">
        <div class="panel-header compact">
          <h3>Filed Receipts / Invoices</h3>
          <span>${documents.length} file${documents.length === 1 ? "" : "s"}</span>
        </div>
        <form class="part-document-form" data-part-document="${part.id}">
          <label>Attach file<input name="document" type="file" accept="image/*,.pdf"></label>
          <p class="error-text" data-part-document-error="${part.id}">${partDocumentsReady ? "" : "Run supabase/step-next-part-documents.sql before attaching files."}</p>
          <button class="secondary-button" type="submit" ${partDocumentsReady ? "" : "disabled"}>Attach File</button>
        </form>
        <div class="mini-list part-document-list">
          ${documents.map((document) => `
            <article>
              <strong>${escapeHtml(document.file_name)}</strong>
              <span>${new Date(document.created_at).toLocaleString()}</span>
              ${document.signedUrl ? `<a href="${escapeHtml(document.signedUrl)}" target="_blank" rel="noreferrer">Open file</a>` : ""}
            </article>
          `).join("") || `<p class="muted">No receipts or invoices filed with this part.</p>`}
        </div>
      </section>

      ${renderPartDangerZone(part)}
    </section>
  `;
}

function renderPartDangerZone(part) {
  const usageCount = partUsageRows(part.id).length;
  const documents = partDocumentsByPartId[part.id] || [];
  const confirming = pendingDeletePartId === part.id;
  if (!canDeleteParts()) {
    return `<p class="muted">Admins and managers can delete unused parts.</p>`;
  }

  return `
    <section class="delete-zone part-delete-zone">
      <div>
        <h3>Delete Part</h3>
        <p>${usageCount
          ? `This part has ${usageCount} usage record${usageCount === 1 ? "" : "s"} tied to work order history, so it cannot be deleted.`
          : `This permanently removes the part${documents.length ? ` and ${documents.length} filed receipt/invoice record${documents.length === 1 ? "" : "s"}` : ""}.`}</p>
      </div>
      <p class="error-text" id="part-delete-error"></p>
      ${usageCount ? `
        <button class="danger-action-button large-delete-button" type="button" disabled>Kept For Traceability</button>
      ` : confirming ? `
        <div class="delete-warning-panel">
          <strong>Permanent Delete Warning</strong>
          <p>You are about to permanently delete "${escapeHtml(part.name)}". This cannot be undone.</p>
          <div class="button-row">
            <button class="secondary-button" data-cancel-delete-part type="button">Cancel</button>
            <button class="danger-action-button large-delete-button permanent-delete-button" data-delete-part="${escapeHtml(part.id)}" type="button">Permanently Delete</button>
          </div>
        </div>
      ` : `
        <button class="danger-action-button large-delete-button" data-delete-part="${escapeHtml(part.id)}" type="button">Delete Part</button>
      `}
    </section>
  `;
}

function renderPublicRequestLinkManager() {
  if (!canManageTeam()) return "";
  const publicBaseUrl = publicAppBaseUrl();
  return `
    <section class="settings-summary public-request-links">
      <div class="settings-section-heading">
        <h3>Location Request QR Links</h3>
        <p class="muted">Post these QR codes so operators can submit a location-specific request without app access.</p>
      </div>
      <form class="form-grid settings-form public-app-url-form" id="public-app-url-form">
        <label>Public MaintainOps URL
          <input name="public_app_url" value="${escapeHtml(publicAppUrlOverride || String(window.PUBLIC_APP_URL || ""))}" placeholder="https://loufish727.github.io/your-maintainops-repo/">
        </label>
        <button class="secondary-button request-action-button" type="submit">Save URL</button>
      </form>
      <p class="muted">Use the exact GitHub Pages URL where MaintainOps opens. Do not use the root URL if that opens another app.</p>
      ${publicBaseUrl ? `<p class="muted">QR codes will point to ${escapeHtml(publicBaseUrl)}</p>` : `<p class="warning-text">Set the public MaintainOps URL before copying or printing QR codes from this local app.</p>`}
      <p class="error-text" id="public-request-link-error">${publicRequestLinksReady ? "" : "Run supabase/step-next-public-request-links.sql before creating QR request links."}</p>
      <div class="public-request-link-grid">
        ${locations.map(renderPublicRequestLocationCard).join("") || `<article><strong>No locations yet</strong><span>Add a location before creating request QR codes.</span></article>`}
      </div>
    </section>
  `;
}

function renderPublicRequestLocationCard(location) {
  const link = publicRequestLinks.find((item) => item.location_id === location.id);
  const linkActive = Boolean(link && link.is_active !== false);
  const canAdministerLinks = canAdministerPublicRequestLinks();
  const requestUrl = linkActive ? publicRequestUrl(link.token) : "";
  const qrUrl = linkActive ? publicRequestQrUrl(link.token) : "";
  const hasUsableUrl = Boolean(requestUrl && qrUrl);
  return `
    <article class="public-request-link-card">
      <div>
        <strong>${escapeHtml(location.name)}</strong>
        <span>${linkActive ? "External request link active" : link ? "Request link disabled" : "No request link yet"}</span>
        ${link?.last_used_at ? `<span>Last used ${new Date(link.last_used_at).toLocaleString()}</span>` : ""}
      </div>
      ${linkActive ? `
        <div class="qr-preview">${hasUsableUrl ? qrSvgFor(requestUrl) : `<div class="qr-fallback">Set URL</div>`}</div>
        <input class="copy-field" value="${escapeHtml(qrUrl || "Set the public MaintainOps URL first")}" readonly>
        <div class="button-row">
          <a class="primary-button request-action-button ${hasUsableUrl ? "" : "disabled-link"}" href="${escapeHtml(qrUrl || "#")}" target="_blank" rel="noreferrer">Open QR Code</a>
          <button class="secondary-button request-action-button" data-copy-public-request-link="${escapeHtml(qrUrl)}" type="button" ${hasUsableUrl ? "" : "disabled"}>Copy QR Link</button>
          <a class="secondary-button ${hasUsableUrl ? "" : "disabled-link"}" href="${escapeHtml(requestUrl || "#")}" target="_blank" rel="noreferrer">Test Form</a>
          ${canAdministerLinks ? `
            <button class="secondary-button request-action-button" data-regenerate-public-request-link="${escapeHtml(link.id)}" type="button">Regenerate QR</button>
            <button class="secondary-button danger-link" data-disable-public-request-link="${escapeHtml(link.id)}" type="button">Disable Link</button>
          ` : `<span class="muted">Only admins can replace or disable posted QR codes.</span>`}
        </div>
      ` : link ? `
        <div class="qr-preview inactive-qr-preview"><div class="qr-fallback">Off</div></div>
        <div class="button-row">
          ${canAdministerLinks ? `
            <button class="secondary-button request-action-button" data-enable-public-request-link="${escapeHtml(link.id)}" type="button">Reactivate Same QR</button>
            <button class="primary-button request-action-button" data-regenerate-public-request-link="${escapeHtml(link.id)}" type="button">Regenerate QR</button>
          ` : `<span class="muted">Only admins can reactivate or replace this QR code.</span>`}
        </div>
      ` : `
        <button class="secondary-button request-action-button" data-create-public-request-link="${escapeHtml(location.id)}" type="button" ${publicRequestLinksReady ? "" : "disabled"}>Create QR Link</button>
      `}
    </article>
  `;
}

function publicRequestUrl(token) {
  return publicAppUrlWithSearch(`?request=${encodeURIComponent(token)}`);
}

function publicRequestQrUrl(token) {
  return publicAppUrlWithSearch(`?qr=${encodeURIComponent(token)}`);
}

function publicAppUrlWithSearch(search) {
  const base = publicAppBaseUrl();
  if (!base) return "";
  const url = new URL(base);
  url.search = search;
  url.hash = "";
  return url.toString();
}

function publicAppBaseUrl() {
  const configured = publicAppUrlOverride || String(window.PUBLIC_APP_URL || "").trim();
  const candidate = configured || (window.location.protocol === "https:" ? window.location.href : "");
  if (!candidate) return "";
  return normalizePublicAppUrl(candidate);
}

function normalizePublicAppUrl(value) {
  try {
    const url = new URL(String(value || "").trim(), window.location.href);
    if (url.protocol !== "https:") return "";
    if (!isPublicAppHost(url.hostname)) return "";
    url.search = "";
    url.hash = "";
    if (url.pathname && url.pathname !== "/" && !url.pathname.endsWith("/") && !url.pathname.endsWith(".html")) {
      url.pathname = `${url.pathname}/`;
    }
    return url.toString();
  } catch (error) {
    return "";
  }
}

function isPublicAppHost(hostname) {
  const host = String(hostname || "").toLowerCase();
  if (!host || host === "localhost" || host.endsWith(".localhost")) return false;
  if (host === "127.0.0.1" || host === "::1" || host === "[::1]") return false;
  if (/^10\./.test(host) || /^192\.168\./.test(host)) return false;
  if (/^172\.(1[6-9]|2\d|3[0-1])\./.test(host)) return false;
  return true;
}

function qrSvgFor(value, cellSize = 4) {
  if (!window.qrcode || !value) return `<div class="qr-fallback">QR</div>`;
  try {
    const qr = window.qrcode(0, "M");
    qr.addData(value);
    qr.make();
    return qr.createSvgTag(cellSize, 0).replace("<svg", "<svg class=\"qr-code\"");
  } catch (error) {
    return `<div class="qr-fallback">QR</div>`;
  }
}

function renderMaintenanceRequest(request) {
  const converted = isConvertedRequest(request);
  const confirming = pendingDeleteRequestId === request.id;
  const deleteControls = canDeleteOperationalRecords() ? confirming ? `
    <button class="secondary-button" data-cancel-delete-request type="button">Cancel</button>
    <button class="danger-action-button confirm-delete-button" data-confirm-delete-request="${escapeHtml(request.id)}" type="button">Permanently Delete</button>
  ` : `
    <button class="danger-action-button" data-delete-request="${escapeHtml(request.id)}" type="button">Delete</button>
  ` : "";
  return `
    <article class="request-card ${converted ? "converted-request" : "active-request"}">
      <div class="request-card-main">
        <div class="chip-row">
          <span class="chip ${request.priority}">${escapeHtml(request.priority)}</span>
          <span class="chip ${converted ? "completed" : "open"}">${converted ? "converted" : escapeHtml(request.status)}</span>
        </div>
        <h3>${escapeHtml(request.title)}</h3>
        <p>${escapeHtml(request.description || "No description.")}</p>
        ${renderMaintenanceRequestPhoto(request)}
        <div class="meta-row">
          <span>${escapeHtml(request.assets?.name || request.locations?.name || "No equipment")}</span>
          <span>${escapeHtml(request.requested_by_name || profilesByUserId[request.requested_by]?.full_name || "Requester")}</span>
          <span>${new Date(request.created_at).toLocaleString()}</span>
        </div>
      </div>
      ${!converted && request.status === "submitted" ? `
        <div class="request-actions">
          <button class="secondary-button request-action-button" data-quick-fix-request="${request.id}" type="button">Quick Fix</button>
          <button class="secondary-button work-action-button" data-convert-request="${request.id}" type="button">Convert to Work Order</button>
          ${deleteControls}
        </div>
      ` : `
        <div class="request-actions request-converted-note">
          <span>Converted to work order</span>
          ${deleteControls}
        </div>
      `}
    </article>
  `;
}

function renderRequestFormContent() {
  return `
    <form class="form-grid" id="request-form">
      <label>Request title<input name="title" required placeholder="Cold room door not sealing"></label>
      <label>What is happening?<textarea name="description" rows="4" required></textarea></label>
      <label>Photo<input name="photo" type="file" accept="image/*" capture="environment"><small>Optional. Photos are optimized up to 2400px before upload.</small></label>
      <label>Machine / equipment
        <select name="asset_id" data-location-sensitive-asset>
          <option value="">Unknown or general location</option>
          ${renderAssetOptions()}
        </select>
      </label>
      <p class="error-text" data-asset-location-warning></p>
      <label>Priority
        <select name="priority">
          <option>medium</option>
          <option>high</option>
          <option>critical</option>
          <option>low</option>
        </select>
      </label>
      <p class="error-text" id="request-error"></p>
      <button class="primary-button request-action-button" type="submit">Submit Request</button>
    </form>
  `;
}

function renderWorkOrderCard(workOrder) {
    const dueState = getDueState(workOrder);
    const procedure = procedureTemplates.find((template) => template.id === workOrder.procedure_template_id);
    return `
      <article class="work-card status-card status-${workOrder.status} ${workOrder.id === activeWorkOrderId ? "selected" : ""}" data-id="${workOrder.id}" tabindex="0">
        <div class="work-card-header">
          <div class="chip-row">
            <span class="chip ${workOrder.priority}">${workOrder.priority}</span>
            <span class="chip">${escapeHtml(workOrder.type || "reactive")}</span>
            <span class="chip ${workOrder.status}">${statusLabel(workOrder.status)}</span>
            ${dueState ? `<span class="chip ${dueState.className}">${dueState.label}</span>` : ""}
          </div>
        </div>
        <div class="work-card-body">
          <h3>${escapeHtml(workOrder.title)}</h3>
          <p>${escapeHtml(cleanWorkOrderDescription(workOrder.description) || "No description.")}</p>
        </div>
        <div class="work-card-meta meta-row">
          <span>${relationshipIcon("asset")}${escapeHtml(workOrder.assets?.name || "General item / area")}</span>
          <span>${segmentIcon(isVendorAssigned(workOrder) ? "vendor" : "mine")}${escapeHtml(assignmentLabel(workOrder))}</span>
          ${procedure ? `<span>${relationshipIcon("procedure")}${escapeHtml(procedure.name)}</span>` : ""}
          <span>${segmentIcon("due")}Due ${workOrder.due_at || "unset"}</span>
          ${workOrder.completed_at ? `<span>${segmentIcon("completed")}Completed ${new Date(workOrder.completed_at).toLocaleDateString()}</span>` : ""}
        </div>
        ${renderRelationshipChips(workOrder)}
        <div class="quick-actions work-card-actions">
          ${canAssignWorkOrderToMe(workOrder) ? `<button class="assign-action" data-assign-me="${workOrder.id}" type="button">Assign to me</button>` : ""}
          ${canManageTeam() ? renderCardAssignmentControl(workOrder) : ""}
        ${STATUS_OPTIONS.filter((status) => status !== workOrder.status).slice(0, 3).map((status) => `
          <button data-quick-status="${status}" data-id="${workOrder.id}" type="button">${statusLabel(status)}</button>
        `).join("")}
      </div>
    </article>
  `;
}

function renderCardAssignmentControl(workOrder) {
  return `
    <form class="card-assign-form" data-card-assign="${workOrder.id}">
      <select name="assigned_to" aria-label="Assign ${escapeHtml(workOrder.title)}">
        <option value="">Unassigned</option>
        <option value="${OUTSIDE_VENDOR_VALUE}" ${isVendorAssigned(workOrder) ? "selected" : ""}>Outside vendor</option>
        ${Object.entries(profilesByUserId).map(([userId, profile]) => `<option value="${userId}" ${!isVendorAssigned(workOrder) && userId === workOrder.assigned_to ? "selected" : ""}>${escapeHtml(profile.full_name || teamMemberName(userId))}</option>`).join("")}
      </select>
      <button class="card-assign-button" type="submit">Assign</button>
    </form>
  `;
}

function renderAssignmentSelect(selectedValue = "", options = {}) {
  const selected = selectedValue || "";
  const allowManagerOptions = options.managerOptions ?? canManageTeam();
  const allowUnassigned = options.allowUnassigned !== false;
  const selfLabel = options.selfLabel || "Assign to me";
  const optionsHtml = [];
  if (allowUnassigned) {
    optionsHtml.push(`<option value="" ${selected === "" ? "selected" : ""}>Unassigned</option>`);
  }
  optionsHtml.push(`<option value="${session.user.id}" ${selected === session.user.id ? "selected" : ""}>${selfLabel}</option>`);
  if (allowManagerOptions) {
    optionsHtml.push(`<option value="${OUTSIDE_VENDOR_VALUE}" ${selected === OUTSIDE_VENDOR_VALUE ? "selected" : ""}>Outside vendor</option>`);
    optionsHtml.push(...Object.entries(profilesByUserId)
      .filter(([userId]) => userId !== session.user.id)
      .map(([userId, profile]) => `<option value="${userId}" ${selected === userId ? "selected" : ""}>${escapeHtml(profile.full_name || teamMemberName(userId))}</option>`));
  }
  return optionsHtml.join("");
}

function assignmentFormValue(workOrder) {
  if (isVendorAssigned(workOrder)) return OUTSIDE_VENDOR_VALUE;
  return workOrder?.assigned_to || "";
}

function renderWorkOrderAssignmentField(workOrder, id = "") {
  const currentValue = assignmentFormValue(workOrder);
  if (canManageTeam()) {
    return `
      <label ${id ? `id="${id}"` : ""}>Assign to
        <select name="assigned_to">
          ${renderAssignmentSelect(currentValue, { managerOptions: true })}
        </select>
      </label>
    `;
  }
  if (!workOrder.assigned_to && !isVendorAssigned(workOrder)) {
    return `
      <label ${id ? `id="${id}"` : ""}>Assign to
        <select name="assigned_to">
          ${renderAssignmentSelect("", { managerOptions: false, selfLabel: "Assign to me" })}
        </select>
      </label>
    `;
  }
  return `
    <label ${id ? `id="${id}"` : ""}>Assigned to
      <input value="${escapeHtml(assignmentLabel(workOrder))}" disabled>
      <input name="assigned_to" type="hidden" value="${escapeHtml(currentValue)}">
    </label>
  `;
}

function renderCreateWorkOrder() {
  return `
    <form class="form-grid create-work-order-template relationship-detail asset" id="create-work-order-form">
      <div>
        <h3>Create Work Order</h3>
        <p class="muted">Build a complete work order step by step.</p>
      </div>

      <div class="form-section-title">1. What needs attention?</div>
      <label>Title<input name="title" required placeholder="Inspect packaging line sensor"></label>
      <label>Description<textarea name="description" rows="2" placeholder="What is happening, where, and what should be checked?"></textarea></label>
      <div class="equipment-choice">
        <label>Machine / equipment
          <select name="asset_id" data-location-sensitive-asset>
            <option value="">No machine / equipment - general item or area</option>
            ${renderAssetOptions()}
          </select>
        </label>
        <span>or</span>
        <label>New machine / equipment name<input name="new_asset_name" placeholder="Roll Former 3"></label>
      </div>
      <p class="error-text" data-asset-location-warning></p>

      <details class="quick-fix-more" open>
        <summary>2. Priority and timing</summary>
        <div class="form-grid">
          <label>Status
            <select name="status">
              ${STATUS_OPTIONS.map((status) => `<option value="${status}" ${status === "open" ? "selected" : ""}>${statusLabel(status)}</option>`).join("")}
            </select>
          </label>
          <label>Priority
            <select name="priority">
              <option>medium</option>
              <option>high</option>
              <option>critical</option>
              <option>low</option>
            </select>
          </label>
          <label>Type
            <select name="type">
              ${TYPE_OPTIONS.filter((type) => type !== "request").map((type) => `<option value="${type}">${type}</option>`).join("")}
            </select>
          </label>
          <label>Expected back up / due date<input name="due_at" type="text" inputmode="numeric" placeholder="YYYY-MM-DD"></label>
        </div>
      </details>

      <details class="quick-fix-more">
        <summary>3. People and procedure</summary>
        <div class="form-grid">
          <label>Assign to
            <select name="assigned_to">
              ${renderAssignmentSelect("", { selfLabel: "Assign to me" })}
            </select>
          </label>
          <label>Procedure
            <select name="procedure_template_id">
              ${renderProcedureOptions()}
            </select>
          </label>
        </div>
      </details>

      <details class="quick-fix-more">
        <summary>4. Internal notes and completion</summary>
        <div class="form-grid">
          <label>Cause / finding<textarea name="failure_cause" rows="2" placeholder="What caused the issue, or what did you find?"></textarea></label>
          <label>Resolution<textarea name="resolution_summary" rows="2" placeholder="What action fixed it?"></textarea></label>
          <label class="check-row"><input name="follow_up_needed" type="checkbox"> Follow-up needed</label>
          <label class="check-row safety-check-row"><input name="safety_devices_checked" type="checkbox"> Safety devices checked before completion: E-stops, sensors, guards, and interlocks</label>
          <label>Actual minutes<input name="actual_minutes" type="number" min="0" step="5" value="0"></label>
          <label>Completion notes<textarea name="completion_notes" rows="2" placeholder="Final notes if this is already complete."></textarea></label>
        </div>
      </details>

      <details class="quick-fix-more">
        <summary>5. Parts, photo, and first comment</summary>
        <div class="form-grid">
          <label>Part used
            <select name="part_id">
              <option value="">No part used</option>
              ${parts.map((part) => `<option value="${part.id}">${escapeHtml(part.name)} (${part.quantity_on_hand} on hand)</option>`).join("")}
            </select>
          </label>
          <label>Quantity used<input name="quantity_used" type="number" min="1" step="1" value="1"></label>
          <label>Photo<input name="photo" type="file" accept="image/*" capture="environment"><small>Optional. Photos are optimized up to 2400px before upload.</small></label>
          <label>First comment<textarea name="initial_comment" rows="2" placeholder="Add the first update or note for the record."></textarea></label>
        </div>
      </details>

      <p class="error-text" id="create-work-order-error"></p>
      <button class="primary-button work-action-button quick-fix-submit" type="submit">Create Work Order</button>
    </form>
  `;
}

function renderQuickFixForm() {
  const selectedAssetId = quickFixAssetId || "";
  const sourceRequest = maintenanceRequests.find((request) => request.id === quickFixRequestId);
  return `
    <form class="form-grid quick-fix-form relationship-detail comment" id="quick-fix-form">
      <div>
        <h3>Quick Fix</h3>
        <p class="muted">Log the issue now. Details can be added later.</p>
      </div>
      ${sourceRequest ? `<p class="completion-note">Resolving request: ${escapeHtml(sourceRequest.title)}</p>` : ""}
      <label>Issue<input name="title" required autofocus placeholder="Loose guard switch fixed" value="${escapeHtml(sourceRequest?.title || "")}"></label>
      <label>Machine / equipment
        <select name="asset_id" data-location-sensitive-asset>
          <option value="">No machine / equipment - general item or area</option>
          ${renderAssetOptions(selectedAssetId || sourceRequest?.asset_id || "")}
        </select>
        <small>Machine or equipment not listed? Add it below.</small>
      </label>
      <p class="error-text" data-asset-location-warning>${escapeHtml(assetLocationRoutingMessage(selectedAssetId || sourceRequest?.asset_id || ""))}</p>
      <label>New machine / equipment name<input name="new_asset_name" placeholder="Packaging Line 2"></label>
      <label>Photo<input name="photo" type="file" accept="image/*" capture="environment"><small>Optional. Photos are optimized up to 2400px before upload.</small></label>
      <label class="check-row"><input name="machine_down" type="checkbox"> Machine is down</label>
      <label class="check-row"><input name="mark_completed" type="checkbox"> Already fixed - mark complete now</label>
      <label class="check-row safety-check-row"><input name="safety_devices_checked" type="checkbox"> Safety devices checked if completing equipment work: E-stops, sensors, guards, and interlocks</label>
      <details class="quick-fix-more">
        <summary>Optional details</summary>
        <div class="form-grid">
          <div class="form-section-title">Work Order Info</div>
          <label>Expected back up / due date<input name="due_at" type="text" inputmode="numeric" placeholder="YYYY-MM-DD"></label>
          <label>Priority
            <select name="priority">
              ${["medium", "high", "critical", "low"].map((priority) => `<option value="${priority}">${priority}</option>`).join("")}
            </select>
          </label>
          <label>Type
            <select name="type">
              ${TYPE_OPTIONS.filter((type) => type !== "request").map((type) => `<option value="${type}" ${type === "corrective" ? "selected" : ""}>${type}</option>`).join("")}
            </select>
          </label>
          <label>Assign to
            <select name="assigned_to">
              ${renderAssignmentSelect(session.user.id, { selfLabel: "Assign to me" })}
            </select>
          </label>
          <label>Procedure
            <select name="procedure_template_id">
              ${renderProcedureOptions()}
            </select>
          </label>
          <div class="form-section-title">Outcome / Notes</div>
          <label>What did you do?<textarea name="resolution_summary" rows="2" placeholder="Tightened mount, tested switch, line returned to normal."></textarea></label>
          <label>Cause / finding<textarea name="failure_cause" rows="2" placeholder="Loose mount, worn part, operator report, unknown...">${escapeHtml(sourceRequest?.description || "")}</textarea></label>
        <label>Equipment status after fix
          <select name="asset_status">
            <option value="">Leave unchanged</option>
              ${["running", "watch", "degraded", "offline"].map((status) => `<option value="${status}">${assetStatusLabel(status)}</option>`).join("")}
          </select>
        </label>
          <label>Part used
            <select name="part_id">
              <option value="">No part used</option>
              ${parts.map((part) => `<option value="${part.id}">${escapeHtml(part.name)} (${part.quantity_on_hand} on hand)</option>`).join("")}
            </select>
          </label>
          <label>Quantity used<input name="quantity_used" type="number" min="1" step="1" value="1"></label>
          <label class="check-row"><input name="follow_up_needed" type="checkbox"> Follow-up needed</label>
        </div>
      </details>
      <p class="error-text" id="quick-fix-error"></p>
      <button class="primary-button quick-fix-submit" type="submit">Log Quick Fix</button>
    </form>
  `;
}

function renderWorkOrderDetail() {
  const workOrder = workOrders.find((item) => item.id === activeWorkOrderId);
  if (!workOrder) return renderMissingWorkOrderDetail();
  const comments = commentsByWorkOrder[workOrder.id] || [];
  const photos = photosByWorkOrder[workOrder.id] || [];
  const events = eventsByWorkOrder[workOrder.id] || [];
  const usedParts = partsUsedByWorkOrder[workOrder.id] || [];
  const partsCost = usedParts.reduce((sum, row) => sum + ((Number(row.quantity_used) || 0) * partUsageUnitCost(row)), 0);
  const partsQuantity = usedParts.reduce((sum, row) => sum + (Number(row.quantity_used) || 0), 0);
  const activity = buildActivityFeed(comments, photos, events, usedParts);
  const procedure = procedureTemplates.find((template) => template.id === workOrder.procedure_template_id);
  const progress = procedure ? checklistProgress(workOrder, procedure) : null;
  const requiredProgress = procedure ? requiredChecklistProgress(workOrder, procedure) : null;

  return `
    <div class="detail-stack">
      <div>
        <div class="chip-row">
          <span class="chip ${workOrder.priority}">${workOrder.priority}</span>
          <span class="chip">${escapeHtml(workOrder.type || "reactive")}</span>
          <span class="chip ${workOrder.status}">${statusLabel(workOrder.status)}</span>
        </div>
        <h2>${escapeHtml(workOrder.title)}</h2>
        <p>${escapeHtml(cleanWorkOrderDescription(workOrder.description) || "No description.")}</p>
        ${renderRelationshipChips(workOrder)}
        ${workOrder.completed_at ? `<p class="completion-note">Completed ${new Date(workOrder.completed_at).toLocaleString()} Â· ${workOrder.actual_minutes || 0} min</p>` : ""}
        ${workOrder.asset_id && hasCompletedSafetyDeviceCheck(workOrder) ? `<p class="completion-note">Safety devices checked before completion.</p>` : ""}
        ${workOrder.completion_notes ? `<p>${escapeHtml(workOrder.completion_notes)}</p>` : ""}
      </div>

      ${renderWorkOrderCommandSummary(workOrder)}
      ${renderWorkOrderRecommendation(workOrder)}

      ${workOrder.completed_at && (workOrder.failure_cause || workOrder.resolution_summary || workOrder.follow_up_needed) ? `
        <div class="outcome-summary">
          <h3>Work Outcome</h3>
          ${workOrder.failure_cause ? `<article><span>Cause</span><strong>${escapeHtml(workOrder.failure_cause)}</strong></article>` : ""}
          ${workOrder.resolution_summary ? `<article><span>Resolution</span><strong>${escapeHtml(workOrder.resolution_summary)}</strong></article>` : ""}
          ${workOrder.follow_up_needed ? `<article class="follow-up"><span>Follow-up</span><strong>Needed</strong></article>` : ""}
        </div>
      ` : ""}

      <label>Status
        <select id="status-select">
          ${STATUS_OPTIONS.map((status) => `<option value="${status}" ${status === workOrder.status ? "selected" : ""}>${statusLabel(status)}</option>`).join("")}
        </select>
      </label>

      <div class="quick-actions detail-quick-actions">
        ${canAssignWorkOrderToMe(workOrder) ? `<button class="assign-action" data-assign-me="${workOrder.id}" type="button">${workOrder.assigned_to ? "Reassign to me" : "Assign to me"}</button>` : ""}
        ${STATUS_OPTIONS.filter((status) => status !== workOrder.status).map((status) => `
          <button data-quick-status="${status}" data-id="${workOrder.id}" type="button">${statusLabel(status)}</button>
        `).join("")}
      </div>
      ${workOrderActionWarningId === workOrder.id && workOrderActionWarning ? `<p class="error-text action-warning">${escapeHtml(workOrderActionWarning)}</p>` : ""}

      <details class="quick-update-panel relationship-detail comment work-detail-section" open>
        <summary>Quick Update</summary>
        <form class="form-grid" id="quick-update-work-order-form">
          <label id="quick-update-issue-field">Issue<input name="title" required value="${escapeHtml(workOrder.title)}"></label>
          <div class="equipment-choice" id="quick-update-equipment-field">
            <label>Machine / equipment
              <select name="asset_id" data-location-sensitive-asset>
                <option value="">No machine / equipment - general item or area</option>
                ${renderAssetOptions(workOrder.asset_id || "")}
              </select>
            </label>
            <span>or</span>
            <label>New machine / equipment name<input name="new_asset_name" placeholder="Roll Former 3"></label>
          </div>
          <p class="error-text" data-asset-location-warning>${escapeHtml(assetLocationRoutingMessage(workOrder.asset_id || ""))}</p>
          <label id="quick-update-resolution-field">Resolution<textarea name="resolution_summary" rows="2" placeholder="What action fixed it?">${escapeHtml(workOrder.resolution_summary || "")}</textarea></label>
          <label id="quick-update-due-field">Expected back up / due date<input name="due_at" type="text" inputmode="numeric" placeholder="YYYY-MM-DD" value="${escapeHtml(workOrder.due_at || "")}"></label>
          <label id="quick-update-status-field">Status
            <select name="status">
              ${STATUS_OPTIONS.map((status) => `<option value="${status}" ${status === workOrder.status ? "selected" : ""}>${statusLabel(status)}</option>`).join("")}
            </select>
          </label>
          <label>Priority
            <select name="priority">
              ${["low", "medium", "high", "critical"].map((priority) => `<option value="${priority}" ${priority === workOrder.priority ? "selected" : ""}>${priority}</option>`).join("")}
            </select>
          </label>
          ${renderWorkOrderAssignmentField(workOrder, "quick-update-owner-field")}
          <label class="check-row"><input name="machine_down" type="checkbox" ${workOrder.assets?.status === "offline" ? "checked" : ""}> Machine is down</label>
          ${requiresSafetyDeviceCheck(workOrder) ? (
            `<label class="check-row safety-check-row" id="quick-update-safety-field"><input name="safety_devices_checked" type="checkbox" ${workOrder.safety_devices_checked ? "checked" : ""}> Safety devices checked before completion: E-stops, sensors, guards, and interlocks</label>`
          ) : `<div class="safety-check-row safety-pending-note" id="quick-update-safety-field"><strong>Safety devices</strong><span>No machine / equipment selected, so no equipment safety check is required.</span></div>`}
          <p class="error-text" id="quick-update-error"></p>
          <button class="primary-button quick-fix-submit" type="submit">Save Quick Update</button>
        </form>
      </details>

      <div class="downtime-copy relationship-detail asset" id="work-order-email-helper-target">
        <div>
          <h3>Email Helper</h3>
          <p class="muted">Copy a human update for email when this machine/equipment is down or needs attention.</p>
        </div>
        <div class="quick-actions">
          <button class="secondary-button" data-copy-downtime="subject" data-id="${workOrder.id}" type="button">Copy Subject</button>
          <button class="secondary-button" data-copy-downtime="body" data-id="${workOrder.id}" type="button">Copy Email Body</button>
        </div>
      </div>

      ${renderWorkOrderMessages(workOrder)}

      <details class="work-detail-section relationship-detail asset">
        <summary>Full Work Order Details</summary>
      <form class="form-grid" id="edit-work-order-form">
        <label>Title<input name="title" required value="${escapeHtml(workOrder.title)}"></label>
        <label>Description<textarea name="description" rows="3">${escapeHtml(cleanWorkOrderDescription(workOrder.description) || "")}</textarea></label>
        <label>Due date<input name="due_at" type="text" inputmode="numeric" placeholder="YYYY-MM-DD" value="${escapeHtml(workOrder.due_at || "")}"></label>
        <label>Priority
          <select name="priority">
            ${["low", "medium", "high", "critical"].map((priority) => `<option value="${priority}" ${priority === workOrder.priority ? "selected" : ""}>${priority}</option>`).join("")}
          </select>
        </label>
        <label>Type
          <select name="type">
            ${TYPE_OPTIONS.map((type) => `<option value="${type}" ${type === (workOrder.type || "reactive") ? "selected" : ""}>${type}</option>`).join("")}
          </select>
        </label>
        ${renderWorkOrderAssignmentField(workOrder)}
        <label>Procedure
          <select name="procedure_template_id">
            ${renderProcedureOptions(workOrder.procedure_template_id || "")}
          </select>
        </label>
        <div class="form-section-title">Internal Record</div>
        <label>Cause / finding<textarea name="failure_cause" rows="2" placeholder="What caused the issue, or what did you find?">${escapeHtml(workOrder.failure_cause || "")}</textarea></label>
        <label>Resolution<textarea name="resolution_summary" rows="2" placeholder="What action fixed it?">${escapeHtml(workOrder.resolution_summary || "")}</textarea></label>
        <label class="check-row"><input name="follow_up_needed" type="checkbox" ${workOrder.follow_up_needed ? "checked" : ""}> Follow-up needed</label>
        ${requiresSafetyDeviceCheck(workOrder) ? `
          <label class="check-row safety-check-row">
            <input name="safety_devices_checked" type="checkbox" ${workOrder.safety_devices_checked ? "checked" : ""}>
            Safety devices checked before completion: E-stops, sensors, guards, and interlocks
          </label>
        ` : ""}
        <label>Actual minutes<input name="actual_minutes" type="number" min="0" step="5" value="${workOrder.actual_minutes || 0}"></label>
        <p class="error-text" id="work-order-save-error"></p>
        <button class="secondary-button save-work-button" type="submit">Save Work Order</button>
      </form>
      </details>

      ${procedure ? `
        <details class="work-detail-section relationship-detail procedure">
          <summary>Procedure Checklist</summary>
          <div class="panel-header compact-header">
            <h3>${escapeHtml(procedure.name)}</h3>
            <span>${progress.done} of ${progress.total} complete Â· required ${requiredProgress.done}/${requiredProgress.total}</span>
          </div>
          <div class="checklist-list">
            ${procedure.procedure_steps.map((step) => renderChecklistStep(workOrder, step)).join("") || `<p class="muted">This procedure has no steps yet.</p>`}
          </div>
        </details>
      ` : ""}

      ${workOrder.status !== "completed" ? `
        <details class="work-detail-section completion-section" id="work-order-complete-target">
          <summary>Complete Work</summary>
        <form class="completion-box" id="complete-work-order-form">
          <h3>Complete Work</h3>
          ${requiredProgress?.total ? `<p class="${requiredProgress.done === requiredProgress.total ? "completion-note" : "warning-text"}">Required checklist: ${requiredProgress.done}/${requiredProgress.total}</p>` : ""}
          <label>Cause / finding<textarea name="failure_cause" rows="2" placeholder="What caused the issue, or what did you find?"></textarea></label>
          <label>Resolution<textarea name="resolution_summary" rows="2" placeholder="What action fixed it?"></textarea></label>
          <label class="check-row"><input name="follow_up_needed" type="checkbox"> Follow-up needed</label>
          <label>Actual minutes<input name="actual_minutes" type="number" min="0" step="5" value="${workOrder.actual_minutes || 0}"></label>
          <label>Completion notes<textarea name="completion_notes" rows="3" placeholder="What was fixed? Any follow-up needed?"></textarea></label>
          ${requiresSafetyDeviceCheck(workOrder) ? `
            <label class="check-row safety-check-row">
              <input name="safety_devices_checked" type="checkbox" required ${hasCompletedSafetyDeviceCheck(workOrder) ? "checked" : ""}>
              Safety devices checked and functioning: E-stops, sensors, guards, and interlocks
            </label>
          ` : ""}
          <p class="error-text" id="completion-error"></p>
          <button class="primary-button" type="submit">Complete Work Order</button>
        </form>
        </details>
      ` : ""}

      <details class="work-detail-section relationship-detail parts" id="work-order-parts-target">
        <summary>Parts Used</summary>
      <form class="form-grid relationship-detail parts" id="parts-used-form">
        <h3>Parts Used</h3>
        <label>Part
          <select name="part_id" required>
            <option value="">Select part</option>
            ${parts.map((part) => `<option value="${part.id}">${escapeHtml(part.name)} (${part.quantity_on_hand} on hand)</option>`).join("")}
          </select>
        </label>
        <label>Quantity used<input name="quantity_used" type="number" min="1" step="1" value="1"></label>
        <p class="error-text" id="parts-used-error"></p>
        <button class="secondary-button" type="submit">Record Part Used</button>
      </form>

      <div class="parts-used-list">
        ${usedParts.length ? `<article class="parts-used-summary"><strong>Parts estimate</strong><span>${money(partsCost)}</span></article>` : ""}
        ${usedParts.map((row) => `
          <article class="relationship-detail parts">
            <strong>${escapeHtml(row.parts?.name || "Part")}</strong>
            <span>${row.quantity_used} used - ${money((Number(row.quantity_used) || 0) * partUsageUnitCost(row))}</span>
          </article>
        `).join("") || `<p class="muted">No parts used yet.</p>`}
      </div>
      </details>

      <details class="work-detail-section relationship-detail photo" id="work-order-photos-target">
        <summary>Photos</summary>
      <form class="form-grid relationship-detail photo" id="photo-form">
        <label>Upload photo<input name="photo" type="file" accept="image/*"><small>Photos are optimized up to 2400px before upload.</small></label>
        <p class="error-text" id="photo-error"></p>
        <button class="secondary-button" type="submit">Upload Photo</button>
      </form>

      <div>
        <h3>Photos</h3>
        <div class="photo-list">
          ${photos.map((photo) => `
            <article class="relationship-detail photo">
              ${photo.signedUrl && photo.content_type?.startsWith("image/")
                ? `<img class="photo-thumb" src="${escapeHtml(photo.signedUrl)}" alt="${escapeHtml(photo.file_name)}">`
                : ""}
              <strong>${escapeHtml(photo.file_name)}</strong>
              <span>${photoMetaText(photo)}</span>
              ${photo.signedUrl ? `<a href="${escapeHtml(photo.signedUrl)}" target="_blank" rel="noreferrer">Open photo</a>` : ""}
            </article>
          `).join("") || `<p class="muted">No photos uploaded yet.</p>`}
        </div>
      </div>
      </details>

      <details class="work-detail-section relationship-detail comment" id="work-order-comments-target">
        <summary>Comments</summary>
      <form class="form-grid relationship-detail comment" id="comment-form">
        <label>Comment<textarea name="body" rows="3" required></textarea></label>
        <p class="error-text" id="comment-error"></p>
        <button class="primary-button" type="submit">Add Comment</button>
      </form>
      <div class="comment-list">
        ${comments.map((comment) => `
          <article class="relationship-detail comment">
            <strong>${escapeHtml(profilesByUserId[comment.author_id]?.full_name || "Team member")}</strong>
            <span>${comment.created_at ? new Date(comment.created_at).toLocaleString() : ""}</span>
            <p>${escapeHtml(comment.body)}</p>
          </article>
        `).join("") || `<p class="muted">No comments yet.</p>`}
      </div>
      </details>

      <details class="work-detail-section" id="work-order-history-target">
        <summary>History</summary>
      <div class="timeline">
        ${commentsError ? `<p class="error-text">${escapeHtml(commentsError)}</p>` : ""}
        ${activity.map(renderActivityItem).join("") || `<p class="muted">No activity yet.</p>`}
      </div>
      </details>

      ${canDeleteWorkOrders() ? renderWorkOrderDangerZone(workOrder) : ""}
    </div>
  `;
}

function renderWorkOrderDangerZone(workOrder) {
  const confirming = pendingDeleteWorkOrderId === workOrder.id;
  return `
    <section class="delete-zone">
      <div>
        <h3>Delete Work Order</h3>
        <p>This removes the work order and its linked comments, history, parts used, and photo records.</p>
      </div>
      ${confirming ? `
        <div class="delete-warning-panel">
          <strong>Permanent Delete Warning</strong>
          <p>You are about to permanently delete "${escapeHtml(workOrder.title)}". This cannot be undone.</p>
          <div class="button-row">
            <button class="secondary-button" data-cancel-delete-work-order type="button">Cancel</button>
            <button class="danger-action-button confirm-delete-button" data-confirm-delete-work-order="${workOrder.id}" type="button">Permanently Delete</button>
          </div>
        </div>
      ` : `
        <button class="danger-action-button large-delete-button" data-delete-work-order="${workOrder.id}" type="button">Delete Work Order</button>
      `}
    </section>
  `;
}

function recommendedWorkOrderStep(workOrder) {
  const orderedFields = [
    {
      isMissing: () => !String(workOrder.title || "").trim(),
      title: "Issue",
      target: "quick-update-issue-field",
    },
    {
      isMissing: () => !workOrder.asset_id,
      title: "Machine / Equipment",
      target: "quick-update-equipment-field",
    },
    {
      isMissing: () => !workOrder.assigned_to && !isVendorAssigned(workOrder),
      title: "Assign To",
      target: "quick-update-owner-field",
    },
    {
      isMissing: () => !workOrder.due_at,
      title: "Expected Back Up / Due Date",
      target: "quick-update-due-field",
    },
    {
      isMissing: () => !String(workOrder.resolution_summary || workOrder.completion_notes || "").trim(),
      title: "Resolution",
      target: "quick-update-resolution-field",
    },
    {
      isMissing: () => workOrder.status === "completed" && requiresSafetyDeviceCheck(workOrder) && !hasCompletedSafetyDeviceCheck(workOrder),
      title: "Safety Devices",
      target: "quick-update-safety-field",
      tone: "warning",
    },
  ];
  const nextField = orderedFields.find((field) => field.isMissing());
  if (nextField) {
    return {
      title: nextField.title,
      helper: "Want to update this next? Skip it if it does not apply.",
      action: "Go To Field",
      target: nextField.target,
      tone: nextField.tone || "",
    };
  }

  if (workOrder.status !== "completed") {
    return {
      title: "Complete Work",
      helper: "The quick update fields are filled in. When the work is done, complete the order.",
      action: "Go To Completion",
      target: "work-order-complete-target",
    };
  }

  return "";
}

function bindWorkspaceEvents() {
  document.querySelector("#company-select").addEventListener("change", async (event) => {
    activeCompanyId = event.target.value;
    activeLocationId = "";
    activeWorkOrderId = null;
    createWorkOrderMode = false;
    reportIssueMode = false;
    localStorage.setItem("maintainops.activeCompanyId", activeCompanyId);
    await render();
  });

  const switchLocation = async (nextLocationId) => {
      activeLocationId = nextLocationId;
      activeWorkOrderId = null;
      activeAssetId = null;
      activePartId = null;
      reportIssueMode = false;
      resetWorkOrderPage();
      resetPartsPage();
      resetAssetsPage();
      resetRequestsPage();
      invalidateExactWorkOrderSearchCache();
      persistActiveLocationId(activeLocationId);
      await reloadWorkOrderQueue();
      await reloadRequestQueue();
  };

  const locationSelect = document.querySelector("#location-select");
  if (locationSelect) {
    locationSelect.addEventListener("change", async () => {
      await switchLocation(locationSelect.value);
    });
  }

  document.querySelectorAll("[data-location-select]").forEach((select) => {
    select.addEventListener("change", async () => {
      await switchLocation(select.value);
    });
  });

  document.querySelectorAll("[data-location-sensitive-asset]").forEach((select) => {
    updateAssetLocationWarning(select);
    select.addEventListener("change", () => updateAssetLocationWarning(select));
  });

  document.querySelectorAll("[data-sign-out]").forEach((button) => {
    button.addEventListener("click", () => supabaseClient.auth.signOut());
  });
  document.querySelector("#new-company").addEventListener("click", renderCompanyCreate);
  document.querySelectorAll("[data-section]").forEach((button) => {
    button.addEventListener("click", async () => {
      if (!visibleNavItems().some(([id]) => id === button.dataset.section)) return;
      activeSection = button.dataset.section;
      activeWorkOrderId = null;
      activeAssetId = null;
      activePartId = null;
      showPartSourceManager = false;
      createWorkOrderMode = false;
      quickFixMode = false;
      reportIssueMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      if (activeSection !== "work") setWorkOrderSearchMode(false);
      resetWorkOrderPage();
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
      await reloadWorkOrderQueue();
      if (activeSection === "requests") await reloadRequestQueue();
    });
  });
  document.querySelectorAll("[data-command-action]").forEach((button) => {
    button.addEventListener("click", async () => {
      if (button.dataset.commandAction === "quick-fix") {
        activeWorkOrderId = null;
        activeAssetId = null;
        createWorkOrderMode = false;
        quickFixMode = true;
        reportIssueMode = false;
        quickFixAssetId = null;
        quickFixRequestId = null;
        activeSection = "mywork";
        setWorkOrderSearchMode(false);
        localStorage.setItem("maintainops.activeSection", activeSection);
        renderWorkspace();
        return;
      }
      if (button.dataset.commandAction === "create-work-order") {
        activeWorkOrderId = null;
        activeAssetId = null;
        createWorkOrderMode = true;
        quickFixMode = false;
        reportIssueMode = false;
        quickFixAssetId = null;
        quickFixRequestId = null;
        activeSection = "work";
        setWorkOrderSearchMode(false);
        localStorage.setItem("maintainops.activeSection", activeSection);
        renderWorkspace();
        return;
      }
      if (button.dataset.commandAction === "request") {
        activeWorkOrderId = null;
        activeAssetId = null;
        createWorkOrderMode = false;
        quickFixMode = false;
        reportIssueMode = false;
        quickFixAssetId = null;
        quickFixRequestId = null;
        activeSection = "requests";
        setWorkOrderSearchMode(false);
        localStorage.setItem("maintainops.activeSection", activeSection);
        resetRequestsPage();
        await reloadRequestQueue();
        return;
      }
      if (button.dataset.commandAction === "report-issue") {
        activeWorkOrderId = null;
        activeAssetId = null;
        activePartId = null;
        createWorkOrderMode = false;
        quickFixMode = false;
        reportIssueMode = true;
        renderWorkspace();
        return;
      }
      if (button.dataset.commandAction === "export-csv") {
        exportActiveSectionCsv();
      }
    });
  });

  const appIssueReportForm = document.querySelector("#app-issue-report-form");
  if (appIssueReportForm) appIssueReportForm.addEventListener("submit", createAppIssueReport);

  document.querySelectorAll("[data-cancel-app-issue-report]").forEach((button) => {
    button.addEventListener("click", () => {
      reportIssueMode = false;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-app-issue-status]").forEach((form) => {
    form.addEventListener("submit", updateAppIssueReportStatus);
  });

  document.querySelectorAll("[data-setup-action]").forEach((button) => {
    button.addEventListener("click", () => {
      if (button.dataset.setupAction !== "confirm-admin-delete-sql") return;
      adminDeleteSqlConfirmed = true;
      localStorage.setItem("maintainops.adminDeleteSqlConfirmed", "true");
      showNotice("Admin delete SQL marked as applied.");
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-message-thread]").forEach((button) => {
    button.addEventListener("click", async () => {
      activeMessageThreadId = button.dataset.messageThread;
      localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
      await markMessageThreadRead(activeMessageThreadId);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-message-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      messageThreadFilter = button.dataset.messageFilter;
      localStorage.setItem("maintainops.messageThreadFilter", messageThreadFilter);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-open-linked-work-order]").forEach((button) => {
    button.addEventListener("click", () => {
      activeWorkOrderId = button.dataset.openLinkedWorkOrder;
      activeAssetId = null;
      activePartId = null;
      quickFixMode = false;
      createWorkOrderMode = false;
      activeSection = "work";
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-jump-work-section]").forEach((button) => {
    button.addEventListener("click", () => {
      const target = document.querySelector(`#${button.dataset.jumpWorkSection}`);
      if (!target) return;
      const detailSection = target.closest("details");
      if (detailSection) detailSection.open = true;
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      const highlightTarget = target;
      highlightTarget.classList.add("jump-highlight", "field-jump-highlight");
      setTimeout(() => highlightTarget.classList.remove("jump-highlight"), 1400);
      setTimeout(() => highlightTarget.classList.remove("field-jump-highlight"), 1400);
    });
  });

  document.querySelectorAll("[data-start-work-message]").forEach((button) => {
    button.addEventListener("click", () => {
      messageComposerWorkOrderId = button.dataset.startWorkMessage;
      messageComposerOpen = true;
      activeMessageThreadId = "";
      activeSection = "messages";
      localStorage.setItem("maintainops.messageComposerWorkOrderId", messageComposerWorkOrderId);
      localStorage.setItem("maintainops.activeSection", activeSection);
      localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-open-work-message-thread]").forEach((button) => {
    button.addEventListener("click", async () => {
      activeMessageThreadId = button.dataset.openWorkMessageThread;
      messageComposerOpen = false;
      activeSection = "messages";
      localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
      localStorage.setItem("maintainops.activeSection", activeSection);
      await markMessageThreadRead(activeMessageThreadId);
      renderWorkspace();
    });
  });

  const clearMessageWorkLink = document.querySelector("[data-clear-message-work-link]");
  if (clearMessageWorkLink) {
    clearMessageWorkLink.addEventListener("click", () => {
      messageComposerWorkOrderId = "";
      localStorage.setItem("maintainops.messageComposerWorkOrderId", messageComposerWorkOrderId);
      renderWorkspace();
    });
  }

  const messageSearch = document.querySelector("#message-search");
  if (messageSearch) {
    messageSearch.addEventListener("input", () => {
      messageSearchQuery = messageSearch.value;
      localStorage.setItem("maintainops.messageSearchQuery", messageSearchQuery);
      renderWorkspace();
      const nextSearch = document.querySelector("#message-search");
      nextSearch.focus();
      nextSearch.setSelectionRange(messageSearchQuery.length, messageSearchQuery.length);
    });
  }

  const messageThreadForm = document.querySelector("#message-thread-form");
  if (messageThreadForm) {
    messageThreadForm.addEventListener("submit", createMessageThread);
    const typeSelect = messageThreadForm.querySelector("#message-thread-type");
    const directField = messageThreadForm.querySelector(".message-direct-field");
    const scopeNote = messageThreadForm.querySelector("#message-scope-note");
    const syncMessageComposer = () => {
      const isDirect = typeSelect.value === "direct";
      directField.classList.toggle("hidden-section", !isDirect);
      directField.querySelector("select").disabled = !isDirect;
      scopeNote.textContent = messageComposerScopeNote(typeSelect.value);
    };
    typeSelect.addEventListener("change", syncMessageComposer);
    syncMessageComposer();
  }

  const messageReplyForm = document.querySelector("#message-reply-form");
  if (messageReplyForm) {
    messageReplyForm.addEventListener("submit", sendThreadReply);
  }

  document.querySelectorAll("[data-quick-reply]").forEach((button) => {
    button.addEventListener("click", () => {
      const replyForm = document.querySelector("#message-reply-form");
      const field = replyForm?.querySelector("textarea[name='body']");
      if (!field) return;
      const prefix = field.value.trim();
      field.value = prefix ? `${prefix}\n${button.dataset.quickReply}` : button.dataset.quickReply;
      field.focus();
      autoGrowTextarea(field);
    });
  });

  const backToMyWork = document.querySelector("#back-to-my-work");
  if (backToMyWork) {
    backToMyWork.addEventListener("click", () => {
      activeWorkOrderId = null;
      activeAssetId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      renderWorkspace();
    });
  }

  const backToEquipment = document.querySelector("#back-to-equipment");
  if (backToEquipment) {
    backToEquipment.addEventListener("click", () => {
      activeAssetId = null;
      pendingDeleteAssetId = null;
      renderWorkspace();
    });
  }

  document.querySelectorAll(".workspace-search-input").forEach((searchInput) => {
    searchInput.addEventListener("input", async () => {
      const activeSearchId = searchInput.id;
      searchQuery = searchInput.value;
      invalidateExactWorkOrderSearchCache();
      if (!searchQuery.trim()) setWorkOrderSearchMode(false);
      if (searchQuery.trim()) {
        activeWorkOrderId = null;
        activeAssetId = null;
        activePartId = null;
        quickFixMode = false;
        createWorkOrderMode = false;
        quickFixAssetId = null;
        quickFixRequestId = null;
      }
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      resetWorkOrderPage();
      resetPartsPage();
      resetRequestsPage();
      await reloadWorkOrderQueue();
      await reloadRequestQueue();
      const nextSearchInput = document.querySelector(`#${activeSearchId}`);
      if (!nextSearchInput) return;
      nextSearchInput.focus();
      nextSearchInput.setSelectionRange(searchQuery.length, searchQuery.length);
    });
  });

  document.querySelectorAll("[data-view-work-search]").forEach((button) => {
    button.addEventListener("click", async () => {
      activeSection = "work";
      activeWorkOrderId = null;
      activeAssetId = null;
      activePartId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      setWorkOrderSearchMode(true);
      invalidateExactWorkOrderSearchCache();
      resetWorkOrderPage();
      localStorage.setItem("maintainops.activeSection", activeSection);
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-close-work-search]").forEach((button) => {
    button.addEventListener("click", async () => {
      setWorkOrderSearchMode(false);
      invalidateExactWorkOrderSearchCache();
      resetWorkOrderPage();
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll(".work-card").forEach((card) => {
    card.addEventListener("click", () => {
      activeWorkOrderId = card.dataset.id;
      activeAssetId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll(".asset-card").forEach((card) => {
    card.addEventListener("click", () => {
      activeAssetId = card.dataset.assetId;
      activeWorkOrderId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      activeSection = "assets";
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-open-asset]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      activeAssetId = button.dataset.openAsset;
      activeWorkOrderId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      if (activeSection !== "assets") activeSection = "work";
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-asset-id]").forEach((card) => {
    const openAsset = () => {
      activeAssetId = card.dataset.assetId;
      activeWorkOrderId = null;
      activePartId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      reportIssueMode = false;
      activeSection = "assets";
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    };

    card.addEventListener("click", openAsset);
    card.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      openAsset();
    });
  });

  document.querySelectorAll("[data-mini-work-order]").forEach((item) => {
    item.addEventListener("click", () => {
      activeWorkOrderId = item.dataset.miniWorkOrder;
      activeAssetId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      quickFixAssetId = null;
      quickFixRequestId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-search-work-order]").forEach((button) => {
    button.addEventListener("click", () => {
      activeWorkOrderId = button.dataset.searchWorkOrder;
      activeAssetId = null;
      activePartId = null;
      activeSection = "work";
      searchQuery = "";
      setWorkOrderSearchMode(false);
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-search-asset]").forEach((button) => {
    button.addEventListener("click", () => {
      activeAssetId = button.dataset.searchAsset;
      activeWorkOrderId = null;
      activePartId = null;
      activeSection = "assets";
      searchQuery = "";
      setWorkOrderSearchMode(false);
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-search-part]").forEach((button) => {
    button.addEventListener("click", () => {
      activePartId = button.dataset.searchPart;
      activeAssetId = null;
      activeWorkOrderId = null;
      activeSection = "parts";
      searchQuery = "";
      setWorkOrderSearchMode(false);
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-search-request]").forEach((button) => {
    button.addEventListener("click", () => {
      activeSection = "requests";
      searchQuery = "";
      setWorkOrderSearchMode(false);
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-search-section]").forEach((button) => {
    button.addEventListener("click", () => {
      activeSection = button.dataset.searchSection;
      searchQuery = "";
      setWorkOrderSearchMode(false);
      localStorage.setItem("maintainops.searchQuery", searchQuery);
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-quick-fix-asset]").forEach((button) => {
    button.addEventListener("click", () => {
      quickFixAssetId = button.dataset.quickFixAsset;
      quickFixRequestId = null;
      activeAssetId = null;
      activeWorkOrderId = null;
      createWorkOrderMode = false;
      quickFixMode = true;
      activeSection = "mywork";
      localStorage.setItem("maintainops.activeSection", activeSection);
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-quick-status]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      const originalText = button.textContent;
      button.disabled = true;
      button.textContent = "Saving...";
      try {
        const saved = await setWorkOrderStatus(button.dataset.id, button.dataset.quickStatus);
        if (!saved && button.isConnected) {
          button.disabled = false;
          button.textContent = originalText;
        }
      } catch (error) {
        showNotice(`Could not update status: ${error.message || error}`, "warning");
        if (button.isConnected) {
          button.disabled = false;
          button.textContent = originalText;
        }
      }
      if (button.isConnected) {
        button.disabled = false;
        button.textContent = originalText;
      }
    });
  });

  document.querySelectorAll("[data-assign-me]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      await assignWorkOrderToMe(button.dataset.assignMe);
    });
  });

  document.querySelectorAll("[data-delete-work-order]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      requestDeleteWorkOrder(button.dataset.deleteWorkOrder);
    });
  });

  document.querySelectorAll("[data-cancel-delete-work-order]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      pendingDeleteWorkOrderId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-delete-work-order]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      await deleteWorkOrder(button.dataset.confirmDeleteWorkOrder);
    });
  });

  document.querySelectorAll("[data-delete-asset]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      await requestDeleteAsset(button.dataset.deleteAsset);
    });
  });

  document.querySelectorAll("[data-cancel-delete-asset]").forEach((button) => {
    button.addEventListener("click", (event) => {
      event.stopPropagation();
      pendingDeleteAssetId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-delete-asset]").forEach((button) => {
    button.addEventListener("click", async (event) => {
      event.stopPropagation();
      await deleteAsset(button.dataset.confirmDeleteAsset);
    });
  });

  document.querySelectorAll("[data-card-assign]").forEach((form) => {
    form.addEventListener("submit", assignWorkOrderFromCard);
    form.addEventListener("click", (event) => event.stopPropagation());
    form.addEventListener("change", (event) => {
      event.stopPropagation();
      if (event.target?.name === "assigned_to") form.requestSubmit();
    });
  });

  document.querySelectorAll("[data-status-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      activeStatusFilter = button.dataset.statusFilter;
      resetWorkOrderPage();
      if (activeStatusFilter === "requests") {
        resetRequestsPage();
      }
      await reloadWorkOrderQueue();
      if (activeStatusFilter === "requests") await reloadRequestQueue();
    });
  });

  document.querySelectorAll("[data-my-work-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      myWorkFilter = button.dataset.myWorkFilter;
      localStorage.setItem("maintainops.myWorkFilter", myWorkFilter);
      resetWorkOrderPage();
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-work-order-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      workOrderFilter = button.dataset.workOrderFilter;
      workOrderAssigneeFilter = "";
      localStorage.setItem("maintainops.workOrderFilter", workOrderFilter);
      localStorage.removeItem("maintainops.workOrderAssigneeFilter");
      resetWorkOrderPage();
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-clear-assignee-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      workOrderAssigneeFilter = "";
      localStorage.removeItem("maintainops.workOrderAssigneeFilter");
      resetWorkOrderPage();
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-work-sort]").forEach((button) => {
    button.addEventListener("click", async () => {
      workSort = button.dataset.workSort;
      localStorage.setItem("maintainops.workSort", workSort);
      invalidateExactWorkOrderSearchCache();
      resetWorkOrderPage();
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-request-filter]").forEach((button) => {
    button.addEventListener("click", async () => {
      if (button.disabled) return;
      requestViewFilter = button.dataset.requestFilter || "active";
      localStorage.setItem("maintainops.requestViewFilter", requestViewFilter);
      resetRequestsPage();
      await reloadRequestQueue();
    });
  });

  document.querySelectorAll("[data-work-page]").forEach((button) => {
    button.addEventListener("click", async () => {
      workOrderPage += button.dataset.workPage === "next" ? 1 : -1;
      localStorage.setItem("maintainops.workOrderPage", String(workOrderPage));
      await reloadWorkOrderQueue();
    });
  });

  document.querySelectorAll("[data-parts-page]").forEach((button) => {
    button.addEventListener("click", () => {
      partsPage += button.dataset.partsPage === "next" ? 1 : -1;
      localStorage.setItem("maintainops.partsPage", String(partsPage));
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-assets-page]").forEach((button) => {
    button.addEventListener("click", () => {
      assetsPage += button.dataset.assetsPage === "next" ? 1 : -1;
      localStorage.setItem("maintainops.assetsPage", String(assetsPage));
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-list-page]").forEach((button) => {
    button.addEventListener("click", async () => {
      const delta = button.dataset.pageDirection === "next" ? 1 : -1;
      if (button.dataset.listPage === "requests") {
        requestsPage += delta;
        localStorage.setItem("maintainops.requestsPage", String(requestsPage));
        await reloadRequestQueue();
        return;
      }
      if (button.dataset.listPage === "schedules") {
        schedulesPage += delta;
        localStorage.setItem("maintainops.schedulesPage", String(schedulesPage));
      }
      if (button.dataset.listPage === "procedures") {
        proceduresPage += delta;
        localStorage.setItem("maintainops.proceduresPage", String(proceduresPage));
      }
      if (button.dataset.listPage === "members") {
        membersPage += delta;
        localStorage.setItem("maintainops.membersPage", String(membersPage));
      }
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-copy-downtime]").forEach((button) => {
    button.addEventListener("click", async () => {
      const workOrder = workOrders.find((item) => item.id === button.dataset.id);
      if (!workOrder) return;
      const text = button.dataset.copyDowntime === "subject"
        ? downtimeEmailSubject(workOrder)
        : downtimeEmailBody(workOrder);
      const copied = await copyTextToClipboard(text);
      button.textContent = copied ? "Copied" : "Copy failed";
      setTimeout(() => {
        button.textContent = button.dataset.copyDowntime === "subject" ? "Copy Subject" : "Copy Email Body";
      }, 1600);
    });
  });

  bindAutoGrowTextareas();

  const createForm = document.querySelector("#create-work-order-form");
  if (createForm) createForm.addEventListener("submit", createWorkOrder);

  const quickFixForm = document.querySelector("#quick-fix-form");
  if (quickFixForm) quickFixForm.addEventListener("submit", createQuickFix);

  document.querySelectorAll("[data-create-public-request-link]").forEach((button) => {
    button.addEventListener("click", () => createPublicRequestLink(button.dataset.createPublicRequestLink));
  });

  document.querySelectorAll("[data-disable-public-request-link]").forEach((button) => {
    button.addEventListener("click", () => disablePublicRequestLink(button.dataset.disablePublicRequestLink));
  });

  document.querySelectorAll("[data-enable-public-request-link]").forEach((button) => {
    button.addEventListener("click", () => setPublicRequestLinkActive(button.dataset.enablePublicRequestLink, true));
  });

  document.querySelectorAll("[data-regenerate-public-request-link]").forEach((button) => {
    button.addEventListener("click", () => regeneratePublicRequestLink(button.dataset.regeneratePublicRequestLink));
  });

  document.querySelectorAll("[data-copy-public-request-link]").forEach((button) => {
    button.addEventListener("click", async () => {
      const copied = await copyTextToClipboard(button.dataset.copyPublicRequestLink);
      button.textContent = copied ? "Copied" : "Copy failed";
      setTimeout(() => {
        button.textContent = "Copy QR Link";
      }, 1600);
    });
  });

  document.querySelectorAll("[data-convert-request]").forEach((button) => {
    button.addEventListener("click", () => convertRequestToWorkOrder(button.dataset.convertRequest));
  });

  document.querySelectorAll("[data-quick-fix-request]").forEach((button) => {
    button.addEventListener("click", () => openQuickFixForRequest(button.dataset.quickFixRequest));
  });

  document.querySelectorAll("[data-delete-request]").forEach((button) => {
    button.addEventListener("click", () => requestDeleteMaintenanceRequest(button.dataset.deleteRequest));
  });

  document.querySelectorAll("[data-cancel-delete-request]").forEach((button) => {
    button.addEventListener("click", () => {
      pendingDeleteRequestId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-delete-request]").forEach((button) => {
    button.addEventListener("click", () => deleteMaintenanceRequest(button.dataset.confirmDeleteRequest));
  });

  const editForm = document.querySelector("#edit-work-order-form");
  if (editForm) editForm.addEventListener("submit", updateWorkOrderDetails);

  const quickUpdateForm = document.querySelector("#quick-update-work-order-form");
  if (quickUpdateForm) quickUpdateForm.addEventListener("submit", updateWorkOrderQuickView);

  const completionForm = document.querySelector("#complete-work-order-form");
  if (completionForm) completionForm.addEventListener("submit", completeWorkOrder);

  document.querySelectorAll('input[name="safety_devices_checked"]').forEach((field) => {
    field.addEventListener("change", syncSafetyDeviceChecks);
  });

  const statusSelect = document.querySelector("#status-select");
  if (statusSelect) statusSelect.addEventListener("change", updateWorkOrderStatus);

  const commentForm = document.querySelector("#comment-form");
  if (commentForm) commentForm.addEventListener("submit", createComment);

  const photoForm = document.querySelector("#photo-form");
  if (photoForm) photoForm.addEventListener("submit", uploadPhoto);

  const assetForm = document.querySelector("#create-asset-form");
  if (assetForm) assetForm.addEventListener("submit", createAsset);

  const editAssetForm = document.querySelector("#edit-asset-form");
  if (editAssetForm) editAssetForm.addEventListener("submit", updateAsset);

  const pmForm = document.querySelector("#create-pm-form");
  if (pmForm) pmForm.addEventListener("submit", createPreventiveSchedule);

  document.querySelectorAll("[data-generate-pm]").forEach((button) => {
    button.addEventListener("click", () => generatePreventiveWorkOrder(button.dataset.generatePm));
  });

  document.querySelectorAll("[data-delete-schedule]").forEach((button) => {
    button.addEventListener("click", () => requestDeletePreventiveSchedule(button.dataset.deleteSchedule));
  });

  document.querySelectorAll("[data-cancel-delete-schedule]").forEach((button) => {
    button.addEventListener("click", () => {
      pendingDeleteScheduleId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-delete-schedule]").forEach((button) => {
    button.addEventListener("click", () => deletePreventiveSchedule(button.dataset.confirmDeleteSchedule));
  });

  document.querySelectorAll("[data-create-follow-up]").forEach((button) => {
    button.addEventListener("click", () => createFollowUpWorkOrder(button.dataset.createFollowUp));
  });

  const procedureForm = document.querySelector("#create-procedure-form");
  if (procedureForm) procedureForm.addEventListener("submit", createProcedureTemplate);

  const sampleProcedureButton = document.querySelector("#seed-sample-procedure");
  if (sampleProcedureButton) sampleProcedureButton.addEventListener("click", seedSampleProcedure);

  document.querySelectorAll("[data-add-step]").forEach((form) => {
    form.addEventListener("submit", createProcedureStep);
  });

  document.querySelectorAll("[data-delete-procedure]").forEach((button) => {
    button.addEventListener("click", async () => requestDeleteProcedureTemplate(button.dataset.deleteProcedure));
  });

  document.querySelectorAll("[data-cancel-delete-procedure]").forEach((button) => {
    button.addEventListener("click", () => {
      pendingDeleteProcedureId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-delete-procedure]").forEach((button) => {
    button.addEventListener("click", async () => deleteProcedureTemplate(button.dataset.confirmDeleteProcedure));
  });

  document.querySelectorAll("[data-step-result]").forEach((field) => {
    field.addEventListener("change", saveStepResult);
  });

  const memberForm = document.querySelector("#add-member-form");
  if (memberForm) memberForm.addEventListener("submit", addCompanyMember);

  document.querySelectorAll("[data-member-role]").forEach((form) => {
    form.addEventListener("submit", updateCompanyMemberRole);
  });

  document.querySelectorAll("[data-view-member-work]").forEach((button) => {
    button.addEventListener("click", () => {
      workOrderAssigneeFilter = button.dataset.viewMemberWork;
      activeSection = "work";
      activeStatusFilter = "active";
      activeWorkOrderId = null;
      activeAssetId = null;
      createWorkOrderMode = false;
      quickFixMode = false;
      localStorage.setItem("maintainops.activeSection", activeSection);
      localStorage.setItem("maintainops.workOrderAssigneeFilter", workOrderAssigneeFilter);
      resetWorkOrderPage();
      renderWorkspace();
    });
  });

  const profileForm = document.querySelector("#profile-form");
  if (profileForm) profileForm.addEventListener("submit", updateMyProfile);

  const inviteForm = document.querySelector("#team-invite-form");
  if (inviteForm) inviteForm.addEventListener("submit", createTeamInvite);

  document.querySelectorAll("[data-cancel-invite]").forEach((button) => {
    button.addEventListener("click", () => {
      teamInviteCancelError = "";
      pendingCancelInviteId = button.dataset.cancelInvite;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-cancel-invite-cancel]").forEach((button) => {
    button.addEventListener("click", () => {
      teamInviteCancelError = "";
      pendingCancelInviteId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-confirm-cancel-invite]").forEach((button) => {
    button.addEventListener("click", () => cancelTeamInvite(button.dataset.confirmCancelInvite));
  });

  const partForm = document.querySelector("#create-part-form");
  if (partForm) partForm.addEventListener("submit", createPart);

  document.querySelectorAll("[data-part-inventory-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      partInventoryFilter = button.dataset.partInventoryFilter;
      localStorage.setItem("maintainops.partInventoryFilter", partInventoryFilter);
      resetPartsPage();
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-asset-status-filter]").forEach((button) => {
    button.addEventListener("click", () => {
      assetStatusFilter = assetStatusFilter === button.dataset.assetStatusFilter ? "all" : button.dataset.assetStatusFilter;
      localStorage.setItem("maintainops.assetStatusFilter", assetStatusFilter);
      resetAssetsPage();
      renderWorkspace();
    });
  });

  const partSearchForm = document.querySelector("#part-search-form");
  if (partSearchForm) {
    const partSearchInput = partSearchForm.querySelector("input[name='part_search']");
    if (partSearchInput) {
      partSearchInput.addEventListener("input", () => {
        partSearchQuery = partSearchInput.value || "";
        localStorage.setItem("maintainops.partSearchQuery", partSearchQuery);
        resetPartsPage();
        renderWorkspace();
        const nextPartSearchInput = document.querySelector("#part-search");
        if (!nextPartSearchInput) return;
        nextPartSearchInput.focus();
        const cursorPosition = nextPartSearchInput.value.length;
        nextPartSearchInput.setSelectionRange(cursorPosition, cursorPosition);
      });
    }
    partSearchForm.addEventListener("submit", (event) => {
      event.preventDefault();
      partSearchQuery = new FormData(partSearchForm).get("part_search") || "";
      localStorage.setItem("maintainops.partSearchQuery", partSearchQuery);
      resetPartsPage();
      renderWorkspace();
      document.querySelector("#parts-list")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  document.querySelectorAll("[data-restock-part]").forEach((form) => {
    form.addEventListener("submit", restockPart);
  });

  document.querySelectorAll("[data-use-part]").forEach((form) => {
    form.addEventListener("submit", usePartFromInventory);
  });

  document.querySelectorAll("[data-edit-part]").forEach((form) => {
    form.addEventListener("submit", updatePart);
  });

  document.querySelectorAll("[data-delete-part]").forEach((button) => {
    button.addEventListener("click", () => requestDeletePart(button.dataset.deletePart));
  });

  document.querySelectorAll("[data-cancel-delete-part]").forEach((button) => {
    button.addEventListener("click", () => {
      pendingDeletePartId = null;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-open-part]").forEach((button) => {
    button.addEventListener("click", () => {
      activePartId = button.dataset.openPart;
      renderWorkspace();
    });
    button.addEventListener("keydown", (event) => {
      if (event.key !== "Enter" && event.key !== " ") return;
      event.preventDefault();
      activePartId = button.dataset.openPart;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-close-part-detail]").forEach((button) => {
    button.addEventListener("click", () => {
      activePartId = null;
      showPartSourceManager = false;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-toggle-part-sources]").forEach((button) => {
    button.addEventListener("click", () => {
      showPartSourceManager = !showPartSourceManager;
      renderWorkspace();
    });
  });

  document.querySelectorAll("[data-rename-part-source]").forEach((form) => {
    form.addEventListener("submit", renamePartSource);
  });

  document.querySelectorAll("[data-part-document]").forEach((form) => {
    form.addEventListener("submit", uploadPartDocument);
  });

  const partsUsedForm = document.querySelector("#parts-used-form");
  if (partsUsedForm) partsUsedForm.addEventListener("submit", recordPartUsed);

  const settingsForm = document.querySelector("#company-settings-form");
  if (settingsForm) settingsForm.addEventListener("submit", updateCompanySettings);

  const logoForm = document.querySelector("#company-logo-form");
  if (logoForm) logoForm.addEventListener("submit", uploadCompanyLogo);

  const locationForm = document.querySelector("#location-form");
  if (locationForm) locationForm.addEventListener("submit", createLocation);

  const publicAppUrlForm = document.querySelector("#public-app-url-form");
  if (publicAppUrlForm) publicAppUrlForm.addEventListener("submit", savePublicAppUrl);
}

async function createAsset(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#asset-create-error");
  if (errorElement) errorElement.textContent = "";
  const submitButton = formElement.querySelector("button[type='submit']");
  const originalButtonText = submitButton?.textContent || "Add Equipment";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }
  try {
    const form = new FormData(formElement);
    const payload = {
      company_id: activeCompanyId,
      location_id: form.get("location_id") || activeLocationDatabaseId(),
      name: requiredText(form.get("name"), "Equipment name"),
      asset_code: String(form.get("asset_code") || "").trim() || null,
      location: String(form.get("location") || "").trim() || null,
      parent_asset_id: form.get("parent_asset_id") || null,
      asset_type: form.get("asset_type") || "machine",
      safety_devices_required: form.get("safety_devices_required") === "on",
      status: "running",
    };
    const { error } = await withOperationTimeout(
      supabaseClient.from("assets").insert(payload),
      "Equipment save timed out. Check your connection and try again.",
      15000
    );
    if (error && isMissingColumnError(error, "location_id")) {
      locationsReady = false;
      throw new Error(databaseSetupRequiredMessage("saving equipment locations"));
    }
    if (error && isAssetHierarchySchemaError(error)) {
      throw new Error(equipmentSchemaMessage(error));
    }
    if (error) throw error;
    showNotice("Equipment added.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message;
    else alert(error.message);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = originalButtonText;
    }
  }
}

async function updateAsset(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#asset-edit-error");
  if (errorElement) errorElement.textContent = "";
  const submitButton = formElement.querySelector("button[type='submit']");
  const originalButtonText = submitButton?.textContent || "Save Equipment";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }
  try {
    const form = new FormData(formElement);
    const payload = {
      name: requiredText(form.get("name"), "Equipment name"),
      asset_code: String(form.get("asset_code") || "").trim() || null,
      location_id: form.get("location_id") || activeLocationDatabaseId(),
      location: String(form.get("location") || "").trim() || null,
      parent_asset_id: form.get("parent_asset_id") || null,
      asset_type: form.get("asset_type") || "machine",
      safety_devices_required: form.get("safety_devices_required") === "on",
      status: form.get("status"),
    };
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("assets")
        .update(payload)
        .eq("id", activeAssetId)
        .eq("company_id", activeCompanyId),
      "Equipment save timed out. Check your connection and try again.",
      15000
    );
    if (error && isMissingColumnError(error, "location_id")) {
      locationsReady = false;
      throw new Error(databaseSetupRequiredMessage("saving equipment locations"));
    }
    if (error && isAssetHierarchySchemaError(error)) {
      throw new Error(equipmentSchemaMessage(error));
    }
    if (error) throw error;
    showNotice("Equipment saved.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message;
    else alert(error.message);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = originalButtonText;
    }
  }
}

async function updateAssetStatus(assetId, status) {
  const { error } = await withOperationTimeout(
    supabaseClient
      .from("assets")
      .update({ status })
      .eq("id", assetId)
      .eq("company_id", activeCompanyId),
    "Equipment status save timed out. Check your connection and try again.",
    12000
  );
  return error || null;
}

function assetDeleteBlockers(assetId) {
  return {
    workOrders: workOrders.filter((workOrder) => workOrder.asset_id === assetId).length,
    children: childAssetsFor(assetId).length,
    schedules: preventiveSchedules.filter((schedule) => schedule.asset_id === assetId).length,
    requests: maintenanceRequests.filter((request) => request.asset_id === assetId).length,
  };
}

function assetHasDeleteBlockers(assetId) {
  const blockers = assetDeleteBlockers(assetId);
  return Object.values(blockers).some(Boolean);
}

// LFES-RELIABILITY: Delete guards query live linked counts because paged client lists can hide traceability blockers.
async function loadAssetDeleteBlockers(assetId) {
  const [workOrdersCount, schedulesCount, requestsCount] = await Promise.all([
    countAssetLinkedRows("work_orders", assetId),
    countAssetLinkedRows("preventive_schedules", assetId),
    countAssetLinkedRows("maintenance_requests", assetId),
  ]);
  return {
    workOrders: workOrdersCount,
    children: childAssetsFor(assetId).length,
    schedules: schedulesCount,
    requests: requestsCount,
  };
}

async function countAssetLinkedRows(tableName, assetId) {
  const { count, error } = await withOperationTimeout(
    supabaseClient
      .from(tableName)
      .select("id", { count: "exact", head: true })
      .eq("company_id", activeCompanyId)
      .eq("asset_id", assetId),
    `Equipment delete check timed out while checking ${tableName}.`,
    15000
  );
  if (error) throw new Error(`Could not verify linked ${tableName.replaceAll("_", " ")} before deleting equipment: ${error.message}`);
  return count || 0;
}

function assetDeleteBlockerMessage(blockers) {
  const parts = [
    blockers.workOrders ? `${blockers.workOrders} work order${blockers.workOrders === 1 ? "" : "s"}` : "",
    blockers.children ? `${blockers.children} linked equipment item${blockers.children === 1 ? "" : "s"}` : "",
    blockers.schedules ? `${blockers.schedules} PM schedule${blockers.schedules === 1 ? "" : "s"}` : "",
    blockers.requests ? `${blockers.requests} request${blockers.requests === 1 ? "" : "s"}` : "",
  ].filter(Boolean);
  return parts.length
    ? `This equipment is kept for traceability because it has ${parts.join(", ")}.`
    : "";
}

async function requestDeleteAsset(id) {
  if (!canDeleteEquipment()) {
    alert("Only company admins and managers can delete equipment.");
    return;
  }
  const errorElement = document.querySelector("#asset-delete-error");
  if (errorElement) errorElement.textContent = "";
  try {
    const blockers = await loadAssetDeleteBlockers(id);
    const message = assetDeleteBlockerMessage(blockers);
    if (message) {
      if (errorElement) errorElement.textContent = message;
      return;
    }
    pendingDeleteAssetId = id;
    renderWorkspace();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not verify equipment links before delete.";
    else showNotice(error.message || "Could not verify equipment links before delete.", "warning");
  }
}

async function deleteAsset(id) {
  if (!canDeleteEquipment()) {
    alert("Only company admins and managers can delete equipment.");
    return;
  }
  const errorElement = document.querySelector("#asset-delete-error");
  if (errorElement) errorElement.textContent = "";
  const confirmButton = document.querySelector(`[data-confirm-delete-asset="${CSS.escape(id)}"]`);
  if (confirmButton) {
    confirmButton.disabled = true;
    confirmButton.textContent = "Deleting...";
  }

  try {
    const blockers = await loadAssetDeleteBlockers(id);
    const blockerMessage = assetDeleteBlockerMessage(blockers);
    if (blockerMessage) throw new Error(blockerMessage);

    const { error } = await withOperationTimeout(
      supabaseClient
        .from("assets")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId),
      "Equipment delete timed out. Check your connection and try again.",
      15000
    );
    if (error) {
      throw new Error(error.message.includes("violates foreign key constraint")
        ? "This equipment is linked to records and cannot be deleted."
        : error.message);
    }
    activeAssetId = null;
    pendingDeleteAssetId = null;
    activeSection = "assets";
    showNotice("Equipment deleted.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not delete equipment.";
    if (confirmButton) {
      confirmButton.disabled = false;
      confirmButton.textContent = "Permanently Delete";
    }
  }
}

async function createQuickFixAsset(name, status = "running") {
  const payload = {
    company_id: activeCompanyId,
    location_id: activeLocationDatabaseId(),
    name,
    asset_type: "machine",
    safety_devices_required: true,
    status,
  };
  let response = await withOperationTimeout(
    supabaseClient
      .from("assets")
      .insert(payload)
      .select()
      .single(),
    "Equipment save timed out. Check your connection and try again.",
    15000
  );
  if (response.error && isMissingColumnError(response.error, "location_id")) {
    locationsReady = false;
    return withSetupError(response, databaseSetupRequiredMessage("adding equipment in this location"));
  }
  if (response.error && isAssetHierarchySchemaError(response.error)) {
    return withSetupError(response, equipmentSchemaMessage(response.error).replace("saving", "adding"));
  }
  return response;
}

async function createPreventiveSchedule(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorElement = document.querySelector("#pm-error");
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }

  try {
    const form = new FormData(formElement);
    if (!confirmAssetLocationRouting(form.get("asset_id") || null, "this PM schedule", errorElement)) return;
    const { error } = await withOperationTimeout(
      insertWithOptionalProcedure("preventive_schedules", {
        company_id: activeCompanyId,
        location_id: locationIdForAsset(form.get("asset_id")),
        asset_id: form.get("asset_id"),
        title: requiredText(form.get("title"), "PM title"),
        frequency: form.get("frequency"),
        next_due_at: form.get("next_due_at"),
        ...procedureColumn(form.get("procedure_template_id")),
        active: true,
        created_by: session.user.id,
      }),
      "PM schedule save timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    showNotice("PM schedule added.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not add PM schedule.";
    else alert(error.message || error);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Schedule";
    }
  }
}

function requestDeletePreventiveSchedule(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete PM schedules.");
    return;
  }
  if (!preventiveSchedules.some((schedule) => schedule.id === id)) return;
  pendingDeleteScheduleId = id;
  renderWorkspace();
}

async function deletePreventiveSchedule(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete PM schedules.");
    return;
  }

  const schedule = preventiveSchedules.find((item) => item.id === id);
  if (!schedule) return;
  const button = document.querySelector(`[data-confirm-delete-schedule="${CSS.escape(id)}"]`);
  if (button) {
    button.disabled = true;
    button.textContent = "Deleting...";
  }

  try {
    const { data, error } = await withOperationTimeout(
      supabaseClient
        .from("preventive_schedules")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .select("id"),
      "PM schedule delete timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    if (!data?.length) {
      throw new Error("PM schedule was not deleted. Run supabase/step-next-cleanup-delete-paths.sql, then try again.");
    }

    const verification = await withOperationTimeout(
      supabaseClient
        .from("preventive_schedules")
        .select("id")
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .maybeSingle(),
      "PM schedule delete verification timed out. Refresh and check the PM list.",
      15000
    );
    if (verification.error) throw new Error(`PM schedule delete verification failed: ${verification.error.message}`);
    if (verification.data) throw new Error("PM schedule delete did not persist in Supabase.");

    pendingDeleteScheduleId = null;
    showNotice("PM schedule deleted.");
    await render();
  } catch (error) {
    showNotice(error.message || "Could not delete PM schedule.", "warning");
    if (button) {
      button.disabled = false;
      button.textContent = "Permanently Delete";
    }
  }
}

async function createProcedureTemplate(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorElement = document.querySelector("#procedure-error");
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }

  try {
    const form = new FormData(formElement);
    const { error } = await withOperationTimeout(
      supabaseClient.from("procedure_templates").insert({
        company_id: activeCompanyId,
        name: requiredText(form.get("name"), "Procedure name"),
        description: String(form.get("description") || "").trim() || null,
        created_by: session.user.id,
      }),
      "Procedure save timed out."
    );
    if (error) throw error;
    showNotice("Procedure added.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not add procedure.";
    else alert(error.message || error);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Procedure";
    }
  }
}

async function seedSampleProcedure() {
  const button = document.querySelector("#seed-sample-procedure");
  const existing = procedureTemplates.find((template) => template.name.toLowerCase() === "basic equipment inspection");
  if (existing) {
    showNotice("Sample inspection procedure already exists.", "warning");
    return;
  }
  if (button) {
    button.disabled = true;
    button.textContent = "Adding sample...";
  }

  try {
    const { data: template, error: templateError } = await withOperationTimeout(
      supabaseClient
        .from("procedure_templates")
        .insert({
          company_id: activeCompanyId,
          name: "Basic Equipment Inspection",
          description: "A simple starter checklist for visual checks, readings, and final pass/fail.",
          created_by: session.user.id,
        })
        .select()
        .single(),
      "Sample procedure save timed out."
    );

    if (templateError) throw templateError;

    const steps = [
      { position: 1, prompt: "Confirm lockout or safe operating condition", response_type: "checkbox", required: true },
      { position: 2, prompt: "Inspect for leaks, loose guards, or visible damage", response_type: "pass_fail", required: true },
      { position: 3, prompt: "Record operating reading", response_type: "number", required: false },
      { position: 4, prompt: "Add technician notes", response_type: "text", required: false },
    ].map((step) => ({
      ...step,
      company_id: activeCompanyId,
      procedure_template_id: template.id,
    }));

    const { error: stepsError } = await withOperationTimeout(
      supabaseClient.from("procedure_steps").insert(steps),
      "Sample procedure steps save timed out."
    );
    if (stepsError) throw stepsError;
    showNotice("Sample procedure added.");
    await render();
  } catch (error) {
    showNotice(`Could not add sample procedure: ${error.message || error}`, "warning");
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = "Add sample inspection procedure";
    }
  }
}

async function createProcedureStep(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorElement = document.querySelector(`[data-step-error="${formElement.dataset.addStep}"]`);
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }

  try {
    const form = new FormData(formElement);
    const template = procedureTemplates.find((item) => item.id === formElement.dataset.addStep);
    const nextPosition = (template?.procedure_steps?.length || 0) + 1;
    const { error } = await withOperationTimeout(
      supabaseClient.from("procedure_steps").insert({
        company_id: activeCompanyId,
        procedure_template_id: formElement.dataset.addStep,
        position: nextPosition,
        prompt: requiredText(form.get("prompt"), "Procedure step"),
        response_type: form.get("response_type"),
        required: form.get("required") === "true",
      }),
      "Procedure step save timed out."
    );
    if (error) throw error;
    showNotice("Procedure step added.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not add procedure step.";
    else alert(error.message || error);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Step";
    }
  }
}

async function loadProcedureDeleteBlockers(templateId) {
  const [workOrdersCount, schedulesCount] = await Promise.all([
    countProcedureLinkedRows("work_orders", templateId),
    countProcedureLinkedRows("preventive_schedules", templateId),
  ]);
  return {
    workOrders: workOrdersCount,
    schedules: schedulesCount,
  };
}

async function countProcedureLinkedRows(tableName, templateId) {
  const { count, error } = await withOperationTimeout(
    supabaseClient
      .from(tableName)
      .select("id", { count: "exact", head: true })
      .eq("company_id", activeCompanyId)
      .eq("procedure_template_id", templateId),
    `Procedure delete check timed out while checking ${tableName}.`,
    15000
  );
  if (error) throw new Error(`Could not verify linked ${tableName.replaceAll("_", " ")} before deleting procedure: ${error.message}`);
  return count || 0;
}

function procedureDeleteBlockerMessage(blockers) {
  const parts = [
    blockers.workOrders ? `${blockers.workOrders} work order${blockers.workOrders === 1 ? "" : "s"}` : "",
    blockers.schedules ? `${blockers.schedules} PM schedule${blockers.schedules === 1 ? "" : "s"}` : "",
  ].filter(Boolean);
  return parts.length
    ? `This procedure is kept for traceability because it is linked to ${parts.join(", ")}.`
    : "";
}

async function requestDeleteProcedureTemplate(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete procedures.");
    return;
  }
  if (!procedureTemplates.some((template) => template.id === id)) return;
  const errorElement = document.querySelector(`[data-procedure-delete-error="${CSS.escape(id)}"]`);
  if (errorElement) errorElement.textContent = "";
  try {
    const blockers = await loadProcedureDeleteBlockers(id);
    const message = procedureDeleteBlockerMessage(blockers);
    if (message) {
      if (errorElement) errorElement.textContent = message;
      return;
    }
    pendingDeleteProcedureId = id;
    renderWorkspace();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not verify procedure links before delete.";
    else showNotice(error.message || "Could not verify procedure links before delete.", "warning");
  }
}

async function deleteProcedureTemplate(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete procedures.");
    return;
  }

  const template = procedureTemplates.find((item) => item.id === id);
  if (!template) return;
  const button = document.querySelector(`[data-confirm-delete-procedure="${CSS.escape(id)}"]`);
  const errorElement = document.querySelector(`[data-procedure-delete-error="${CSS.escape(id)}"]`);
  if (errorElement) errorElement.textContent = "";
  if (button) {
    button.disabled = true;
    button.textContent = "Deleting...";
  }

  try {
    const blockers = await loadProcedureDeleteBlockers(id);
    const blockerMessage = procedureDeleteBlockerMessage(blockers);
    if (blockerMessage) throw new Error(blockerMessage);

    const { data, error } = await withOperationTimeout(
      supabaseClient
        .from("procedure_templates")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .select("id"),
      "Procedure delete timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    if (!data?.length) {
      throw new Error("Procedure was not deleted. Run supabase/step-next-cleanup-delete-paths.sql, then try again.");
    }

    const verification = await withOperationTimeout(
      supabaseClient
        .from("procedure_templates")
        .select("id")
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .maybeSingle(),
      "Procedure delete verification timed out. Refresh and check the procedure list.",
      15000
    );
    if (verification.error) throw new Error(`Procedure delete verification failed: ${verification.error.message}`);
    if (verification.data) throw new Error("Procedure delete did not persist in Supabase.");

    pendingDeleteProcedureId = null;
    showNotice("Procedure deleted.");
    await render();
  } catch (error) {
    const message = error.message || "Could not delete procedure.";
    showNotice(message, "warning");
    if (errorElement) errorElement.textContent = message;
    if (button) {
      button.disabled = false;
      button.textContent = "Permanently Delete";
    }
  }
}

async function addCompanyMember(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  const submitButton = formElement.querySelector("button[type='submit']");
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }
  try {
    const { error } = await withOperationTimeout(
      supabaseClient.from("company_members").insert({
        company_id: activeCompanyId,
        user_id: form.get("user_id"),
        role: form.get("role"),
      }),
      "Team member save timed out."
    );
    if (error) throw error;
    await render();
  } catch (error) {
    alert(error.message || error);
  } finally {
    if (submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Member";
    }
  }
}

async function updateCompanyMemberRole(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const form = new FormData(formElement);
  const submitButton = formElement.querySelector("button[type='submit']");
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient.rpc("update_company_member_role", {
        target_company_id: activeCompanyId,
        target_user_id: formElement.dataset.memberRole,
        new_role: form.get("role"),
      }),
      "Role save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      throw new Error(error.message.includes("update_company_member_role")
        ? "Run supabase/step-next-team-roles.sql before editing roles."
        : error.message);
    }

    await loadMembers();
    showNotice("Role saved.");
    render();
  } catch (error) {
    showNotice(`Could not save role: ${error.message || error}`, "warning");
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Role";
    }
  }
}

async function updateMyProfile(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#profile-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  const fullName = String(form.get("full_name") || "").trim();
  const mobileTechField = formElement.querySelector('input[name="mobile_tech"]');
  const mobileTech = mobileTechField ? mobileTechField.checked : Boolean(profilesByUserId[session.user.id]?.mobile_tech);
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("profiles")
        .upsert({
          company_id: activeCompanyId,
          user_id: session.user.id,
          full_name: fullName,
          mobile_tech: mobileTech,
        }, { onConflict: "company_id,user_id" }),
      "Profile save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      if (isMissingColumnError(error, "mobile_tech")) {
        throw new Error("Run supabase/step-next-mobile-tech-setting.sql before saving Mobile tech settings.");
      }
      throw error;
    }

    showNotice("Profile saved.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not save profile.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Profile";
    }
  }
}

// LFES-TRACEABILITY: Invite default location is onboarding state; acceptance must preserve the intended starting location.
async function createTeamInvite(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#team-invite-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (errorElement) errorElement.textContent = "";
  if (!teamInvitesReady) {
    if (errorElement) errorElement.textContent = "Run supabase/step-next-invite-default-location.sql before inviting by email.";
    return;
  }
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Inviting...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient.rpc("create_company_invite", {
        target_company_id: activeCompanyId,
        invite_email: String(form.get("email") || "").trim(),
        invite_role: form.get("role"),
        invite_default_location_id: form.get("default_location_id") || null,
      }),
      "Invite save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      if (error.message.includes("create_company_invite") || isColumnSchemaError(error, ["company_invites"])) {
        teamInvitesReady = false;
        throw new Error("Run supabase/step-next-invite-default-location.sql before inviting by email.");
      }
      throw error;
    }

    showNotice("Invite created.");
    teamInviteCancelError = "";
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not create invite.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Create Invite";
    }
  }
}

async function cancelTeamInvite(inviteId) {
  if (!inviteId || !activeCompanyId) return;
  try {
    const { error } = await withOperationTimeout(
      supabaseClient.rpc("cancel_company_invite", {
        target_company_id: activeCompanyId,
        target_invite_id: inviteId,
      }),
      "Invite cancel timed out. Check your connection and try again.",
      15000
    );
    if (error) {
      if (error.message.includes("cancel_company_invite")) {
        throw new Error("Run supabase/step-next-cancel-team-invites.sql before canceling invites.");
      }
      throw error;
    }
    pendingCancelInviteId = null;
    teamInviteCancelError = "";
    showNotice("Invite canceled.");
    await loadTeamInvites();
    renderWorkspace();
  } catch (error) {
    pendingCancelInviteId = null;
    teamInviteCancelError = error.message || "Could not cancel invite.";
    renderWorkspace();
  }
}

async function createMessageThread(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#message-thread-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (errorElement) errorElement.textContent = "";
  if (!messagesReady) {
    if (errorElement) errorElement.textContent = "Run supabase/step-next-message-center.sql before creating threads.";
    return;
  }

  const threadType = form.get("thread_type");
  const directUserId = form.get("direct_user_id");
  const memberIds = messageThreadMembersForType(threadType, directUserId);
  const title = String(form.get("title") || "").trim();
  const body = String(form.get("body") || "").trim();
  if (threadType === "direct" && !directUserId) {
    if (errorElement) errorElement.textContent = "Choose a teammate for a direct message.";
    return;
  }
  if (!title || !body) {
    if (errorElement) errorElement.textContent = "Add a subject and message before starting the thread.";
    return;
  }
  if (!memberIds.includes(session.user.id)) memberIds.push(session.user.id);

  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Starting...";
  }

  let threadStarted = false;
  try {
    const workOrderId = form.get("work_order_id") || null;
    const threadPayload = {
      company_id: activeCompanyId,
      location_id: threadType === "location" ? activeLocationDatabaseId() : null,
      thread_type: threadType,
      title,
      created_by: session.user.id,
    };
    if (workOrderId && messageWorkOrderLinksReady) {
      threadPayload.work_order_id = workOrderId;
    }

    const { data: thread, error: threadError } = await withOperationTimeout(
      supabaseClient
        .from("message_threads")
        .insert(threadPayload)
        .select("*")
        .single(),
      "Message thread save timed out. Check your connection and try again.",
      15000
    );

    if (threadError) {
      if (isMissingColumnError(threadError, "work_order_id")) {
        messageWorkOrderLinksReady = false;
      }
      throw threadError;
    }

    const memberRows = [...new Set(memberIds)].map((userId) => ({
      company_id: activeCompanyId,
      thread_id: thread.id,
      user_id: userId,
    }));
    const { error: memberError } = await withOperationTimeout(
      supabaseClient.from("message_thread_members").insert(memberRows),
      "Message member save timed out. Check your connection and try again.",
      15000
    );
    if (memberError) throw memberError;

    const { error: messageError } = await insertThreadMessage(thread.id, body);
    if (messageError) throw messageError;

    activeMessageThreadId = thread.id;
    messageComposerWorkOrderId = "";
    messageComposerOpen = false;
    localStorage.setItem("maintainops.activeMessageThreadId", activeMessageThreadId);
    localStorage.setItem("maintainops.messageComposerWorkOrderId", messageComposerWorkOrderId);
    await markMessageThreadRead(thread.id);
    showNotice("Thread started.");
    threadStarted = true;
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = friendlyMessageCenterError(error);
  } finally {
    if (!threadStarted && submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Start Thread";
    }
  }
}

async function sendThreadReply(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#message-reply-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const body = String(new FormData(formElement).get("body") || "").trim();
  if (!body) return;
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Sending...";
  }

  let replySent = false;
  try {
    const { error } = await insertThreadMessage(formElement.dataset.threadId, body);
    if (error) throw error;

    showNotice("Message sent.");
    await markMessageThreadRead(formElement.dataset.threadId);
    replySent = true;
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = friendlyMessageCenterError(error);
  } finally {
    if (!replySent && submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Send Reply";
    }
  }
}

async function markMessageThreadRead(threadId) {
  if (!messagesReady || !threadId) return;
  const readAt = new Date().toISOString();
  messageReadsByThreadId[threadId] = {
    company_id: activeCompanyId,
    thread_id: threadId,
    user_id: session.user.id,
    last_read_at: readAt,
  };
  const { error } = await withOperationTimeout(
    supabaseClient
      .from("message_reads")
      .upsert(messageReadsByThreadId[threadId], { onConflict: "thread_id,user_id" }),
    "Message read marker timed out.",
    8000
  ).catch((error) => ({ error }));
  if (error) console.warn("Could not mark message thread read", error);
}

async function insertThreadMessage(threadId, body) {
  const message = await withOperationTimeout(
    supabaseClient
      .from("messages")
      .insert({
        company_id: activeCompanyId,
        thread_id: threadId,
        sender_id: session.user.id,
        body,
      }),
    "Message save timed out. Check your connection and try again.",
    15000
  );

  if (message.error) return { error: message.error };

  const thread = await withOperationTimeout(
    supabaseClient
      .from("message_threads")
      .update({ updated_at: new Date().toISOString() })
      .eq("id", threadId)
      .eq("company_id", activeCompanyId),
    "Message thread timestamp save timed out.",
    8000
  ).catch((error) => ({ error }));

  return { error: thread.error };
}

function friendlyMessageCenterError(error) {
  if (isMissingColumnError(error, "work_order_id")) {
    return "Run supabase/step-next-message-work-order-links.sql before linking message threads to work orders.";
  }
  if (isColumnSchemaError(error, ["message_threads", "message_thread_members", "messages"]) || error.message.includes("message_threads")) {
    messagesReady = false;
    return "Run supabase/step-next-message-center.sql before using Messages.";
  }
  return error.message;
}

async function updateCompanySettings(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }
  try {
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("companies")
        .update({ name: requiredText(form.get("name"), "Company name") })
        .eq("id", activeCompanyId),
      "Company save timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    showNotice("Company saved.");
    await render();
  } catch (error) {
    showNotice(`Could not save company: ${error.message || error}`, "warning");
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Company";
    }
  }
}

async function uploadCompanyLogo(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#company-logo-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const file = new FormData(formElement).get("logo");
  if (errorElement) errorElement.textContent = "";
  if (!file || !file.name) {
    if (errorElement) errorElement.textContent = "Choose a logo image first.";
    return;
  }

  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Uploading...";
  }

  try {
    const optimized = await optimizeLogo(file);
    const path = `${activeCompanyId}/logo-${crypto.randomUUID()}-${optimized.fileName}`;
    const upload = await withOperationTimeout(
      supabaseClient.storage.from("company-logos").upload(path, optimized.blob, {
        contentType: optimized.contentType,
        upsert: false,
      }),
      "Company logo upload timed out. Check your connection and try again.",
      25000
    );

    if (upload.error) {
      throw new Error(upload.error.message.includes("Bucket not found")
        ? "Run supabase/step-next-company-logo.sql before uploading a logo."
        : upload.error.message);
    }

    const { error } = await withOperationTimeout(
      supabaseClient.rpc("set_company_logo", {
        target_company_id: activeCompanyId,
        new_logo_path: path,
      }),
      "Company logo record save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      await removeUploadedObject("company-logos", path);
      throw new Error(isColumnSchemaError(error, ["logo_path"])
        ? "Run supabase/step-next-company-logo.sql before saving a company logo."
        : error.message.includes("set_company_logo")
        ? "Run supabase/step-next-company-logo.sql, then try uploading the logo again."
        : error.message);
    }

    const activeCompany = companies.find((company) => company.id === activeCompanyId);
    if (activeCompany) {
      activeCompany.logo_path = path;
      activeCompany.logoUrl = URL.createObjectURL(optimized.blob);
    }

    showNotice("Company logo uploaded.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not upload logo.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Upload Logo";
    }
  }
}

async function createLocation(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#location-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const name = String(new FormData(formElement).get("name") || "").trim();
  if (!name) return;
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }

  try {
    const { data, error } = await withOperationTimeout(
      createLocationRecord(supabaseClient, activeCompanyId, name),
      "Location save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      if (isColumnSchemaError(error, ["locations"])) locationsReady = false;
      throw new Error(locationsReady ? error.message : "Run supabase/step-next-locations.sql before adding locations.");
    }

    activeLocationId = data.id;
    persistActiveLocationId(activeLocationId);
    showNotice("Location added.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not add location.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Location";
    }
  }
}

async function reloadAppIssueReports() {
  const { data, error } = await withOperationTimeout(
    listAppIssueReports(supabaseClient, activeCompanyId),
    "App issue report load timed out. Check your connection and try again.",
    12000
  );
  appIssueReportsReady = !error;
  appIssueReports = error ? [] : (data || []);
  if (error) throw error;
}

function appIssueReportError(error) {
  if (isColumnSchemaError(error, ["app_issue_reports"]) || String(error.message || "").includes("app_issue_reports")) {
    appIssueReportsReady = false;
    return "Run supabase/step-next-app-issue-reports.sql before saving app issue reports.";
  }
  return error.message || String(error);
}

async function createAppIssueReport(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#app-issue-report-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Sending...";
  }

  try {
    const payload = {
      company_id: activeCompanyId,
      location_id: activeLocationDatabaseId(),
      reporter_id: session.user.id,
      screen: String(form.get("screen") || activeSection || "workspace").slice(0, 80),
      page_url: window.location.href,
      severity: String(form.get("severity") || "normal"),
      title: requiredText(form.get("title"), "Short title").slice(0, 140),
      details: requiredText(form.get("details"), "Details"),
      status: "open",
    };

    const { error } = await withOperationTimeout(
      createAppIssueReportRecord(supabaseClient, payload),
      "App issue report save timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;

    reportIssueMode = false;
    showNotice("Issue report sent.");
    await reloadAppIssueReports();
    renderWorkspace();
  } catch (error) {
    if (errorElement) errorElement.textContent = appIssueReportError(error);
  } finally {
    if (submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Send Report";
    }
  }
}

async function updateAppIssueReportStatus(event) {
  event.preventDefault();
  if (!canManageTeam()) return;
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const nextStatus = String(form.get("status") || "open");
    const { error } = await withOperationTimeout(
      updateAppIssueReportStatusRecord(
        supabaseClient,
        activeCompanyId,
        formElement.dataset.appIssueStatus,
        nextStatus
      ),
      "Issue report status save timed out. Check your connection and try again.",
      12000
    );
    if (error) throw error;

    showNotice("Issue report updated.");
    await reloadAppIssueReports();
    renderWorkspace();
  } catch (error) {
    showNotice(`Could not update issue report: ${appIssueReportError(error)}`, "warning");
  } finally {
    if (submitButton?.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Save";
    }
  }
}

async function createPublicRequestLink(locationId) {
  const errorElement = document.querySelector("#public-request-link-error");
  const button = document.querySelector(`[data-create-public-request-link="${CSS.escape(locationId)}"]`);
  if (errorElement) errorElement.textContent = "";
  if (button) {
    button.disabled = true;
    button.textContent = "Creating...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient.rpc("ensure_location_request_link", {
        target_location_id: locationId,
      }),
      "QR link save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      publicRequestLinksReady = false;
      throw new Error(error.message.includes("ensure_location_request_link")
        ? "Run supabase/step-next-public-request-links.sql before creating QR request links."
        : error.message);
    }

    showNotice("Location request QR link ready.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not create QR request link.";
  } finally {
    if (button) {
      button.disabled = false;
      button.textContent = "Create QR Link";
    }
  }
}

async function disablePublicRequestLink(linkId) {
  if (!canAdministerPublicRequestLinks()) {
    const errorElement = document.querySelector("#public-request-link-error");
    if (errorElement) errorElement.textContent = "Only admins can disable posted QR request links.";
    return;
  }
  const confirmed = window.confirm("Disable this public request QR link? Posted codes for this location will stop accepting requests until you reactivate it.");
  if (!confirmed) return;
  await setPublicRequestLinkActive(linkId, false);
}

async function setPublicRequestLinkActive(linkId, isActive) {
  if (!canAdministerPublicRequestLinks()) {
    const errorElement = document.querySelector("#public-request-link-error");
    if (errorElement) errorElement.textContent = "Only admins can reactivate or disable posted QR request links.";
    return;
  }
  await updatePublicRequestLink(
    linkId,
    { is_active: Boolean(isActive) },
    isActive ? "Request link reactivated." : "Request link disabled.",
  );
}

async function regeneratePublicRequestLink(linkId) {
  if (!canAdministerPublicRequestLinks()) {
    const errorElement = document.querySelector("#public-request-link-error");
    if (errorElement) errorElement.textContent = "Only admins can replace posted QR request links.";
    return;
  }
  const confirmed = window.confirm("Regenerate this QR code? Any QR codes already printed or shared for this location will stop working.");
  if (!confirmed) return;

  await updatePublicRequestLink(
    linkId,
    {
      token: generatePublicRequestToken(),
      is_active: true,
    },
    "Request QR regenerated.",
  );
}

async function updatePublicRequestLink(linkId, patch, successMessage) {
  const errorElement = document.querySelector("#public-request-link-error");
  if (errorElement) errorElement.textContent = "";

  if (!canAdministerPublicRequestLinks()) {
    if (errorElement) errorElement.textContent = "Only admins can replace, disable, or reactivate posted QR request links.";
    return;
  }

  if (!linkId || !activeCompanyId) {
    if (errorElement) errorElement.textContent = "Select a company before updating request links.";
    return;
  }

  try {
    const { data, error } = await withOperationTimeout(
      supabaseClient
        .from("public_request_links")
        .update({
          ...patch,
          updated_at: new Date().toISOString(),
        })
        .eq("id", linkId)
        .eq("company_id", activeCompanyId)
        .select("id"),
      "Request link update timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      if (errorElement) errorElement.textContent = error.message;
      return;
    }

    if (!data?.length) {
      if (errorElement) {
        errorElement.textContent = "Could not update the request link. Check that your company role is admin or manager.";
      }
      return;
    }

    showNotice(successMessage);
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not update the request link.";
  }
}

function generatePublicRequestToken() {
  if (window.crypto?.getRandomValues) {
    const bytes = new Uint8Array(18);
    window.crypto.getRandomValues(bytes);
    return btoa(String.fromCharCode(...bytes)).replaceAll("+", "-").replaceAll("/", "_").replaceAll("=", "");
  }

  return `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}${Math.random().toString(36).slice(2)}`;
}

function savePublicAppUrl(event) {
  event.preventDefault();
  const errorElement = document.querySelector("#public-request-link-error");
  const rawUrl = String(new FormData(event.currentTarget).get("public_app_url") || "").trim();
  if (errorElement) errorElement.textContent = "";

  if (!rawUrl) {
    publicAppUrlOverride = "";
    localStorage.removeItem("maintainops.publicAppUrl");
    showNotice("Public app URL cleared.");
    renderWorkspace();
    return;
  }

  const normalizedUrl = normalizePublicAppUrl(rawUrl);
  if (!normalizedUrl) {
    if (errorElement) errorElement.textContent = "Enter the public https:// URL where MaintainOps opens. Localhost, file paths, and private network addresses cannot be used for posted QR codes.";
    return;
  }

  publicAppUrlOverride = normalizedUrl;
  localStorage.setItem("maintainops.publicAppUrl", publicAppUrlOverride);
  showNotice("Public app URL saved.");
  renderWorkspace();
}

async function createPart(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#part-create-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Adding...";
  }
  let saveTimeoutId;

  try {
    const payload = {
      company_id: activeCompanyId,
      location_id: activeLocationDatabaseId(),
      name: String(form.get("name") || "").trim(),
      sku: String(form.get("sku") || "").trim() || null,
      supplier_name: String(form.get("supplier_name") || "").trim() || null,
      quantity_on_hand: Number(form.get("quantity_on_hand")) || 0,
      reorder_point: Number(form.get("reorder_point")) || 0,
      unit_cost: Number(form.get("unit_cost")) || 0,
    };

    if (!payload.company_id) {
      throw new Error("Choose a company before adding parts.");
    }
    if (!payload.name) {
      throw new Error("Part name is required.");
    }

    const saveTimeout = new Promise((_, reject) => {
      saveTimeoutId = setTimeout(() => reject(new Error("Part save timed out. Check your connection and try again.")), 20000);
    });
    const { data, error } = await Promise.race([
      supabaseClient.from("parts").insert(payload).select("id").single(),
      saveTimeout,
    ]);
    clearTimeout(saveTimeoutId);

    if (error && isMissingColumnError(error, "location_id")) {
      locationsReady = false;
      throw new Error(databaseSetupRequiredMessage("saving parts by location"));
    }
    if (error && isMissingColumnError(error, "supplier_name")) {
      partSuppliersReady = false;
      throw new Error("Source/vendor is not active in Supabase yet. Run supabase/step-next-part-suppliers.sql, then add the part again.");
    }
    if (error && isMissingColumnError(error, "unit_cost")) {
      partCostsReady = false;
      throw new Error("Unit cost is not active in Supabase yet. Run supabase/step-next-part-costs.sql, then add the part again.");
    }
    if (error) {
      throw error;
    }

    activePartId = data?.id || null;
    clearPartSearchState();
    showNotice("Part added.");
    formElement.reset();
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not add part.";
  } finally {
    if (saveTimeoutId) clearTimeout(saveTimeoutId);
    if (submitButton && submitButton.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Add Part";
    }
  }
}

async function restockPart(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const part = parts.find((item) => item.id === formElement.dataset.restockPart);
  const quantity = Number(new FormData(formElement).get("quantity")) || 0;
  if (!part || quantity <= 0) return;
  const originalText = submitButton?.textContent || "Restock";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .update({ quantity_on_hand: (Number(part.quantity_on_hand) || 0) + quantity })
        .eq("id", part.id)
        .eq("company_id", activeCompanyId),
      "Part restock timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    showNotice("Part restocked.");
    await render();
  } catch (error) {
    showNotice(`Could not restock part: ${error.message || error}`, "warning");
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }
}

async function usePartFromInventory(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const part = parts.find((item) => item.id === formElement.dataset.usePart);
  const quantity = Number(new FormData(formElement).get("quantity")) || 0;
  if (!part || quantity <= 0) return;
  const originalText = submitButton?.textContent || "Use";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const currentQuantity = Number(part.quantity_on_hand) || 0;
    const nextQuantity = Math.max(0, currentQuantity - quantity);
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .update({ quantity_on_hand: nextQuantity })
        .eq("id", part.id)
        .eq("company_id", activeCompanyId),
      "Part use save timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    showNotice("Part used.");
    await render();
  } catch (error) {
    showNotice(`Could not use part: ${error.message || error}`, "warning");
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }
}

async function updatePart(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const partId = formElement.dataset.editPart;
  const errorElement = document.querySelector(`[data-part-edit-error="${partId}"]`);
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  if (errorElement) errorElement.textContent = "";
  const originalText = submitButton?.textContent || "Save Part";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  const payload = {
    name: String(form.get("name") || "").trim(),
    sku: form.get("sku") || null,
    supplier_name: form.get("supplier_name") || null,
    quantity_on_hand: Number(form.get("quantity_on_hand")) || 0,
    reorder_point: Number(form.get("reorder_point")) || 0,
    unit_cost: Number(form.get("unit_cost")) || 0,
  };

  try {
    if (!payload.name) throw new Error("Part name is required.");

    const { error } = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .update(payload)
        .eq("id", partId)
        .eq("company_id", activeCompanyId),
      "Part save timed out. Check your connection and try again.",
      15000
    );

    if (error && isMissingColumnError(error, "supplier_name")) {
      partSuppliersReady = false;
      throw new Error("Source/vendor is not active in Supabase yet. Run supabase/step-next-part-suppliers.sql, then save again.");
    }

    if (error && isMissingColumnError(error, "unit_cost")) {
      partCostsReady = false;
      throw new Error("Unit cost is not active in Supabase yet. Run supabase/step-next-part-costs.sql, then save again.");
    }

    if (error) throw error;

    activePartId = null;
    clearPartSearchState();
    showNotice("Part saved.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not save part.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  }
}

function requestDeletePart(id) {
  if (!canDeleteParts()) {
    alert("Only company admins and managers can delete parts.");
    return;
  }

  const part = parts.find((item) => item.id === id);
  if (!part) return;
  if (partUsageRows(id).length) {
    alert("This part has work order usage history and is kept for traceability.");
    return;
  }

  const confirmButtonVisible = Boolean(document.querySelector(`[data-delete-part="${CSS.escape(id)}"].permanent-delete-button`));
  if (pendingDeletePartId === id || confirmButtonVisible) {
    deletePart(id);
    return;
  }

  pendingDeletePartId = id;
  renderWorkspace();
}

async function deletePart(id) {
  if (!canDeleteParts()) {
    alert("Only company admins and managers can delete parts.");
    return;
  }

  const part = parts.find((item) => item.id === id);
  const errorElement = document.querySelector("#part-delete-error");
  if (errorElement) errorElement.textContent = "";
  if (!part) return;

  if (partUsageRows(id).length) {
    if (errorElement) errorElement.textContent = "This part has work order usage history and is kept for traceability.";
    return;
  }
  const confirmButton = document.querySelector(`[data-delete-part="${CSS.escape(id)}"].permanent-delete-button`);
  if (confirmButton) {
    confirmButton.disabled = true;
    confirmButton.textContent = "Deleting...";
  }

  try {
    const documentPaths = (partDocumentsByPartId[id] || [])
      .map((document) => document.storage_path)
      .filter(Boolean);
    if (documentPaths.length) {
      const storageDelete = await withOperationTimeout(
        supabaseClient.storage.from("part-documents").remove(documentPaths),
        "Part document cleanup timed out. Try deleting again.",
        15000
      );
      if (storageDelete.error) {
        throw new Error(`Could not remove filed receipts/invoices: ${storageDelete.error.message}`);
      }
    }

    const { data, error } = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .select("id"),
      "Part delete timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      throw new Error(error.message.includes("violates foreign key constraint")
        ? "This part is used on a work order and cannot be deleted."
        : error.message);
    }

    if (!data?.length) {
      throw new Error("Part was not deleted. Check that your company role is admin or manager and that supabase/step-next-part-delete.sql has been run.");
    }

    const verification = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .select("id")
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .maybeSingle(),
      "Part delete verification timed out. Refresh and check the part list.",
      15000
    );

    if (verification.error) {
      throw new Error(`Part delete verification failed: ${verification.error.message}`);
    }

    if (verification.data) {
      throw new Error("Part delete did not persist in Supabase. Run supabase/step-next-part-delete.sql, then try again.");
    }

    activePartId = null;
    pendingDeletePartId = null;
    showNotice("Part deleted.");
    await render();
  } catch (error) {
    showNotice(error.message || "Could not delete part.", "warning");
    if (errorElement) {
      errorElement.textContent = error.message || "Could not delete part.";
    }
    if (confirmButton) {
      confirmButton.disabled = false;
      confirmButton.textContent = "Permanently Delete";
    }
  }
}

async function renamePartSource(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#part-source-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  const form = new FormData(formElement);
  const oldSource = String(form.get("old_source") || "").trim();
  const newSource = String(form.get("new_source") || "").trim();

  if (errorElement) errorElement.textContent = "";
  if (!oldSource) return;
  if (!partSuppliersReady) {
    if (errorElement) errorElement.textContent = "Run supabase/step-next-part-suppliers.sql before editing sources.";
    return;
  }
  if (oldSource === newSource) {
    if (errorElement) errorElement.textContent = "Change the source name before saving.";
    return;
  }

  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Renaming...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("parts")
        .update({ supplier_name: newSource || null })
        .eq("company_id", activeCompanyId)
        .eq("supplier_name", oldSource),
      "Part source rename timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      if (isMissingColumnError(error, "supplier_name")) partSuppliersReady = false;
      throw new Error(partSuppliersReady
        ? error.message
        : "Run supabase/step-next-part-suppliers.sql before editing sources.");
    }

    showNotice("Part source updated.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not update part source.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Rename";
    }
  }
}

async function uploadPartDocument(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const partId = formElement.dataset.partDocument;
  const errorElement = document.querySelector(`[data-part-document-error="${partId}"]`);
  const submitButton = formElement.querySelector("button[type='submit']");
  const file = new FormData(formElement).get("document");

  if (errorElement) errorElement.textContent = "";
  if (!partDocumentsReady) {
    if (errorElement) errorElement.textContent = "Run supabase/step-next-part-documents.sql before attaching files.";
    return;
  }
  if (!file || !file.name) {
    if (errorElement) errorElement.textContent = "Choose a receipt, invoice, photo, or PDF first.";
    return;
  }

  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Attaching...";
  }

  const fileName = safeFileName(file.name || "part-file");
  const path = `${activeCompanyId}/${partId}/${crypto.randomUUID()}-${fileName}`;
  try {
    const upload = await withOperationTimeout(
      supabaseClient.storage.from("part-documents").upload(path, file, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      }),
      "Part file upload timed out. Check your connection and try again.",
      25000
    );

    if (upload.error) throw upload.error;

    const { error } = await withOperationTimeout(
      supabaseClient.from("part_documents").insert({
        company_id: activeCompanyId,
        part_id: partId,
        uploaded_by: session.user.id,
        storage_path: path,
        file_name: fileName,
        content_type: file.type || null,
      }),
      "Part file record save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      await removeUploadedObject("part-documents", path);
      if (isColumnSchemaError(error, ["part_documents"])) partDocumentsReady = false;
      throw new Error(partDocumentsReady
        ? error.message
        : "Run supabase/step-next-part-documents.sql before attaching files.");
    }

    showNotice("Part file attached.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not attach file.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Attach File";
    }
  }
}

async function recordPartUsed(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorElement = document.querySelector("#parts-used-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Recording...";
  }

  try {
    const form = new FormData(formElement);
    const partId = form.get("part_id");
    const quantity = Number(form.get("quantity_used")) || 1;
    const part = parts.find((item) => item.id === partId);
    if (!activeWorkOrderId) throw new Error("Open a work order before recording parts.");
    if (!part) throw new Error("Choose a part first.");

    const usageError = await addPartUsageToWorkOrder(activeWorkOrderId, part, quantity);
    if (usageError) throw usageError;

    showNotice("Part recorded on work order.");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not record part used.";
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Record Part Used";
    }
  }
}
async function addPartUsageToWorkOrder(workOrderId, part, quantity) {
  if (!part) return new Error("Choose a part first.");

  const { error } = await withOperationTimeout(
    supabaseClient.rpc("record_work_order_part_usage", {
      p_company_id: activeCompanyId,
      p_work_order_id: workOrderId,
      p_part_id: part.id,
      p_quantity: quantity,
    }),
    "Part usage save timed out."
  );
  if (error) return error;
  return null;
}

async function generatePreventiveWorkOrder(scheduleId) {
  const schedule = preventiveSchedules.find((item) => item.id === scheduleId);
  if (!schedule) return;
  const button = document.querySelector(`[data-generate-pm="${CSS.escape(scheduleId)}"]`);
  if (button) {
    button.disabled = true;
    button.textContent = "Generating...";
  }

  try {
    const payload = {
      company_id: activeCompanyId,
      location_id: locationIdForAsset(schedule.asset_id),
      asset_id: schedule.asset_id,
      title: schedule.title,
      description: `Generated from preventive schedule: ${schedule.frequency}.`,
      priority: "medium",
      type: "preventive",
      status: "open",
      due_at: schedule.next_due_at,
      ...procedureColumn(schedule.procedure_template_id),
      created_by: session.user.id,
    };
    applySafetyRequirementPayload(payload);
    applySafetyCheckPayload(payload, false);
    const { data, error } = await withOperationTimeout(
      insertWithOptionalProcedure("work_orders", payload, { returnSingle: true }),
      "PM work order generation timed out."
    );

    if (error) throw error;

    activeWorkOrderId = data.id;
    activeSection = "work";
    let scheduleWarning = "";
    try {
      const scheduleUpdate = await withOperationTimeout(
        supabaseClient
          .from("preventive_schedules")
          .update({ next_due_at: nextDueDate(schedule.next_due_at, schedule.frequency) })
          .eq("id", schedule.id)
          .eq("company_id", activeCompanyId),
        "PM next due date update timed out."
      );
      if (scheduleUpdate.error) scheduleWarning = scheduleUpdate.error.message;
    } catch (updateError) {
      scheduleWarning = updateError.message || String(updateError);
    }
    showNotice(
      scheduleWarning ? `PM work generated, but next due date did not update: ${scheduleWarning}` : "PM work order generated.",
      scheduleWarning ? "warning" : "success"
    );
    await render();
  } catch (error) {
    showNotice(`Could not generate PM work: ${error.message || error}`, "warning");
    if (button) {
      button.disabled = false;
      button.textContent = "Generate Work";
    }
  }
}

async function createFollowUpWorkOrder(sourceId) {
  const source = workOrders.find((item) => item.id === sourceId);
  if (!source) return;

  const payload = {
    company_id: activeCompanyId,
    location_id: source.location_id || locationIdForAsset(source.asset_id),
    asset_id: source.asset_id || null,
    assigned_to: source.assigned_to || null,
    title: `Follow-up: ${source.title}`,
    description: [
      source.resolution_summary ? `Prior resolution: ${source.resolution_summary}` : "",
      source.completion_notes ? `Prior notes: ${source.completion_notes}` : "",
      `Created from completed work order ${source.title}.`,
    ].filter(Boolean).join("\n\n"),
    priority: source.priority || "medium",
    type: "corrective",
    status: "open",
    due_at: null,
    created_by: session.user.id,
  };
  applySafetyRequirementPayload(payload);
  applySafetyCheckPayload(payload, false);
  try {
    const { data, error } = await withOperationTimeout(
      insertWithOptionalProcedure("work_orders", payload, { returnSingle: true }),
      "Follow-up work order save timed out."
    );
    if (error) throw error;

    let sourceWarning = "";
    try {
      const sourceUpdate = await withOperationTimeout(
        updateWorkOrderSafely({ follow_up_needed: false }, source.id),
        "Follow-up source update timed out."
      );
      if (sourceUpdate.error) sourceWarning = sourceUpdate.error.message;
    } catch (updateError) {
      sourceWarning = updateError.message || String(updateError);
    }
    if (sourceWarning) showNotice(`Follow-up created, but source order did not update: ${sourceWarning}`, "warning");
    await recordWorkOrderEvent(source.id, "follow_up_created", `Follow-up work order created: ${data.title}.`);
    await recordWorkOrderEvent(data.id, "created", `Created as follow-up from ${source.title}.`);
    activeSection = "work";
    activeWorkOrderId = data.id;
    localStorage.setItem("maintainops.activeSection", activeSection);
    await render();
  } catch (error) {
    showNotice(`Could not create follow-up work: ${error.message || error}`, "warning");
  }
}

function nextDueDate(value, frequency) {
  const date = new Date(`${value}T00:00:00`);
  if (frequency === "weekly") date.setDate(date.getDate() + 7);
  if (frequency === "monthly") date.setMonth(date.getMonth() + 1);
  if (frequency === "quarterly") date.setMonth(date.getMonth() + 3);
  return date.toISOString().slice(0, 10);
}

async function createWorkOrder(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#create-work-order-error");
  submitButton.disabled = true;
  submitButton.textContent = "Creating...";
  if (errorTarget) errorTarget.textContent = "";

  try {
    const form = new FormData(formElement);
    const status = form.get("status") || "open";
    let assetId = form.get("asset_id") || null;
    const newAssetName = String(form.get("new_asset_name") || "").trim();
    if (newAssetName) {
      const { data: newAsset, error: assetError } = await createQuickFixAsset(newAssetName, "running");
      if (assetError) {
        if (errorTarget) errorTarget.textContent = `Could not add equipment: ${assetError.message}`;
        return;
      }
      assetId = newAsset.id;
    }
    if (!newAssetName && !confirmAssetLocationRouting(assetId, "creating this work order", errorTarget)) return;
    if (status === "completed" && assetRequiresSafety(assetId) && form.get("safety_devices_checked") !== "on") {
      if (errorTarget) errorTarget.textContent = "Check safety devices before creating completed work tied to equipment.";
      return;
    }
    const procedureCompletionMessage = status === "completed"
      ? blocksProcedureCompletion(null, form.get("procedure_template_id") || null)
      : "";
    if (procedureCompletionMessage) {
      setWorkOrderActionWarning("", "");
      if (errorTarget) errorTarget.textContent = `${procedureCompletionMessage} Create the work order first, then complete the checklist before marking it complete.`;
      return;
    }
    const payload = {
      company_id: activeCompanyId,
      location_id: locationIdForAsset(assetId),
      title: requiredText(form.get("title"), "Work order title"),
      description: descriptionWithAssignmentNote(form.get("description"), form.get("assigned_to")),
      asset_id: assetId,
      priority: form.get("priority"),
      type: form.get("type") || "reactive",
      due_at: workOrderDateValue(form.get("due_at")),
      assigned_to: assignedUserFromForm(form),
      ...procedureColumn(form.get("procedure_template_id")),
      status,
      created_by: session.user.id,
      actual_minutes: Number(form.get("actual_minutes")) || 0,
      failure_cause: form.get("failure_cause") || null,
      resolution_summary: form.get("resolution_summary") || null,
      follow_up_needed: form.get("follow_up_needed") === "on",
      completion_notes: form.get("completion_notes") || null,
      completed_at: status === "completed" ? new Date().toISOString() : null,
    };
    applySafetyRequirementPayload(payload);
    applySafetyCheckPayload(payload, status === "completed" && payload.safety_check_required && form.get("safety_devices_checked") === "on");
    const { data, error } = await withOperationTimeout(
      insertWithOptionalProcedure("work_orders", payload, { returnSingle: true }),
      "Work order creation timed out. Check your connection and try again."
    );
    if (error) {
      if (errorTarget) errorTarget.textContent = `Could not create work order: ${friendlyWorkOrderSaveError(error)}`;
      return;
    }
    await recordWorkOrderEvent(data.id, "created", "Work order created.");
    if (newAssetName) {
      await recordWorkOrderEvent(data.id, "equipment_created", `Equipment created from work order: ${newAssetName}.`);
    }

    const warnings = [];
    const partId = form.get("part_id");
    if (partId) {
      const part = parts.find((item) => item.id === partId);
      const partError = await addPartUsageToWorkOrder(data.id, part, Number(form.get("quantity_used")) || 1);
      if (partError) warnings.push(`part usage failed: ${partError.message}`);
      else await recordWorkOrderEvent(data.id, "part_used", `Part recorded: ${part?.name || "Part"}.`);
    }

    const photo = form.get("photo");
    if (photo && photo.name) {
      const photoError = await addPhotoToWorkOrder(data.id, photo);
      if (photoError) warnings.push(`photo upload failed: ${photoError.message}`);
      else await recordWorkOrderEvent(data.id, "photo_uploaded", `Photo uploaded: ${photo.name}.`);
    }

    const initialComment = String(form.get("initial_comment") || "").trim();
    if (initialComment) {
      const commentError = await addCommentToWorkOrder(data.id, initialComment);
      if (commentError) warnings.push(`comment failed: ${commentError.message}`);
      else await recordWorkOrderEvent(data.id, "comment_added", "Initial comment added.");
    }

    activeWorkOrderId = data.id;
    createWorkOrderMode = false;
    showNotice(warnings.length ? `Work order created with warning: ${warnings[0]}` : "Work order created.", warnings.length ? "warning" : "success");
    await render();
  } catch (error) {
    if (errorTarget) errorTarget.textContent = `Could not create work order: ${error.message || error}`;
    else alert(error.message || error);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Create Work Order";
  }
}

function openQuickFixForRequest(requestId) {
  const request = maintenanceRequests.find((item) => item.id === requestId);
  if (!request) return;
  quickFixRequestId = requestId;
  quickFixAssetId = request.asset_id || null;
  quickFixMode = true;
  activeWorkOrderId = null;
  activeAssetId = null;
  createWorkOrderMode = false;
  activeSection = "mywork";
  localStorage.setItem("maintainops.activeSection", activeSection);
  renderWorkspace();
}

async function createQuickFix(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const errorTarget = document.querySelector("#quick-fix-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  if (errorTarget) errorTarget.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const form = new FormData(formElement);
    const title = String(form.get("title") || "").trim();
    if (!title) throw new Error("Quick Fix issue is required.");
    const resolutionSummary = String(form.get("resolution_summary") || "").trim();
    const quickFixSummary = resolutionSummary || title;
    const markCompleted = form.get("mark_completed") === "on";
    const machineDown = form.get("machine_down") === "on";
    let assetId = form.get("asset_id") || null;
    const sourceRequest = quickFixRequestId ? maintenanceRequests.find((request) => request.id === quickFixRequestId) : null;
    const newAssetName = String(form.get("new_asset_name") || "").trim();
    if (newAssetName) {
      const { data: newAsset, error: assetError } = await withOperationTimeout(
        createQuickFixAsset(newAssetName, machineDown ? "offline" : "running"),
        "Equipment save timed out. Check your connection and try again."
      );
      if (assetError) {
        if (errorTarget) errorTarget.textContent = assetError.message;
        return;
      }
      assetId = newAsset.id;
    }
    if (!newAssetName && !confirmAssetLocationRouting(assetId, "logging this Quick Fix", errorTarget)) return;
    if (markCompleted && assetRequiresSafety(assetId) && form.get("safety_devices_checked") !== "on") {
      if (errorTarget) errorTarget.textContent = "Check safety devices before marking equipment work complete.";
      return;
    }
    const procedureCompletionMessage = markCompleted
      ? blocksProcedureCompletion(null, form.get("procedure_template_id") || null)
      : "";
    if (procedureCompletionMessage) {
      setWorkOrderActionWarning("", "");
      if (errorTarget) errorTarget.textContent = `${procedureCompletionMessage} Log it first, then complete the checklist before marking it complete.`;
      return;
    }

    const payload = {
      company_id: activeCompanyId,
      location_id: locationIdForAsset(assetId),
      title,
      description: descriptionWithRequestPhotoNote(descriptionWithAssignmentNote(quickFixSummary, form.get("assigned_to")), sourceRequest),
      asset_id: assetId,
      assigned_to: assignedUserFromForm(form, session.user.id),
      priority: form.get("priority") || "medium",
      type: form.get("type") || "corrective",
      status: markCompleted ? "completed" : "open",
      due_at: workOrderDateValue(form.get("due_at")),
      created_by: session.user.id,
      ...procedureColumn(form.get("procedure_template_id")),
      actual_minutes: 0,
      failure_cause: form.get("failure_cause") || null,
      resolution_summary: markCompleted ? quickFixSummary : (resolutionSummary || null),
      follow_up_needed: form.get("follow_up_needed") === "on",
      completion_notes: markCompleted ? quickFixSummary : null,
      completed_at: markCompleted ? new Date().toISOString() : null,
    };
    applySafetyRequirementPayload(payload);
    applySafetyCheckPayload(payload, markCompleted && payload.safety_check_required && form.get("safety_devices_checked") === "on");

    const { data, error } = await withOperationTimeout(
      insertWithOptionalProcedure("work_orders", payload, { returnSingle: true }),
      "Quick Fix save timed out. Check your connection and try again."
    );

    if (error) {
      if (errorTarget) errorTarget.textContent = `Could not log quick fix: ${friendlyWorkOrderSaveError(error)}`;
      return;
    }

    const warnings = [];
    const partId = form.get("part_id");
    const quantity = Number(form.get("quantity_used")) || 1;
    if (partId) {
      const part = parts.find((item) => item.id === partId);
      const partError = await withOperationTimeout(
        addPartUsageToWorkOrder(data.id, part, quantity),
        "Part usage save timed out.",
        12000
      ).catch((timeoutError) => timeoutError);
      if (partError) warnings.push(`part usage failed: ${partError.message}`);
    }

    const photo = form.get("photo");
    if (photo && photo.name) {
      const photoError = await withOperationTimeout(
        addPhotoToWorkOrder(data.id, photo),
        "Photo upload timed out.",
        25000
      ).catch((timeoutError) => timeoutError);
      if (photoError) warnings.push(`photo upload failed: ${photoError.message}`);
    }

    const assetStatus = machineDown ? "offline" : form.get("asset_status");
    if (payload.asset_id && !newAssetName && (machineDown || (markCompleted && assetStatus))) {
      const assetError = await withOperationTimeout(
        updateAssetStatus(payload.asset_id, assetStatus),
        "Equipment status update timed out.",
        12000
      ).catch((timeoutError) => timeoutError);
      if (assetError) {
        warnings.push(`equipment status did not update: ${assetError.message}`);
      } else {
        await withOperationTimeout(
          recordWorkOrderEvent(data.id, "asset_status_updated", machineDown ? "Equipment marked down/offline." : `Equipment status set to ${assetStatus}.`),
          "Activity log timed out.",
          8000
        ).catch((logError) => warnings.push(`history did not update: ${logError.message}`));
      }
    }

    await withOperationTimeout(
      recordWorkOrderEvent(data.id, "quick_fix", markCompleted ? "Quick fix recorded as completed." : "Quick fix logged and assigned to creator."),
      "Activity log timed out.",
      8000
    ).catch((logError) => warnings.push(`history did not update: ${logError.message}`));
    if (newAssetName) {
      await withOperationTimeout(
        recordWorkOrderEvent(data.id, "equipment_created", `Equipment created from Quick Fix: ${newAssetName}.`),
        "Activity log timed out.",
        8000
      ).catch((logError) => warnings.push(`history did not update: ${logError.message}`));
    }
    if (quickFixRequestId && requestsReady) {
      const requestUpdate = await withOperationTimeout(
        supabaseClient
          .from("maintenance_requests")
          .update({
            status: "converted",
            reviewed_by: session.user.id,
            reviewed_at: new Date().toISOString(),
            converted_work_order_id: data.id,
          })
          .eq("id", quickFixRequestId)
          .eq("company_id", activeCompanyId),
        "Request status update timed out.",
        12000
      ).catch((timeoutError) => ({ error: timeoutError }));
      if (requestUpdate.error) {
        warnings.push(`request status did not update: ${requestUpdate.error.message}`);
      } else {
        await withOperationTimeout(
          recordWorkOrderEvent(data.id, "request_quick_fixed", markCompleted ? "Request resolved through Quick Fix." : "Request converted to a Quick Fix work order."),
          "Activity log timed out.",
          8000
        ).catch((logError) => warnings.push(`history did not update: ${logError.message}`));
      }
    }
    activeWorkOrderId = data.id;
    activeAssetId = null;
    createWorkOrderMode = false;
    quickFixMode = false;
    quickFixAssetId = null;
    quickFixRequestId = null;
    showNotice(warnings.length ? `Quick Fix saved with warning: ${warnings[0]}` : "Quick Fix saved.", warnings.length ? "warning" : "success");
    await render();
  } catch (error) {
    if (errorTarget) errorTarget.textContent = `Could not log quick fix: ${error.message || error}`;
    else alert(error.message || error);
  } finally {
    if (submitButton && submitButton.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Log Quick Fix";
    }
  }
}

async function updateWorkOrderDetails(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#work-order-save-error");
  submitButton.disabled = true;
  submitButton.textContent = "Saving...";
  if (errorTarget) errorTarget.textContent = "";

  try {
    const form = new FormData(event.target);
    const previous = workOrders.find((workOrder) => workOrder.id === activeWorkOrderId);
    const currentStatus = document.querySelector("#status-select")?.value || previous?.status || "open";
    const payload = {
      title: requiredText(form.get("title"), "Work order title"),
      description: descriptionWithAssignmentNote(form.get("description"), form.get("assigned_to")),
      due_at: workOrderDateValue(form.get("due_at")),
      location_id: locationIdForAsset(previous?.asset_id || null),
      status: currentStatus,
      priority: form.get("priority"),
      type: form.get("type"),
      assigned_to: assignedUserFromForm(form),
      ...procedureColumn(form.get("procedure_template_id")),
      failure_cause: form.get("failure_cause") || null,
      resolution_summary: form.get("resolution_summary") || null,
      follow_up_needed: form.get("follow_up_needed") === "on",
      actual_minutes: Number(form.get("actual_minutes")) || 0,
    };
    payload.safety_check_required = assetRequiresSafety(previous?.asset_id || null);
    if (payload.status === "completed" && previous?.status !== "completed" && payload.safety_check_required && !hasCompletedSafetyDeviceCheck(previous) && form.get("safety_devices_checked") !== "on") {
      submitButton.disabled = false;
      submitButton.textContent = "Save Work Order";
      if (errorTarget) errorTarget.textContent = "Use Complete Work and check safety devices before completing equipment work.";
      return;
    }
    const procedureChanged = (previous?.procedure_template_id || "") !== (payload.procedure_template_id || "");
    const procedureCompletionMessage = payload.status === "completed" && (previous?.status !== "completed" || procedureChanged)
      ? blocksProcedureCompletion(previous, payload.procedure_template_id || null)
      : "";
    if (procedureCompletionMessage) {
      setWorkOrderActionWarning(activeWorkOrderId, procedureCompletionMessage);
      submitButton.disabled = false;
      submitButton.textContent = "Save Work Order";
      if (errorTarget) errorTarget.textContent = procedureCompletionMessage;
      return;
    }
    if (payload.status === "completed" && previous?.status !== "completed") {
      payload.completed_at = new Date().toISOString();
      applySafetyCheckPayload(payload, payload.safety_check_required && (form.get("safety_devices_checked") === "on" || hasCompletedSafetyDeviceCheck(previous)));
    } else if (payload.status !== "completed") {
      payload.completed_at = null;
      applySafetyCheckPayload(payload, false);
    } else if (previous?.status === "completed" && payload.safety_check_required && form.has("safety_devices_checked")) {
      applySafetyCheckPayload(payload, form.get("safety_devices_checked") === "on" || hasCompletedSafetyDeviceCheck(previous));
    } else if (previous?.status === "completed" && !payload.safety_check_required) {
      applySafetyCheckPayload(payload, false);
    }
    const { error } = await withOperationTimeout(
      updateWorkOrderSafely(payload, activeWorkOrderId),
      "Work order save timed out. Check your connection and try again.",
      20000
    );
    if (error) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Work Order";
      if (errorTarget) errorTarget.textContent = `Could not save work order: ${friendlyWorkOrderSaveError(error)}`;
      return;
    }
    const changeSnapshot = { ...Object.fromEntries(form.entries()), status: currentStatus };
    const logError = await withOperationTimeout(
      recordWorkOrderEvent(activeWorkOrderId, "updated", describeWorkOrderChanges(previous, changeSnapshot)),
      "Activity log timed out.",
      8000
    ).catch((error) => error);
    setWorkOrderActionWarning("", "");
    showNotice(logError ? `Work order saved, but history did not update: ${logError.message}` : "Work order saved.", logError ? "warning" : "success");
    await render();
  } catch (error) {
    console.error("Work order save failed", error);
    submitButton.disabled = false;
    submitButton.textContent = "Save Work Order";
    if (errorTarget) errorTarget.textContent = `Could not save work order: ${error.message || error}`;
  } finally {
    if (submitButton && submitButton.isConnected) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Work Order";
    }
  }
}

async function updateWorkOrderQuickView(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#quick-update-error");
  const previous = workOrders.find((workOrder) => workOrder.id === activeWorkOrderId);
  const form = new FormData(formElement);
  submitButton.disabled = true;
  submitButton.textContent = "Saving...";
  if (errorTarget) errorTarget.textContent = "";

  try {
    let assetId = form.get("asset_id") || null;
    const newAssetName = String(form.get("new_asset_name") || "").trim();
    if (newAssetName) {
      const { data: newAsset, error: assetError } = await createQuickFixAsset(newAssetName, "running");
      if (assetError) {
        submitButton.disabled = false;
        submitButton.textContent = "Save Quick Update";
        if (errorTarget) errorTarget.textContent = `Could not add equipment: ${assetError.message}`;
        return;
      }
      assetId = newAsset.id;
    }
    if (!newAssetName && !confirmAssetLocationRouting(assetId, "saving this work update", errorTarget)) return;
    const payload = {
      title: requiredText(form.get("title"), "Issue"),
      description: descriptionWithAssignmentNote(previous?.description || "", form.get("assigned_to")),
      asset_id: assetId,
      location_id: locationIdForAsset(assetId),
      due_at: workOrderDateValue(form.get("due_at")),
      status: form.get("status"),
      priority: form.get("priority"),
      assigned_to: assignedUserFromForm(form),
      resolution_summary: form.get("resolution_summary") || null,
    };
    applySafetyRequirementPayload(payload);
    const safetyChecked = form.get("safety_devices_checked") === "on";
    if (payload.status === "completed" && previous?.status !== "completed") {
      const procedureCompletionMessage = blocksProcedureCompletion(previous);
      if (procedureCompletionMessage) {
        setWorkOrderActionWarning(activeWorkOrderId, procedureCompletionMessage);
        submitButton.disabled = false;
        submitButton.textContent = "Save Quick Update";
        if (errorTarget) errorTarget.textContent = procedureCompletionMessage;
        return;
      }
      applySafetyCheckPayload(payload, safetyChecked);
      if (requiresSafetyDeviceCheck(payload) && !payload.safety_devices_checked) {
        submitButton.disabled = false;
        submitButton.textContent = "Save Quick Update";
        if (errorTarget) errorTarget.textContent = "Check safety devices before completing work tied to equipment.";
        return;
      }
      payload.completed_at = new Date().toISOString();
    }
    if (payload.status !== "completed") {
      payload.completed_at = null;
      applySafetyCheckPayload(payload, false);
    } else if (previous?.status === "completed") {
      applySafetyCheckPayload(payload, payload.safety_check_required && (safetyChecked || hasCompletedSafetyDeviceCheck(previous)));
    }

    const { error } = await withOperationTimeout(
      updateWorkOrderSafely(payload, activeWorkOrderId),
      "Quick update save timed out. Check your connection and try again.",
      20000
    );
    if (error) {
      submitButton.disabled = false;
      submitButton.textContent = "Save Quick Update";
      if (errorTarget) errorTarget.textContent = `Could not save update: ${friendlyWorkOrderSaveError(error)}`;
      return;
    }

    const warnings = [];
    if (payload.asset_id && form.get("machine_down") === "on") {
      const assetError = await updateAssetStatus(payload.asset_id, "offline");
      if (assetError) {
        warnings.push(`equipment status did not update: ${assetError.message}`);
      } else {
        await recordWorkOrderEvent(activeWorkOrderId, "asset_status_updated", "Equipment marked down/offline.");
      }
    }

    const logError = await withOperationTimeout(
      recordWorkOrderEvent(activeWorkOrderId, "quick_update", describeWorkOrderChanges(previous, Object.fromEntries(form.entries()))),
      "Activity log timed out.",
      8000
    ).catch((error) => error);
    if (newAssetName) {
      await withOperationTimeout(
        recordWorkOrderEvent(activeWorkOrderId, "equipment_created", `Equipment created from work order: ${newAssetName}.`),
        "Activity log timed out.",
        8000
      ).catch(() => null);
    }
    if (logError) warnings.push(`history did not update: ${logError.message}`);
    setWorkOrderActionWarning("", "");
    showNotice(warnings.length ? `Quick update saved with warning: ${warnings[0]}` : "Quick update saved.", warnings.length ? "warning" : "success");
    await render();
  } catch (error) {
    console.error("Quick update save failed", error);
    submitButton.disabled = false;
    submitButton.textContent = "Save Quick Update";
    if (errorTarget) errorTarget.textContent = `Could not save update: ${error.message || error}`;
  }
}

async function completeWorkOrder(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#completion-error");
  const workOrder = workOrders.find((item) => item.id === activeWorkOrderId);
  const procedure = procedureTemplates.find((template) => template.id === workOrder?.procedure_template_id);
  const requiredProgress = procedure ? requiredChecklistProgress(workOrder, procedure) : { done: 0, total: 0 };
  if (requiredProgress.done < requiredProgress.total) {
    if (errorTarget) errorTarget.textContent = `Complete required checklist steps first (${requiredProgress.done}/${requiredProgress.total}).`;
    return;
  }
  const form = new FormData(event.target);
  const safetyChecked = form.get("safety_devices_checked") === "on" || currentSafetyCheckboxCheckedForWorkOrder(activeWorkOrderId) || hasCompletedSafetyDeviceCheck(workOrder);
  if (requiresSafetyDeviceCheck(workOrder) && !safetyChecked) {
    if (errorTarget) errorTarget.textContent = "Check safety devices before completing equipment work.";
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Completing...";
  if (errorTarget) errorTarget.textContent = "";

  try {
    const payload = {
      status: "completed",
      asset_id: workOrder?.asset_id || null,
      actual_minutes: Number(form.get("actual_minutes")) || 0,
      failure_cause: form.get("failure_cause") || null,
      resolution_summary: form.get("resolution_summary") || null,
      follow_up_needed: form.get("follow_up_needed") === "on",
      completion_notes: form.get("completion_notes") || null,
      completed_at: new Date().toISOString(),
    };
    applySafetyRequirementPayload(payload);
    applySafetyCheckPayload(payload, payload.safety_check_required && safetyChecked);
    delete payload.asset_id;
    const { error } = await withOperationTimeout(
      updateWorkOrderSafely(payload, activeWorkOrderId),
      "Complete work save timed out. Check your connection and try again.",
      20000
    );
    if (error) {
      if (errorTarget) errorTarget.textContent = `Could not complete work order: ${friendlyWorkOrderSaveError(error)}`;
      return;
    }
    const logError = await withOperationTimeout(
      recordWorkOrderEvent(activeWorkOrderId, "completed", form.get("resolution_summary") || form.get("completion_notes") || "Work order completed."),
      "Activity log timed out.",
      8000
    ).catch((error) => error);
    setWorkOrderActionWarning("", "");
    showNotice(logError ? `Work order completed, but history did not update: ${logError.message}` : "Work order completed.", logError ? "warning" : "success");
    await render();
  } catch (error) {
    if (errorTarget) errorTarget.textContent = `Could not complete work order: ${error.message || error}`;
    else alert(error.message || error);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Complete Work Order";
  }
}

function renderRequestForm() {
  const detailPanel = document.querySelector("#detail-panel");
  detailPanel.innerHTML = renderRequestFormContent();
}

async function createRequest(event) {
  event.preventDefault();
  await createRequestFromForm(event.target);
}

async function createRequestFromForm(formElement) {
  const errorElement = document.querySelector("#request-error");
  const submitButton = formElement.querySelector("button[type='submit']");
  if (errorElement) errorElement.textContent = "";
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Submitting...";
  }

  try {
    const form = new FormData(formElement);
    const assetId = form.get("asset_id") || null;
    if (!confirmAssetLocationRouting(assetId, "submitting this request", errorElement)) return;
    const requestPayload = {
      company_id: activeCompanyId,
      location_id: locationIdForAsset(assetId),
      title: requiredText(form.get("title"), "Request title"),
      description: requiredText(form.get("description"), "Request description"),
      asset_id: assetId,
      priority: form.get("priority"),
      status: "submitted",
      requested_by: session.user.id,
    };

    if (!requestsReady) {
      throw new Error("Run supabase/step-next-maintenance-requests.sql before submitting requests.");
    }
    const { data, error } = await withOperationTimeout(
      supabaseClient.from("maintenance_requests").insert(requestPayload).select("*").single(),
      "Request save timed out. Check your connection and try again.",
      15000
    );
    if (error && isMissingColumnError(error, "location_id")) {
      locationsReady = false;
      throw new Error(databaseSetupRequiredMessage("saving requests by location"));
    }
    if (error) throw error;
    const photo = form.get("photo");
    let photoWarning = "";
    if (photo && photo.name) {
      const photoError = await addPhotoToMaintenanceRequest(data.id, photo);
      if (photoError) photoWarning = ` Photo did not upload: ${photoError.message || photoError}`;
    }
    activeSection = "requests";
    requestViewFilter = "active";
    requestsPage = 1;
    localStorage.setItem("maintainops.activeSection", activeSection);
    localStorage.setItem("maintainops.requestViewFilter", requestViewFilter);
    localStorage.setItem("maintainops.requestsPage", String(requestsPage));
    showNotice(`Request submitted.${photoWarning}`, photoWarning ? "warning" : "success");
    await render();
  } catch (error) {
    if (errorElement) errorElement.textContent = error.message || "Could not submit request.";
    else alert(error.message || error);
  } finally {
    if (submitButton) {
      submitButton.disabled = false;
      submitButton.textContent = "Submit Request";
    }
  }
}

// LFES-EVOLUTION: Request conversion is a workflow mutation boundary; preserve source request context and location when changing it.
async function convertRequestToWorkOrder(requestId) {
  const request = maintenanceRequests.find((item) => item.id === requestId);
  if (!request) return;
  const button = document.querySelector(`[data-convert-request="${CSS.escape(requestId)}"]`);
  if (button) {
    button.disabled = true;
    button.textContent = "Converting...";
  }

  try {
    const payload = {
      company_id: activeCompanyId,
      location_id: request.location_id || locationIdForAsset(request.asset_id),
      title: request.title,
      description: descriptionWithRequestPhotoNote(request.description, request),
      asset_id: request.asset_id || null,
      priority: request.priority || "medium",
      type: "reactive",
      status: "open",
      created_by: session.user.id,
    };
    applySafetyRequirementPayload(payload);
    applySafetyCheckPayload(payload, false);
    const { data, error } = await withOperationTimeout(
      insertWithOptionalProcedure("work_orders", payload, { returnSingle: true }),
      "Request conversion timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;

    const { error: updateError } = await withOperationTimeout(
      supabaseClient
        .from("maintenance_requests")
        .update({
          status: "converted",
          reviewed_by: session.user.id,
          reviewed_at: new Date().toISOString(),
          converted_work_order_id: data.id,
        })
        .eq("id", requestId)
        .eq("company_id", activeCompanyId),
      "Request status update timed out. Check your connection and try again.",
      15000
    );
    if (updateError) throw updateError;

    activeSection = "work";
    activeWorkOrderId = data.id;
    localStorage.setItem("maintainops.activeSection", activeSection);
    await withOperationTimeout(
      recordWorkOrderEvent(data.id, "request_converted", "Request converted to work order."),
      "Activity log timed out.",
      8000
    ).catch(() => null);
    showNotice("Request converted to work order.");
    await render();
  } catch (error) {
    showNotice(`Could not convert request: ${error.message || error}`, "warning");
    if (button) {
      button.disabled = false;
      button.textContent = "Convert to Work Order";
    }
  }
}

function requestDeleteMaintenanceRequest(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete requests.");
    return;
  }
  if (!maintenanceRequests.some((request) => request.id === id)) return;
  pendingDeleteRequestId = id;
  renderWorkspace();
}

async function deleteMaintenanceRequest(id) {
  if (!canDeleteOperationalRecords()) {
    alert("Only company admins and managers can delete requests.");
    return;
  }

  const request = maintenanceRequests.find((item) => item.id === id);
  if (!request) return;
  const button = document.querySelector(`[data-confirm-delete-request="${CSS.escape(id)}"]`);
  if (button) {
    button.disabled = true;
    button.textContent = "Deleting...";
  }

  try {
    if (request.photo_storage_path) {
      const storageDelete = await withOperationTimeout(
        supabaseClient.storage.from("maintenance-request-photos").remove([request.photo_storage_path]),
        "Request photo cleanup timed out.",
        15000
      );
      if (storageDelete.error) throw new Error(`Could not remove request photo: ${storageDelete.error.message}`);
    }

    const { data, error } = await withOperationTimeout(
      supabaseClient
        .from("maintenance_requests")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .select("id"),
      "Request delete timed out. Check your connection and try again.",
      15000
    );
    if (error) throw error;
    if (!data?.length) {
      throw new Error("Request was not deleted. Run supabase/step-next-cleanup-delete-paths.sql, then try again.");
    }

    const verification = await withOperationTimeout(
      supabaseClient
        .from("maintenance_requests")
        .select("id")
        .eq("id", id)
        .eq("company_id", activeCompanyId)
        .maybeSingle(),
      "Request delete verification timed out. Refresh and check the request list.",
      15000
    );
    if (verification.error) throw new Error(`Request delete verification failed: ${verification.error.message}`);
    if (verification.data) throw new Error("Request delete did not persist in Supabase.");

    pendingDeleteRequestId = null;
    showNotice("Request deleted.");
    await render();
  } catch (error) {
    showNotice(error.message || "Could not delete request.", "warning");
    if (button) {
      button.disabled = false;
      button.textContent = "Permanently Delete";
    }
  }
}

async function updateWorkOrderStatus(event) {
  const previous = workOrders.find((item) => item.id === activeWorkOrderId);
  event.target.disabled = true;
  try {
    const saved = await setWorkOrderStatus(activeWorkOrderId, event.target.value);
    if (!saved) event.target.value = previous?.status || "open";
  } catch (error) {
    event.target.value = previous?.status || "open";
    showNotice(`Could not update status: ${error.message || error}`, "warning");
  } finally {
    event.target.disabled = false;
  }
}

async function saveStepResult(event) {
  const field = event.target;
  const value = field.type === "checkbox" ? (field.checked ? "checked" : "") : field.value;
  field.disabled = true;
  try {
    const { error } = await withOperationTimeout(
      supabaseClient.from("work_order_step_results").upsert({
        company_id: activeCompanyId,
        work_order_id: field.dataset.workOrderId,
        procedure_step_id: field.dataset.stepResult,
        completed_by: value ? session.user.id : null,
        value,
        completed_at: value ? new Date().toISOString() : null,
      }, { onConflict: "work_order_id,procedure_step_id" }),
      "Checklist save timed out. Check your connection and try again.",
      15000
    );

    if (error) throw error;
    await withOperationTimeout(
      recordWorkOrderEvent(field.dataset.workOrderId, "checklist_updated", "Procedure checklist updated."),
      "Activity log timed out.",
      8000
    ).catch(() => null);
    const reloadError = await withOperationTimeout(
      loadStepResults(),
      "Checklist refresh timed out. Refresh the workspace to confirm the latest checklist state.",
      10000
    ).catch((error) => error);
    if (reloadError) {
      showNotice(`Checklist saved, but refresh did not finish: ${reloadError.message || reloadError}`, "warning");
      field.disabled = false;
      return;
    }
    if (workOrderActionWarningId === field.dataset.workOrderId) {
      const refreshedWorkOrder = workOrders.find((item) => item.id === field.dataset.workOrderId);
      if (!blocksProcedureCompletion(refreshedWorkOrder)) setWorkOrderActionWarning("", "");
    }
    renderWorkspace();
  } catch (error) {
    showNotice(`Could not save checklist step: ${error.message || error}`, "warning");
    field.disabled = false;
  }
}

async function setWorkOrderStatus(id, status) {
  const workOrder = workOrders.find((item) => item.id === id);
  if (status === "completed") {
    const procedureCompletionMessage = blocksProcedureCompletion(workOrder);
    if (procedureCompletionMessage) {
      activeWorkOrderId = id;
      setWorkOrderActionWarning(id, procedureCompletionMessage);
      showNotice(procedureCompletionMessage, "warning");
      await render();
      return false;
    }
  }
  const safetyCheckedNow = currentSafetyCheckboxCheckedForWorkOrder(id);
  const hasSafetyCheck = hasCompletedSafetyDeviceCheck(workOrder) || safetyCheckedNow;
  if (status === "completed" && requiresSafetyDeviceCheck(workOrder) && !hasSafetyCheck) {
    activeWorkOrderId = id;
    const safetyMessage = "Safety devices must be checked before completing equipment work. Open the work order and use Complete Work.";
    setWorkOrderActionWarning(id, safetyMessage);
    showNotice(safetyMessage, "warning");
    await render();
    return false;
  }
  const payload = {
    status,
    asset_id: workOrder?.asset_id || null,
    completed_at: status === "completed" ? new Date().toISOString() : null,
  };
  applySafetyRequirementPayload(payload);
  if (status === "completed") {
    applySafetyCheckPayload(payload, payload.safety_check_required && hasSafetyCheck);
  } else if (status !== "completed") {
    applySafetyCheckPayload(payload, false);
  }
  delete payload.asset_id;
  const { error } = await withOperationTimeout(
    updateWorkOrderSafely(payload, id),
    "Status save timed out. Check your connection and try again.",
    15000
  );
  if (error) {
    showNotice(`Could not update status: ${friendlyWorkOrderSaveError(error)}`, "warning");
    return false;
  }
  activeWorkOrderId = id;
  setWorkOrderActionWarning("", "");
  await recordWorkOrderEvent(id, "status_changed", `Status changed to ${statusLabel(status)}.`);
  showNotice(`Status changed to ${statusLabel(status)}.`);
  await render();
  return true;
}

function requestDeleteWorkOrder(id) {
  if (!canDeleteWorkOrders()) {
    alert("Only company admins can delete work orders.");
    return;
  }

  pendingDeleteWorkOrderId = id;
  renderWorkspace();
}

async function deleteWorkOrder(id) {
  if (!canDeleteWorkOrders()) {
    alert("Only company admins can delete work orders.");
    return;
  }

  try {
    const photoPaths = (photosByWorkOrder[id] || [])
      .map((photo) => photo.storage_path)
      .filter(Boolean);
    if (photoPaths.length) {
      const storageDelete = await withOperationTimeout(
        supabaseClient.storage.from("work-order-photos").remove(photoPaths),
        "Work order photo cleanup timed out.",
        15000
      );
      if (storageDelete.error) {
        console.warn("Work order photo storage cleanup failed", storageDelete.error);
      }
    }

    const { error } = await withOperationTimeout(
      supabaseClient
        .from("work_orders")
        .delete()
        .eq("id", id)
        .eq("company_id", activeCompanyId),
      "Work order delete timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      alert(`Could not delete work order: ${friendlyWorkOrderSaveError(error)}`);
      return;
    }

    activeWorkOrderId = null;
    activeAssetId = null;
    pendingDeleteWorkOrderId = null;
    showNotice("Work order deleted.");
    await render();
  } catch (error) {
    alert(`Could not delete work order: ${error.message || error}`);
  }
}

async function assignWorkOrderToMe(id) {
  try {
    const hasProfile = await ensureProfileForActiveCompany();
    if (!hasProfile) return alert(appError);
    const workOrder = workOrders.find((item) => item.id === id);
    if (!canAssignWorkOrderToMe(workOrder)) {
      return alert("Technicians can only claim unassigned work. Managers can reassign work.");
    }

    const { error } = await withOperationTimeout(
      supabaseClient
        .from("work_orders")
        .update({
          assigned_to: session.user.id,
          description: cleanWorkOrderDescription(workOrder?.description) || null,
        })
        .eq("id", id)
        .eq("company_id", activeCompanyId),
      "Assignment save timed out. Check your connection and try again.",
      15000
    );

    if (error) return alert(friendlyWorkOrderSaveError(error));
    activeWorkOrderId = id;
    activeAssetId = null;
    await recordWorkOrderEvent(id, "assigned", "Assigned to self.");
    await render();
  } catch (error) {
    alert(error.message || error);
  }
}

async function assignWorkOrderFromCard(event) {
  event.preventDefault();
  event.stopPropagation();
  const formElement = event.currentTarget;
  const workOrder = workOrders.find((item) => item.id === formElement.dataset.cardAssign);
  const form = new FormData(formElement);
  if (!workOrder) return;
  if (formElement.dataset.saving === "true") return;

  const assignmentValue = form.get("assigned_to") || "";
  const assignedTo = assignmentValue === OUTSIDE_VENDOR_VALUE ? null : assignmentValue || null;
  const nextDescription = descriptionWithAssignmentNote(workOrder.description, assignmentValue);
  const submitButton = formElement.querySelector("button[type='submit']");
  const originalButtonText = submitButton?.textContent || "Assign";

  formElement.dataset.saving = "true";
  formElement.classList.add("is-saving");
  if (submitButton) {
    submitButton.disabled = true;
    submitButton.textContent = "Saving...";
  }

  try {
    const { error } = await withOperationTimeout(
      supabaseClient
        .from("work_orders")
        .update({
          assigned_to: assignedTo,
          description: nextDescription,
        })
        .eq("id", workOrder.id)
        .eq("company_id", activeCompanyId),
      "Assignment save timed out. Check your connection and try again.",
      15000
    );

    if (error) {
      showNotice(`Could not assign: ${friendlyWorkOrderSaveError(error)}`, "warning");
      return;
    }

    Object.assign(workOrder, {
      assigned_to: assignedTo,
      description: nextDescription,
      assigned_profile: assignedTo ? { full_name: teamMemberName(assignedTo) } : null,
    });

    const summary = assignmentValue === OUTSIDE_VENDOR_VALUE
      ? "Assigned to outside vendor."
      : assignmentValue
        ? `Assigned to ${teamMemberName(assignmentValue)}.`
        : "Assignment cleared.";
    await recordWorkOrderEvent(workOrder.id, "assigned", summary);
    showNotice("Assignment saved.");
    await render();
  } catch (error) {
    showNotice(`Could not assign: ${error.message || error}`, "warning");
  } finally {
    delete formElement.dataset.saving;
    formElement.classList.remove("is-saving");
    if (submitButton && document.body.contains(submitButton)) {
      submitButton.disabled = false;
      submitButton.textContent = originalButtonText;
    }
  }
}

async function createComment(event) {
  event.preventDefault();
  const formElement = event.target;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#comment-error");
  const body = new FormData(formElement).get("body")?.trim();
  if (!body) return;

  submitButton.disabled = true;
  submitButton.textContent = "Adding...";
  if (errorTarget) errorTarget.textContent = "";

  try {
    const error = await addCommentToWorkOrder(activeWorkOrderId, body);

    if (error) {
      if (errorTarget) errorTarget.textContent = `Could not add comment: ${error.message || error}`;
      return;
    }

    await recordWorkOrderEvent(activeWorkOrderId, "comment_added", "Comment added.");
    await loadComments();
    await loadWorkOrderEvents();
    showNotice("Comment added.");
    await render();
  } catch (error) {
    if (errorTarget) errorTarget.textContent = `Could not add comment: ${error.message || error}`;
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Add Comment";
  }
}

async function addCommentToWorkOrder(workOrderId, body) {
  const hasProfile = await ensureProfileForActiveCompany();
  if (!hasProfile) return new Error(appError);

  const payload = {
    company_id: activeCompanyId,
    work_order_id: workOrderId,
    author_id: session.user.id,
    body,
  };
  let { error } = await withOperationTimeout(
    supabaseClient.from("work_order_comments").insert(payload),
    "Comment save timed out. Check your connection and try again.",
    15000
  );

  if (error && isProfileMissingError(error)) {
    await ensureProfileForActiveCompany();
    const retry = await withOperationTimeout(
      supabaseClient.from("work_order_comments").insert(payload),
      "Comment retry timed out. Check your connection and try again.",
      15000
    );
    error = retry.error;
  }
  return error || null;
}

async function uploadPhoto(event) {
  event.preventDefault();
  const formElement = event.currentTarget;
  const submitButton = formElement.querySelector("button[type='submit']");
  const errorTarget = document.querySelector("#photo-error");
  if (errorTarget) errorTarget.textContent = "";
  const file = new FormData(formElement).get("photo");
  if (!file || !file.name) {
    if (errorTarget) errorTarget.textContent = "Choose a photo first.";
    return;
  }

  submitButton.disabled = true;
  submitButton.textContent = "Uploading...";
  try {
    const hasProfile = await ensureProfileForActiveCompany();
    if (!hasProfile) throw new Error(appError);

    const error = await addPhotoToWorkOrder(activeWorkOrderId, file);
    if (error) throw error;
    await withOperationTimeout(
      recordWorkOrderEvent(activeWorkOrderId, "photo_uploaded", `Photo uploaded: ${file.name}.`),
      "Activity log timed out.",
      8000
    ).catch(() => null);
    showNotice("Photo uploaded.");
    await render();
  } catch (error) {
    if (errorTarget) errorTarget.textContent = `Could not upload photo: ${error.message || error}`;
    else alert(error.message || error);
  } finally {
    submitButton.disabled = false;
    submitButton.textContent = "Upload Photo";
  }
}

async function removeUploadedObject(bucket, path) {
  try {
    const { error } = await withOperationTimeout(
      supabaseClient.storage.from(bucket).remove([path]),
      "Uploaded file cleanup timed out.",
      10000
    );
    if (error) console.warn(`Could not remove uploaded ${bucket} object`, error);
  } catch (error) {
    console.warn(`Could not remove uploaded ${bucket} object`, error);
  }
}

async function addPhotoToWorkOrder(workOrderId, file) {
  const hasProfile = await ensureProfileForActiveCompany();
  if (!hasProfile) return new Error(appError);

  const optimized = await optimizePhoto(file);
  const path = `${activeCompanyId}/${workOrderId}/${crypto.randomUUID()}-${optimized.fileName}`;
  const upload = await withOperationTimeout(
    supabaseClient.storage.from("work-order-photos").upload(path, optimized.blob, {
      contentType: optimized.contentType,
      upsert: false,
    }),
    "Photo upload timed out. Check your connection and try again.",
    25000
  );
  if (upload.error) return upload.error;

  const photoRecord = {
    company_id: activeCompanyId,
    work_order_id: workOrderId,
    uploaded_by: session.user.id,
    storage_path: path,
    file_name: optimized.fileName,
    content_type: optimized.contentType,
    file_size_bytes: optimized.blob.size || null,
    original_file_name: safeFileName(file.name || "photo"),
    original_size_bytes: file.size || null,
  };

  let { error } = await withOperationTimeout(
    supabaseClient.from("work_order_photos").insert(photoRecord),
    "Photo record save timed out. Check your connection and try again.",
    15000
  );
  if (error && isColumnSchemaError(error, ["file_size_bytes", "original_file_name", "original_size_bytes"])) {
    delete photoRecord.file_size_bytes;
    delete photoRecord.original_file_name;
    delete photoRecord.original_size_bytes;
    const retry = await withOperationTimeout(
      supabaseClient.from("work_order_photos").insert(photoRecord),
      "Photo record retry timed out. Check your connection and try again.",
      15000
    );
    error = retry.error;
  }
  if (error) await removeUploadedObject("work-order-photos", path);
  return error || null;
}

async function addPhotoToMaintenanceRequest(requestId, file) {
  if (!requestId) return new Error("Request was not saved before photo upload.");

  const optimized = await optimizePhoto(file);
  const path = `${requestId}/${crypto.randomUUID()}-${optimized.fileName}`;
  const upload = await withOperationTimeout(
    supabaseClient.storage.from("maintenance-request-photos").upload(path, optimized.blob, {
      contentType: optimized.contentType,
      upsert: false,
    }),
    "Request photo upload timed out. Check your connection and try again.",
    25000
  );
  if (upload.error) return upload.error;

  const { error } = await withOperationTimeout(
    supabaseClient.rpc("attach_maintenance_request_photo", {
      target_request_id: requestId,
      p_photo_storage_path: path,
      p_photo_file_name: optimized.fileName,
      p_photo_content_type: optimized.contentType,
      p_photo_file_size_bytes: optimized.blob.size || null,
      p_photo_original_file_name: safeFileName(file.name || "photo"),
      p_photo_original_size_bytes: file.size || null,
    }),
    "Request photo record save timed out. Check your connection and try again.",
    15000
  );
  if (error) {
    await removeUploadedObject("maintenance-request-photos", path);
  }
  return error || null;
}

async function optimizePhoto(file) {
  const imageTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!imageTypes.includes(file.type)) {
    return {
      blob: file,
      fileName: safeFileName(file.name || "photo"),
      contentType: file.type || "application/octet-stream",
    };
  }

  try {
    const bitmap = await createImageBitmap(file);
    const maxDimension = 2400;
    const scale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { alpha: false });
    context.drawImage(bitmap, 0, 0, width, height);
    if (bitmap.close) bitmap.close();

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/jpeg", 0.88));
    if (!blob) throw new Error("Browser could not optimize this image.");

    return {
      blob,
      fileName: `${fileBaseName(file.name || "photo")}.jpg`,
      contentType: "image/jpeg",
    };
  } catch (error) {
    console.warn("Photo optimization failed; uploading original.", error);
    return {
      blob: file,
      fileName: safeFileName(file.name || "photo"),
      contentType: file.type || "application/octet-stream",
    };
  }
}

async function optimizeLogo(file) {
  const imageTypes = ["image/jpeg", "image/png", "image/webp"];
  if (!imageTypes.includes(file.type)) {
    return {
      blob: file,
      fileName: safeFileName(file.name || "logo"),
      contentType: file.type || "application/octet-stream",
    };
  }

  try {
    const bitmap = await createImageBitmap(file);
    const maxDimension = 1200;
    const scale = Math.min(1, maxDimension / Math.max(bitmap.width, bitmap.height));
    const width = Math.max(1, Math.round(bitmap.width * scale));
    const height = Math.max(1, Math.round(bitmap.height * scale));
    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext("2d", { alpha: true });
    context.clearRect(0, 0, width, height);
    context.drawImage(bitmap, 0, 0, width, height);
    if (bitmap.close) bitmap.close();

    const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
    if (!blob) throw new Error("Browser could not optimize this logo.");

    return {
      blob,
      fileName: `${fileBaseName(file.name || "logo")}.png`,
      contentType: "image/png",
    };
  } catch (error) {
    console.warn("Logo optimization failed; uploading original.", error);
    return {
      blob: file,
      fileName: safeFileName(file.name || "logo"),
      contentType: file.type || "application/octet-stream",
    };
  }
}

function activeCompanyRole() {
  const activeMembership = companyMembers.find((member) =>
    member.company_id === activeCompanyId && member.user_id === session?.user?.id
  );
  if (activeMembership?.role) return normalizeRole(activeMembership.role);
  return normalizeRole(companies.find((company) => company.id === activeCompanyId)?.role);
}

function canManageTeam() {
  return ["admin", "manager"].includes(activeCompanyRole());
}

function canAdministerPublicRequestLinks() {
  return activeCompanyRole() === "admin";
}

function canSwitchLocations() {
  return canManageTeam() || Boolean(profilesByUserId[session.user.id]?.mobile_tech);
}

function canDeleteWorkOrders() {
  return activeCompanyRole() === "admin";
}

function canDeleteParts() {
  return ["admin", "manager"].includes(activeCompanyRole());
}

function canDeleteEquipment() {
  return ["admin", "manager"].includes(activeCompanyRole());
}

function canDeleteOperationalRecords() {
  return ["admin", "manager"].includes(activeCompanyRole());
}

function canAssignWorkOrderToMe(workOrder) {
  if (!workOrder || workOrder.assigned_to === session?.user?.id) return false;
  if (canManageTeam()) return true;
  return !workOrder.assigned_to && !isVendorAssigned(workOrder);
}

function visibleNavItems() {
  const items = [
    ["mywork", "My Work"],
    ["work", "Work Orders"],
    ["planning", "Planning"],
    ["requests", "Requests"],
    ["assets", "Equipment"],
    ["pm", "PM"],
    ["procedures", "Procedures"],
    ["parts", "Parts"],
    ["messages", "Messages"],
    ["team", "Team"],
  ];
  if (canManageTeam()) {
    items.push(["setup", "Admin Setup"], ["settings", "Settings"]);
  }
  return items;
}

function assignedUserFromForm(form, defaultUserId = null) {
  const value = form.has("assigned_to") ? form.get("assigned_to") : (defaultUserId || "");
  return value === OUTSIDE_VENDOR_VALUE ? null : value || null;
}

function isVendorAssigned(workOrder) {
  return String(workOrder.description || "").includes(OUTSIDE_VENDOR_NOTE);
}

function requiresSafetyDeviceCheck(workOrderOrPayload) {
  if (!workOrderOrPayload) return false;
  if (Object.prototype.hasOwnProperty.call(workOrderOrPayload, "safety_check_required")) {
    return Boolean(workOrderOrPayload.safety_check_required);
  }
  if (workOrderOrPayload.asset_id) return assetRequiresSafety(workOrderOrPayload.asset_id);
  if (Object.prototype.hasOwnProperty.call(workOrderOrPayload.assets || {}, "safety_devices_required")) {
    return workOrderOrPayload.assets.safety_devices_required !== false;
  }
  return Boolean(workOrderOrPayload.assets?.name);
}

function hasCompletedSafetyDeviceCheck(workOrderOrPayload) {
  return workOrderOrPayload?.status === "completed" && Boolean(workOrderOrPayload?.safety_devices_checked);
}

function currentSafetyCheckboxCheckedForWorkOrder(id) {
  if (activeWorkOrderId !== id) return false;
  return Array.from(document.querySelectorAll('#complete-work-order-form input[name="safety_devices_checked"], #quick-update-work-order-form input[name="safety_devices_checked"]')).some((field) => field.checked);
}

function syncSafetyDeviceChecks(event) {
  document.querySelectorAll('input[name="safety_devices_checked"]').forEach((field) => {
    field.checked = event.target.checked;
  });
}

function applySafetyCheckPayload(payload, checked) {
  payload.safety_devices_checked = Boolean(checked);
  payload.safety_devices_checked_at = checked ? new Date().toISOString() : null;
  return payload;
}

function assetRequiresSafety(assetId) {
  if (!assetId) return false;
  const asset = assets.find((item) => item.id === assetId);
  return asset ? asset.safety_devices_required !== false : true;
}

function applySafetyRequirementPayload(payload) {
  payload.safety_check_required = assetRequiresSafety(payload.asset_id);
  return payload;
}

function assignmentLabel(workOrder) {
  if (isVendorAssigned(workOrder)) return "Outside vendor";
  return workOrder.assigned_profile?.full_name || "Unassigned";
}

function cleanWorkOrderDescription(description) {
  return String(description || "")
    .replace(OUTSIDE_VENDOR_NOTE, "")
    .replace(/\n{3,}/g, "\n\n")
    .trim();
}

function descriptionWithAssignmentNote(description, assignmentValue) {
  const cleanDescription = cleanWorkOrderDescription(description);
  if (assignmentValue !== OUTSIDE_VENDOR_VALUE) return cleanDescription || null;
  return [cleanDescription, OUTSIDE_VENDOR_NOTE].filter(Boolean).join("\n\n");
}

async function copyTextToClipboard(text) {
  try {
    if (navigator.clipboard?.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch (error) {
    console.warn("Clipboard API failed; using fallback.", error);
  }

  const field = document.createElement("textarea");
  field.value = text;
  field.setAttribute("readonly", "");
  field.style.position = "fixed";
  field.style.left = "-9999px";
  document.body.appendChild(field);
  field.select();
  let copied = false;
  try {
    copied = document.execCommand("copy");
  } catch (error) {
    console.warn("Clipboard fallback failed.", error);
  }
  field.remove();
  return copied;
}

function descriptionWithRequestPhotoNote(description, request) {
  const cleanDescription = String(description || "").trim();
  if (!request?.photo_storage_path) return cleanDescription || null;
  const note = "[Request photo attached to original request]";
  return cleanDescription ? `${cleanDescription}\n\n${note}` : note;
}

function isProfileMissingError(error) {
  const message = error?.message || "";
  return message.includes("work_order_comments_company_author_profile_fkey") || message.includes("profiles");
}

function isMissingColumnError(error, columnName) {
  const message = error?.message || "";
  return message.includes(columnName) && (message.includes("column") || message.includes("schema cache"));
}

function friendlyWorkOrderSaveError(error) {
  const message = error?.message || "Unknown error";
  if (message.includes("work_orders_company_assigned_profile_fkey")) {
    return "The assigned user needs a company profile before they can be assigned. Try saving as Unassigned, or open Team/Company once for that user.";
  }
  if (message.includes("row-level security")) {
    return "Supabase permissions rejected this update. Make sure you are still a member of this company.";
  }
  return message;
}

async function recordWorkOrderEvent(workOrderId, eventType, summary) {
  try {
    await withOperationTimeout(
      supabaseClient.from("work_order_events").insert({
        company_id: activeCompanyId,
        work_order_id: workOrderId,
        actor_id: session.user.id,
        event_type: eventType,
        summary,
      }),
      "Activity log timed out.",
      8000
    );
  } catch (error) {
    console.warn("Could not record work order event", error);
  }
}

function describeWorkOrderChanges(previous, next) {
  if (!previous) return "Work order updated.";
  const changes = [];
  if (previous.title !== next.title) changes.push("title");
  if ((previous.description || "") !== (next.description || "")) changes.push("description");
  if ((previous.due_at || "") !== (next.due_at || "")) changes.push("due date");
  if (previous.priority !== next.priority) changes.push("priority");
  if ((previous.type || "reactive") !== next.type) changes.push("type");
  if ((previous.assigned_to || "") !== (next.assigned_to || "")) changes.push("assignment");
  if ((previous.procedure_template_id || "") !== (next.procedure_template_id || "")) changes.push("procedure");
  if (String(previous.actual_minutes || 0) !== String(next.actual_minutes || 0)) changes.push("actual minutes");
  return changes.length ? `Updated ${changes.join(", ")}.` : "Work order saved.";
}

function buildActivityFeed(comments, photos, events, usedParts = []) {
  return [
    ...comments.map((comment) => ({ ...comment, type: "comment" })),
    ...photos.map((photo) => ({ ...photo, type: "photo" })),
    ...usedParts.map((part) => ({ ...part, type: "part" })),
    ...events.map((event) => ({ ...event, type: "event" })),
  ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

function overdueWorkOrders() {
  return workOrders.filter((workOrder) => getDueState(workOrder)?.className === "overdue");
}

function completedThisWeek() {
  return workOrders.filter(isCompletedThisWeek);
}

function isCompletedThisWeek(workOrder) {
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 7);
  return Boolean(workOrder.completed_at && new Date(workOrder.completed_at) >= cutoff);
}

function completedThisMonth() {
  return workOrders.filter(isCompletedThisMonth);
}

function isCompletedThisMonth(workOrder) {
  const now = new Date();
  const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
  return Boolean(workOrder.completed_at && new Date(workOrder.completed_at) >= monthStart);
}

function averageCompletionMinutes(source = workOrders) {
  const completed = source.filter((workOrder) => workOrder.status === "completed" && Number(workOrder.actual_minutes) > 0);
  if (!completed.length) return 0;
  const total = completed.reduce((sum, workOrder) => sum + Number(workOrder.actual_minutes || 0), 0);
  return Math.round(total / completed.length);
}

function preventiveDueSoon() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const soon = new Date(today);
  soon.setDate(soon.getDate() + 7);
  return preventiveSchedules.filter((schedule) => {
    const due = new Date(`${schedule.next_due_at}T00:00:00`);
    return due >= today && due <= soon;
  });
}

function planningItems(bucket = "all") {
  const today = startOfToday();
  const soon = new Date(today);
  soon.setDate(soon.getDate() + 7);

  return workOrders
    .filter(matchesActiveLocation)
    .filter((workOrder) => workOrder.status !== "completed" && workOrder.due_at)
    .filter((workOrder) => matchesSearch([
      workOrder.title,
      workOrder.description,
      workOrder.priority,
      workOrder.status,
      workOrder.assets?.name,
      assignmentLabel(workOrder),
    ]))
    .map((workOrder) => {
      const due = new Date(`${workOrder.due_at}T00:00:00`);
      return {
        kind: "work",
        id: workOrder.id,
        title: workOrder.title,
        priority: workOrder.priority,
        status: workOrder.status,
        assetName: workOrder.assets?.name || "No equipment",
        dueAt: workOrder.due_at,
        due,
        workOrder,
      };
    })
    .filter((item) => {
      if (bucket === "overdue") return item.due < today;
      if (bucket === "today") return item.due.getTime() === today.getTime();
      if (bucket === "soon") return item.due > today && item.due <= soon;
      return true;
    })
    .sort((a, b) => a.due - b.due);
}

function planningPmItems() {
  const today = startOfToday();
  const soon = new Date(today);
  soon.setDate(soon.getDate() + 7);

  return preventiveSchedules
    .filter(matchesActiveLocation)
    .filter((schedule) => {
      const due = new Date(`${schedule.next_due_at}T00:00:00`);
      return due >= today && due <= soon;
    })
    .filter((schedule) => matchesSearch([
      schedule.title,
      schedule.frequency,
      schedule.next_due_at,
      schedule.assets?.name,
    ]))
    .map((schedule) => ({
      kind: "pm",
      id: schedule.id,
      title: schedule.title,
      assetName: schedule.assets?.name || "No equipment",
      dueAt: schedule.next_due_at,
      due: new Date(`${schedule.next_due_at}T00:00:00`),
    }))
    .sort((a, b) => a.due - b.due);
}

function followUpItems() {
  return workOrders
    .filter(matchesActiveLocation)
    .filter((workOrder) => workOrder.follow_up_needed)
    .filter((workOrder) => matchesSearch([
      workOrder.title,
      workOrder.description,
      workOrder.failure_cause,
      workOrder.resolution_summary,
      workOrder.assets?.name,
      workOrder.assigned_profile?.full_name,
    ]))
    .map((workOrder) => ({
      kind: "follow_up",
      id: workOrder.id,
      title: workOrder.title,
      assetName: workOrder.assets?.name || "No equipment",
      completedAt: workOrder.completed_at ? new Date(workOrder.completed_at).toLocaleDateString() : "not completed",
      resolution: workOrder.resolution_summary || workOrder.completion_notes || "",
      workOrder,
    }))
    .sort((a, b) => a.title.localeCompare(b.title));
}

function lowStockParts() {
  return parts.filter(isLowStockPart);
}

function partUsageRows(partId) {
  return Object.values(partsUsedByWorkOrder)
    .flat()
    .filter((row) => row.part_id === partId);
}

function isLowStockPart(part) {
  return Number(part.quantity_on_hand) <= Number(part.reorder_point);
}

function openMaintenanceRequests() {
  return maintenanceRequests.filter((request) => request.status === "submitted");
}

function exportActiveSectionCsv() {
  const exports = {
    work: {
      filename: "work-orders.csv",
      rows: workOrders.map((workOrder) => ({
        title: workOrder.title,
        status: workOrder.status,
        priority: workOrder.priority,
        type: workOrder.type || "reactive",
        equipment: workOrder.assets?.name || "",
        assigned_to: assignmentLabel(workOrder),
        due_at: workOrder.due_at || "",
        completed_at: workOrder.completed_at || "",
        actual_minutes: workOrder.actual_minutes || 0,
        failure_cause: workOrder.failure_cause || "",
        resolution_summary: workOrder.resolution_summary || "",
        follow_up_needed: Boolean(workOrder.follow_up_needed),
      })),
    },
    assets: {
      filename: "equipment.csv",
      rows: assets.map((asset) => ({
        name: asset.name,
        equipment_id: asset.asset_code || "",
        location: asset.location || "",
        status: asset.status,
      })),
    },
    requests: {
      filename: "maintenance-requests.csv",
      rows: maintenanceRequests.map((request) => ({
        title: request.title,
        status: request.status,
        priority: request.priority,
        equipment: request.assets?.name || "",
        requested_by: profilesByUserId[request.requested_by]?.full_name || "",
        created_at: request.created_at || "",
        converted_work_order_id: request.converted_work_order_id || "",
      })),
    },
    pm: {
      filename: "preventive-schedules.csv",
      rows: preventiveSchedules.map((schedule) => ({
        title: schedule.title,
        equipment: schedule.assets?.name || "",
        frequency: schedule.frequency,
        next_due_at: schedule.next_due_at,
        active: schedule.active,
      })),
    },
    parts: {
      filename: "parts.csv",
      rows: parts.map((part) => ({
        name: part.name,
        sku: part.sku || "",
        supplier_name: part.supplier_name || "",
        quantity_on_hand: part.quantity_on_hand,
        reorder_point: part.reorder_point,
        unit_cost: part.unit_cost || 0,
      })),
    },
    procedures: {
      filename: "procedures.csv",
      rows: procedureTemplates.map((template) => ({
        name: template.name,
        description: template.description || "",
        steps: template.procedure_steps?.length || 0,
      })),
    },
    team: {
      filename: "team.csv",
      rows: companyMembers.map((member) => ({
        user_id: member.user_id,
        name: profilesByUserId[member.user_id]?.full_name || "",
        role: member.role,
      })),
    },
  };

  const selected = exports[activeSection] || exports.work;
  if (!selected.rows.length) return alert("Nothing to export in this section yet.");
  downloadCsv(selected.filename, selected.rows);
}

function downloadCsv(filename, rows) {
  const headers = Object.keys(rows[0]);
  const lines = [
    headers.join(","),
    ...rows.map((row) => headers.map((header) => csvCell(row[header])).join(",")),
  ];
  const blob = new Blob([lines.join("\n")], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
